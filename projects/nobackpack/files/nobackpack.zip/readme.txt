No Backpack mod for Doom 1 & 2
------------------------------

* What is it? *

This simple Dehacked mod will remove the Backpack from 
Doom games, making gameplay and firing mechanics harder.

* How to use *

Simply load it to your favorite source-port, that supports
Dehaked information (Chocolate Doom, Crispy Doom, DOOM Retro,
Russian Doom, ZDoom and many others).

You may use a wad-file or deh-file, at your own discretion.


* Thanks for your interest! *

Created by Julian Nechaevsky on 27.04.2017.
http://jnechaevsky.sf.net

You may can everything you want with this mod, 
it's idea really not unique. :p
