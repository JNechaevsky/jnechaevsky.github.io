// MIT License
// 
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// MiniNote - minimal dark notepad for quick notes.
// Written in pure Win32 API. No frameworks, no bloat.
//


#include "file_ops.h"
#include <stdlib.h>

wchar_t* ReadUTF8File(const wchar_t* filePath)
{
    HANDLE hFile = CreateFileW(filePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE)
    {
        return NULL;
    }

    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE)
    {
        CloseHandle(hFile);
        return NULL;
    }

    if (fileSize == 0)
    {
        CloseHandle(hFile);
        wchar_t* empty = (wchar_t*)malloc(sizeof(wchar_t));
        if (empty) empty[0] = L'\0';
        return empty;
    }

    char* buffer = (char*)malloc(fileSize + 1);
    if (!buffer)
    {
        CloseHandle(hFile);
        return NULL;
    }

    DWORD bytesRead = 0;
    ReadFile(hFile, buffer, fileSize, &bytesRead, NULL);
    CloseHandle(hFile);
    buffer[bytesRead] = '\0';

    // Пропускаем UTF-8 BOM (EF BB BF): иначе \uFEFF осядет в начале текста
    // невидимкой, которую потом не из чего вычистить.
    char* src = buffer;
    int srcLen = (int)bytesRead;
    if (srcLen >= 3 && (unsigned char)src[0] == 0xEF &&
        (unsigned char)src[1] == 0xBB && (unsigned char)src[2] == 0xBF)
    {
        src += 3;
        srcLen -= 3;
    }

    int wlen = MultiByteToWideChar(CP_UTF8, 0, src, srcLen, NULL, 0);
    if (wlen == 0)
    {
        free(buffer);
        return NULL;
    }

    wchar_t* wText = (wchar_t*)malloc((wlen + 1) * sizeof(wchar_t));
    if (!wText)
    {
        free(buffer);
        return NULL;
    }

    MultiByteToWideChar(CP_UTF8, 0, src, srcLen, wText, wlen);
    wText[wlen] = L'\0';

    // Нормализация концов строк: заменяем одиночные \n на \r\n для EDIT-контроля
    int newLen = wlen;
    for (int i = 0; i < wlen; i++)
    {
        if (wText[i] == L'\n' && (i == 0 || wText[i - 1] != L'\r'))
        {
            newLen++;
        }
    }

    if (newLen > wlen)
    {
        wchar_t* normalized = (wchar_t*)malloc((newLen + 1) * sizeof(wchar_t));
        if (normalized)
        {
            int j = 0;
            for (int i = 0; i < wlen; i++)
            {
                if (wText[i] == L'\n' && (i == 0 || wText[i - 1] != L'\r'))
                {
                    normalized[j++] = L'\r';
                }
                normalized[j++] = wText[i];
            }
            normalized[j] = L'\0';
            
            free(wText);
            wText = normalized;
        }
    }

    free(buffer);
    return wText;
}

BOOL SaveUTF8File(const wchar_t* filePath, const wchar_t* text)
{
    HANDLE hFile = CreateFileW(filePath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE)
    {
        return FALSE;
    }

    int len = WideCharToMultiByte(CP_UTF8, 0, text, -1, NULL, 0, NULL, NULL);
    if (len == 0)
    {
        CloseHandle(hFile);
        return FALSE;
    }

    char* buffer = (char*)malloc(len);
    if (!buffer)
    {
        CloseHandle(hFile);
        return FALSE;
    }

    WideCharToMultiByte(CP_UTF8, 0, text, -1, buffer, len, NULL, NULL);
    
    DWORD written = 0;
    WriteFile(hFile, buffer, len - 1, &written, NULL);

    free(buffer);
    CloseHandle(hFile);
    return TRUE;
}