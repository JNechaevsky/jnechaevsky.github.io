// MIT License
// 
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// MiniNote - minimal dark notepad for quick notes.
// Written in pure Win32 API. No frameworks, no bloat.
//


#ifndef FILE_OPS_H
#define FILE_OPS_H

#include <windows.h>

// Читает файл как UTF-8, возвращает wchar_t*. NULL при ошибке.
wchar_t* ReadUTF8File(const wchar_t* filePath);

// Сохраняет wchar_t* как UTF-8 файл. FALSE при ошибке.
BOOL SaveUTF8File(const wchar_t* filePath, const wchar_t* text);

#endif // FILE_OPS_H