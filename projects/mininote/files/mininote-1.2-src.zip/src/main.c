// MIT License
// 
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// MiniNote - minimal dark notepad for quick notes.
// Written in pure Win32 API. No frameworks, no bloat.
//

/*

    Compile under Build Tools:

rc /nologo /fo mininote.res mininote.rc && cl /O2 /W4 /utf-8 ^
src\main.c src\file_ops.c /Fe:mininote.exe /link user32.lib gdi32.lib ^
comdlg32.lib shell32.lib advapi32.lib /SUBSYSTEM:WINDOWS /MANIFEST:EMBED ^
/MANIFESTINPUT:mininote.manifest mininote.res


    Compile under MSYS / GCC:

windres mininote.rc -O coff -o mininote.res

gcc -O2 -Wall -Wextra -mwindows -o mininote.exe \
    src/main.c src/file_ops.c mininote.res \
    -luser32 -lgdi32 -lcomdlg32 -lshell32 -ladvapi32


    Compile under MSYS / Clang:

windres mininote.rc -O coff -o mininote.res

clang -O2 -Wall -Wextra -mwindows -municode -o mininote.exe \
    src/main.c src/file_ops.c mininote.res \
    -luser32 -lgdi32 -lcomdlg32 -lshell32 -ladvapi32

*/


// Подавляем варнинги из заголовочных файлов Windows SDK
#pragma warning(push)
#pragma warning(disable: 4201)  // нестандартное расширение: структура без имени


#include <windows.h>
#include <shellapi.h>

#ifndef RICHEDIT_VER
#define RICHEDIT_VER 0x0200
#endif
#include <richedit.h>

#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "file_ops.h"

#define EDIT_ID               301
#define TIMER_AUTOSAVE        1
#define AUTOSAVE_INTERVAL_MS  10000
#define IDM_SELECT_ALL        1000
#define IDM_SAVE              1001
#define IDM_ZOOM_RESET        1002
#define IDM_DATE_TIME         1003
#define DEFAULT_FONT_SIZE_PTS 11 // размер, к которому возвращает Ctrl+0

// Системный трей
#define WM_TRAYICON         (WM_USER + 1)
#define WM_SHOWINSTANCE     (WM_USER + 2)
#define TRAY_ICON_ID        1
#define IDM_TRAY_SHOW       2000
#define IDM_TRAY_QUIT       2001
#define IDM_TRAY_ABOUT      2002
#define IDM_TRAY_TOPMOST    2003
#define IDM_TRAY_DARK       2004
#define IDM_TRAY_WORDWRAP   2005
#define IDM_TRAY_STARTUP    2006

// Окно About
#define IDC_ABOUT_CLOSE 601
#define IDC_ABOUT_TEXT  602

#define DWMWA_USE_IMMERSIVE_DARK_MODE 20

#define LIGHT_BG    RGB(255, 255, 255)
#define LIGHT_TEXT  RGB(0, 0, 0)
#define DARK_BG     RGB(30, 30, 30)
#define DARK_TEXT   RGB(220, 220, 220)

#define CONFIG_FILENAME L"mininote.ini"
#define DATA_FILENAME   L"mininote.txt"

// Автозапуск: значение "MiniNote" в ветке HKCU\...\CurrentVersion\Run
#define STARTUP_RUN_KEY   L"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define STARTUP_VALUE_NAME L"MiniNote"
#define STARTUP_TRAY_ARG  L"/tray" // запуск из автозапуска: окно сразу в трей

// Именованный мьютекс для запрета второго экземпляра программы
#define SINGLE_INSTANCE_MUTEX L"Local\\MiniNote_SingleInstance"

#define BETWEEN(l, u, x) (((x) < (l)) ? (l) : ((x) > (u)) ? (u) : (x))

typedef BOOL (WINAPI *PFN_AllowDarkModeForWindow)(HWND hWnd, BOOL bAllow);
typedef int  (WINAPI *PFN_SetPreferredAppMode)(int mode);
typedef void (WINAPI *PFN_RefreshImmersiveColorPolicyState)(void);
typedef void (WINAPI *PFN_FlushMenuThemes)(void);
typedef HRESULT (WINAPI *PFN_DwmSetWindowAttribute)(HWND hWnd, DWORD dwAttribute, LPCVOID pvAttribute, DWORD cbAttribute);
typedef HRESULT (WINAPI *PFN_SetWindowTheme)(HWND hWnd, LPCWSTR pszSubAppName, LPCWSTR pszSubIdList);

static PFN_AllowDarkModeForWindow           g_pAllowDarkModeForWindow = NULL;
static PFN_SetPreferredAppMode              g_pSetPreferredAppMode = NULL;
static PFN_RefreshImmersiveColorPolicyState g_pRefreshImmersiveColorPolicyState = NULL;
static PFN_FlushMenuThemes                  g_pFlushMenuThemes = NULL;
static PFN_DwmSetWindowAttribute            g_pDwmSetWindowAttribute = NULL;
static PFN_SetWindowTheme                   g_pSetWindowTheme = NULL;

static wchar_t g_iniPath[MAX_PATH];
static wchar_t g_dataPath[MAX_PATH];

static int g_winX = 0, g_winY = 0, g_winW = 0, g_winH = 0;
static BOOL g_darkTheme = TRUE; // По умолчанию тёмная
static BOOL g_wordWrap = TRUE;  // По умолчанию перенос строк включён
static BOOL g_topmost = FALSE;  // По умолчанию обычное окно
static BOOL g_runAtStartup = FALSE; // Автозапуск при старте Windows

static COLORREF g_bgColor = DARK_BG;
static COLORREF g_textColor = DARK_TEXT;
static HBRUSH g_hEditBrush = NULL;
static LOGFONTW g_lf;
static int g_fontSizePts = DEFAULT_FONT_SIZE_PTS; // Consolas 11pt по умолчанию

// Последний сохранённый текст для сравнения при автосохранении.
// Автосохранение не зависит от уведомлений EN_CHANGE (они капризны у RichEdit):
// просто сравниваем текущий текст с последним сохранённым и пишем при различии.
static wchar_t* g_lastSavedText = NULL;

// Длина g_lastSavedText в той же метрике, что и EM_GETTEXTLENGTHEX(GTL_DEFAULT).
// Позволяет в EN_UPDATE видеть «грязь» без копирования всего текста: если
// длины разошлись - сравнение строк уже не нужно.
static LONG g_lastSavedLen = -1;

// Есть ли несохранённые правки (звёздочка в заголовке). Считается в EN_UPDATE
// (надёжнее капризного EN_CHANGE): сначала по длине, при совпадении длин -
// полным wcscmp с g_lastSavedText.
static BOOL g_dirty = FALSE;

// TRUE после завершения WM_CREATE: до этого EN_UPDATE от начального WM_SETTEXT
// не с чем сравнивать (g_lastSavedText ещё не установлен).
static BOOL g_editorReady = FALSE;

// Главные окна приложения
static HWND g_hwndMain = NULL;
static HWND g_hwndAbout = NULL;
static HFONT g_hAboutFont = NULL;

// Состояние трея
static NOTIFYICONDATAW g_nid;
static BOOL g_quitRequested = FALSE; // TRUE, когда закрываемся по-настоящему, а не в трей

// Широковещательное сообщение оболочки "трей пересоздан" (старт/рестарт
// explorer.exe). Номер динамический - через RegisterWindowMessage.
static UINT g_uTaskbarCreated = 0;

// Subclass RichEdit: мгновенный (без анимации) скролл колесом, Ctrl+колесо-зум,
// текстовый фильтр вставки и контекстное меню. См. EditSubclassProc.
static WNDPROC g_origEditProc = NULL;

HINSTANCE g_hInst;


// =============================================================================
//
//                                 УТИЛИТЫ
//
// =============================================================================

static int GetDpiY(void)
{
    HDC hdc = GetDC(NULL);
    int dpi = GetDeviceCaps(hdc, LOGPIXELSY);
    ReleaseDC(NULL, hdc);

    return (dpi > 0) ? dpi : 96;
}

// =============================================================================
//
//                                ФАЙЛ НАСТРОЕК
//
// =============================================================================

static void trim(char *s)
{
    if (!s) return;
    char *p = s;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
    if (p != s) memmove(s, p, (size_t)(strlen(p) + 1));
    size_t n = strlen(s);
    while (n && (s[n-1] == ' ' || s[n-1] == '\t' || s[n-1] == '\r' || s[n-1] == '\n')) { s[--n] = 0; }
}

static int ieq(const char *a, const char *b)
{
    for (; *a && *b; a++, b++)
    {
        char ca = (*a >= 'A' && *a <= 'Z') ? (char)(*a + 32) : *a;
        char cb = (*b >= 'A' && *b <= 'Z') ? (char)(*b + 32) : *b;
        if (ca != cb) return 0;
    }
    return *a == *b;
}

static void ini_apply_kv(const char *key, const char *val)
{
         if (ieq(key, "dark_theme")) g_darkTheme = (int)strtol(val, NULL, 10);
    else if (ieq(key, "word_wrap")) g_wordWrap = (int)strtol(val, NULL, 10);
    else if (ieq(key, "topmost")) g_topmost = (int)strtol(val, NULL, 10);
    else if (ieq(key, "run_at_startup")) g_runAtStartup = (int)strtol(val, NULL, 10);
    else if (ieq(key, "window_x"))   g_winX = (int)strtol(val, NULL, 10);
    else if (ieq(key, "window_y"))   g_winY = (int)strtol(val, NULL, 10);
    else if (ieq(key, "window_w"))   g_winW = (int)strtol(val, NULL, 10);
    else if (ieq(key, "window_h"))   g_winH = (int)strtol(val, NULL, 10);
    else if (ieq(key, "font_face")) MultiByteToWideChar(CP_UTF8, 0, val, -1, g_lf.lfFaceName, LF_FACESIZE);
    else if (ieq(key, "font_size")) g_fontSizePts = (int)strtol(val, NULL, 10);
    else if (ieq(key, "font_weight")) g_lf.lfWeight = (int)strtol(val, NULL, 10);
    else if (ieq(key, "font_italic")) g_lf.lfItalic = (BYTE)(int)strtol(val, NULL, 10);
    else if (ieq(key, "font_underline")) g_lf.lfUnderline = (BYTE)(int)strtol(val, NULL, 10);
    else if (ieq(key, "font_strikeout")) g_lf.lfStrikeOut = (BYTE)(int)strtol(val, NULL, 10);
    else if (ieq(key, "font_charset")) g_lf.lfCharSet = (BYTE)(int)strtol(val, NULL, 10);
}

static void InitPaths(void)
{
    DWORD len = GetModuleFileNameW(NULL, g_iniPath, MAX_PATH);
    if (len == 0 || len >= MAX_PATH)
    {
        wcscpy_s(g_iniPath, MAX_PATH, CONFIG_FILENAME);
        wcscpy_s(g_dataPath, MAX_PATH, DATA_FILENAME);
        return;
    }
    wchar_t* slash = wcsrchr(g_iniPath, L'\\');
    if (slash)
    {
        slash[1] = L'\0';
        wcscpy_s(g_dataPath, MAX_PATH, g_iniPath);
        wcscat_s(g_iniPath, MAX_PATH, CONFIG_FILENAME);
        wcscat_s(g_dataPath, MAX_PATH, DATA_FILENAME);
    }
    else
    {
        wcscpy_s(g_iniPath, MAX_PATH, CONFIG_FILENAME);
        wcscpy_s(g_dataPath, MAX_PATH, DATA_FILENAME);
    }
}

static int CFG_Load(const wchar_t *path)
{
    FILE *f = NULL;
    if (_wfopen_s(&f, path, L"r") != 0 || !f) return 0;
    char line[256];
    while (fgets(line, sizeof line, f))
    {
        trim(line);
        if (!line[0] || line[0] == '#' || line[0] == ';' || line[0] == '[') continue;
        char *p = line;
        while (*p && *p != ' ' && *p != '\t') p++;
        if (!*p) continue;
        *p = 0;
        char *key = line;
        char *val = p + 1;
        trim(key);
        trim(val);
        if (key[0]) ini_apply_kv(key, val);
    }
    fclose(f);
    return 1;
}

static void CFG_Check(void)
{
    g_darkTheme = BETWEEN(0, 1, g_darkTheme);
    g_wordWrap = BETWEEN(0, 1, g_wordWrap);
    g_topmost = BETWEEN(0, 1, g_topmost);
    g_runAtStartup = BETWEEN(0, 1, g_runAtStartup);
    if (g_winW < 100) g_winW = 0;
    if (g_winH < 100) g_winH = 0;
    if (g_fontSizePts > 0) g_fontSizePts = BETWEEN(4, 200, g_fontSizePts);
    g_lf.lfWeight = BETWEEN(1, 1000, g_lf.lfWeight);
}

static int CFG_Save(const wchar_t *path)
{
    FILE *f = NULL;
    if (_wfopen_s(&f, path, L"w") != 0 || !f) return 0;
    fprintf(f, "# MiniNote configuration file\n");
    fprintf(f, "dark_theme %d\n", g_darkTheme ? 1 : 0);
    fprintf(f, "word_wrap %d\n", g_wordWrap ? 1 : 0);
    fprintf(f, "topmost %d\n", g_topmost ? 1 : 0);
    fprintf(f, "window_x %d\n", g_winX);
    fprintf(f, "window_y %d\n", g_winY);
    fprintf(f, "window_w %d\n", g_winW);
    fprintf(f, "window_h %d\n", g_winH);

    char faceUtf8[LF_FACESIZE * 4];
    WideCharToMultiByte(CP_UTF8, 0, g_lf.lfFaceName, -1, faceUtf8, sizeof(faceUtf8), NULL, NULL);

    fprintf(f, "font_face %s\n", faceUtf8);
    fprintf(f, "font_size %d\n", g_fontSizePts);
    fprintf(f, "font_weight %d\n", (int)g_lf.lfWeight);
    fprintf(f, "font_italic %d\n", g_lf.lfItalic ? 1 : 0);
    fprintf(f, "font_underline %d\n", g_lf.lfUnderline ? 1 : 0);
    fprintf(f, "font_strikeout %d\n", g_lf.lfStrikeOut ? 1 : 0);
    fprintf(f, "font_charset %d\n", (int)g_lf.lfCharSet);

    fclose(f);
    return 1;
}

// =============================================================================
//                                   АВТОЗАПУСК
// =============================================================================
//
// Реализован значением "MiniNote" в HKCU\Software\Microsoft\Windows\
// CurrentVersion\Run - стандартном месте, откуда Windows запускает
// пользовательские программы при входе в систему. Ini хранит желаемое
// состояние, реестр - фактическое; при старте они сверяются и лечатся.

// TRUE, если значение "MiniNote" есть в ветке Run.
static BOOL StartupIsEnabled(void)
{
    HKEY hKey;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, STARTUP_RUN_KEY, 0, KEY_QUERY_VALUE, &hKey) != ERROR_SUCCESS)
        return FALSE;
    LONG r = RegQueryValueExW(hKey, STARTUP_VALUE_NAME, NULL, NULL, NULL, NULL);
    RegCloseKey(hKey);
    return r == ERROR_SUCCESS;
}

// Строка автозапуска: полный путь к exe в кавычках + аргумент /tray,
// чтобы при входе в Windows программа стартовала свёрнутой в трей.
static BOOL StartupExeQuoted(wchar_t* buf, size_t cch)
{
    wchar_t path[MAX_PATH];
    DWORD len = GetModuleFileNameW(NULL, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) return FALSE;
    return swprintf_s(buf, cch, L"\"%s\" " STARTUP_TRAY_ARG, path) > 0;
}

// TRUE, если значение в реестре совпадает с фактической командной строкой.
static BOOL StartupPathCurrent(void)
{
    wchar_t want[MAX_PATH + 16];
    if (!StartupExeQuoted(want, sizeof(want) / sizeof(want[0]))) return FALSE;

    HKEY hKey;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, STARTUP_RUN_KEY, 0, KEY_QUERY_VALUE, &hKey) != ERROR_SUCCESS)
        return FALSE;
    wchar_t have[MAX_PATH + 16];
    DWORD cb = sizeof(have) - sizeof(have[0]), type = 0;
    LONG r = RegQueryValueExW(hKey, STARTUP_VALUE_NAME, NULL, &type, (BYTE*)have, &cb);
    RegCloseKey(hKey);
    if (r != ERROR_SUCCESS || type != REG_SZ) return FALSE;
    have[cb / sizeof(wchar_t)] = L'\0';
    return wcscmp(have, want) == 0;
}

// enable=TRUE - записать командную строку текущего exe, FALSE - удалить значение.
static BOOL StartupSet(BOOL enable)
{
    if (enable)
    {
        wchar_t quoted[MAX_PATH + 16];
        if (!StartupExeQuoted(quoted, sizeof(quoted) / sizeof(quoted[0]))) return FALSE;

        HKEY hKey;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, STARTUP_RUN_KEY, 0, KEY_SET_VALUE, &hKey) != ERROR_SUCCESS)
            return FALSE;
        LONG r = RegSetValueExW(hKey, STARTUP_VALUE_NAME, 0, REG_SZ,
                                (const BYTE*)quoted,
                                (DWORD)((wcslen(quoted) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
        return r == ERROR_SUCCESS;
    }
    return RegDeleteKeyValueW(HKEY_CURRENT_USER, STARTUP_RUN_KEY, STARTUP_VALUE_NAME) == ERROR_SUCCESS;
}

// =============================================================================
//
//                                ИНИЦИАЛИЗАЦИЯ
//
// =============================================================================

static void InitDarkModeAPI(void)
{
    HMODULE hUx = LoadLibraryW(L"uxtheme.dll");
    if (hUx)
    {
        g_pAllowDarkModeForWindow = (PFN_AllowDarkModeForWindow)GetProcAddress(hUx, MAKEINTRESOURCEA(133));
        g_pSetPreferredAppMode = (PFN_SetPreferredAppMode)GetProcAddress(hUx, MAKEINTRESOURCEA(135));
        g_pRefreshImmersiveColorPolicyState = (PFN_RefreshImmersiveColorPolicyState)GetProcAddress(hUx, MAKEINTRESOURCEA(104));
        g_pFlushMenuThemes = (PFN_FlushMenuThemes)GetProcAddress(hUx, MAKEINTRESOURCEA(136));
        g_pSetWindowTheme = (PFN_SetWindowTheme)GetProcAddress(hUx, "SetWindowTheme");
    }
    HMODULE hDwm = LoadLibraryW(L"dwmapi.dll");
    if (hDwm)
    {
        g_pDwmSetWindowAttribute = (PFN_DwmSetWindowAttribute)GetProcAddress(hDwm, "DwmSetWindowAttribute");
    }
}

static void RecreateEditBrush(void)
{
    if (g_hEditBrush) DeleteObject(g_hEditBrush);
    g_hEditBrush = CreateSolidBrush(g_bgColor);
}

static void InitFontDefaults(void)
{
    memset(&g_lf, 0, sizeof(g_lf));
    g_lf.lfWeight = FW_NORMAL;
    g_lf.lfCharSet = DEFAULT_CHARSET;
    g_lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
    g_lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    g_lf.lfQuality = CLEARTYPE_QUALITY;
    g_lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
    wcscpy_s(g_lf.lfFaceName, LF_FACESIZE, L"Consolas");
}

// RichEdit игнорирует WM_SETFONT, шрифт и цвет текста задаются через
// EM_SETCHARFORMAT. Размер указывается в твипах (1 пункт = 20 твипов) и,
// в отличие от lfHeight у EDIT, не зависит от DPI.
// ВАЖНО: контрол живёт в режиме TM_PLAINTEXT, а в нём RichEdit принимает
// только ФОРМАТ ПО УМОЛЧАНИЮ (SCF_DEFAULT) - SCF_ALL игнорируется.
static void ApplyEditorFont(HWND hEdit)
{
    CHARFORMAT2W cf;
    memset(&cf, 0, sizeof(cf));
    cf.cbSize = sizeof(CHARFORMAT2W);
    cf.dwMask = CFM_FACE | CFM_SIZE | CFM_WEIGHT | CFM_ITALIC |
                CFM_UNDERLINE | CFM_STRIKEOUT | CFM_CHARSET | CFM_COLOR;
    cf.yHeight = (LONG)g_fontSizePts * 20;
    cf.crTextColor = g_textColor;
    cf.bCharSet = g_lf.lfCharSet;
    cf.bPitchAndFamily = (BYTE)g_lf.lfPitchAndFamily;
    cf.wWeight = (WORD)g_lf.lfWeight;
    wcscpy_s(cf.szFaceName, LF_FACESIZE, g_lf.lfFaceName);

    cf.dwEffects = 0;
    if (g_lf.lfItalic)    cf.dwEffects |= CFE_ITALIC;
    if (g_lf.lfUnderline) cf.dwEffects |= CFE_UNDERLINE;
    if (g_lf.lfStrikeOut) cf.dwEffects |= CFE_STRIKEOUT;

    // SCF_DEFAULT, а не SCF_ALL: в TM_PLAINTEXT пересимвольный формат
    // игнорируется, работает только формат по умолчанию для всего документа.
    SendMessageW(hEdit, EM_SETCHARFORMAT, SCF_DEFAULT, (LPARAM)&cf);
}

// Перенос строк в RichEdit управляется через EM_SETTARGETDEVICE.
// Эмпирически установленная семантика (при нашем стиле ES_AUTOHSCROLL):
//   wParam = NULL (0), lParam = 0 → перенос по ширине окна; RichEdit сам
//                                   переформатирует текст при ресайзе;
//   wParam = NULL (0), lParam = 1 → перенос ВЫКЛЮЧЕН, текст идёт одной длинной
//                                   строкой, работает горизонтальный скролл.
// ВАЖНО: wParam должен быть NULL (или валидным HDC). Значение wParam = 1 это
// НЕВАЛИДНЫЙ хэндл устройства, который ломает отрисовку контрола. Не использовать.
// Документация MSDN по этому месту противоречива, поэтому опираемся на эмпирику.
static void ApplyWordWrap(HWND hEdit)
{
    if (g_wordWrap)
    {
        // Перенос по ширине окна
        SendMessageW(hEdit, EM_SETTARGETDEVICE, 0, 0);
    }
    else
    {
        // Без переноса: одна длинная строка
        SendMessageW(hEdit, EM_SETTARGETDEVICE, 0, 1);
    }
}

// Subclass RichEdit. Зоны ответственности:
//  - WM_MOUSEWHEEL: мгновенный скролл через EM_LINESCROLL (RichEdit анимирует
//    прокрутку независимо от системных настроек) + Ctrl+колесо = зум шрифта;
//  - WM_PASTE: вставку пропускаем только если в буфере есть текст;
//  - WM_CONTEXTMENU: наше контекстное меню (нативного у RichEdit нет).
// Скроллбары не трогаем: там анимация менее заметна, а полная замена требует
// ручной обработки WM_VSCROLL/WM_HSCROLL с расчётом позиций.
static LRESULT CALLBACK EditSubclassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_MOUSEWHEEL:
        {
            int delta = (short)HIWORD(wParam);

            // Ctrl+колесо - зум шрифта редактора, 1 пункт за щелчок.
            // Новое значение живёт в g_fontSizePts и пишется в ini при выходе.
            // Состояние клавиш - в младшем слове wParam (GET_KEYSTATE_WPARAM
            // требует windowsx.h, обходимся LOWORD).
            if (LOWORD(wParam) & MK_CONTROL)
            {
                int newSize = BETWEEN(4, 96, g_fontSizePts + (delta > 0 ? 1 : (delta < 0 ? -1 : 0)));
                if (newSize != g_fontSizePts)
                {
                    g_fontSizePts = newSize;
                    ApplyEditorFont(hwnd);
                }
                return 0;
            }

            // Вертикальная прокрутка: получаем системное количество строк за клик
            // и прокручиваем мгновенно через EM_LINESCROLL.
            UINT lines = 3;
            SystemParametersInfoW(SPI_GETWHEELSCROLLLINES, 0, &lines, 0);
            if (lines == (UINT)-1) lines = 20; // WHEEL_PAGESCROLL = приблизительно страница
            int scrollLines = (delta / 120) * (int)lines; // 120 = WHEEL_DELTA
            SendMessageW(hwnd, EM_LINESCROLL, 0, -scrollLines);
            return 0;
        }
        case WM_PASTE:
        {
            // MiniNote - только текст. TM_PLAINTEXT убирает форматирование,
            // но чистый битмап (PrintScreen) контрол всё равно мог вставить
            // как объект. Пропускаем вставку, только если в буфере есть текст.
            if (!IsClipboardFormatAvailable(CF_UNICODETEXT) &&
                !IsClipboardFormatAvailable(CF_TEXT))
            {
                return 0; // картинки и прочие не-текстовые данные игнорируем
            }
            break;
        }
        case WM_MOUSEHWHEEL:
        {
            // Горизонтальная прокрутка (когда перенос строк выключен).
            int delta = (short)HIWORD(wParam);
            int scrollChars = (delta / 120) * 3;
            SendMessageW(hwnd, EM_LINESCROLL, -scrollChars, 0);
            return 0;
        }
        case WM_CONTEXTMENU:
        {
            // Контекстное меню редактора. Хозяин - главное окно: команды
            // придут к нему как WM_COMMAND с нативными WM_CUT/WM_COPY/...
            HWND hParent = GetParent(hwnd);
            POINT pt;
            if ((DWORD)lParam == 0xFFFFFFFF) GetCursorPos(&pt); // Shift+F10: (-1,-1)
            else { pt.x = (short)LOWORD(lParam); pt.y = (short)HIWORD(lParam); }

            HMENU m = CreatePopupMenu();
            AppendMenuW(m, MF_STRING, WM_UNDO,  L"Undo\tCtrl+Z");
            AppendMenuW(m, MF_SEPARATOR, 0, NULL);
            AppendMenuW(m, MF_STRING, WM_CUT,   L"Cut\tCtrl+X");
            AppendMenuW(m, MF_STRING, WM_COPY,  L"Copy\tCtrl+C");
            AppendMenuW(m, MF_STRING, WM_PASTE, L"Paste\tCtrl+V");
            AppendMenuW(m, MF_STRING, WM_CLEAR, L"Delete\tDel");
            AppendMenuW(m, MF_SEPARATOR, 0, NULL);
            AppendMenuW(m, MF_STRING, IDM_SELECT_ALL, L"Select All\tCtrl+A");

            CHARRANGE cr;
            SendMessageW(hwnd, EM_EXGETSEL, 0, (LPARAM)&cr);
            BOOL hasSel = (cr.cpMin != cr.cpMax);
            EnableMenuItem(m, WM_UNDO, MF_BYCOMMAND |
                (SendMessageW(hwnd, EM_CANUNDO, 0, 0) ? MF_ENABLED : MF_GRAYED));
            EnableMenuItem(m, WM_CUT,   MF_BYCOMMAND | (hasSel ? MF_ENABLED : MF_GRAYED));
            EnableMenuItem(m, WM_COPY,  MF_BYCOMMAND | (hasSel ? MF_ENABLED : MF_GRAYED));
            EnableMenuItem(m, WM_CLEAR, MF_BYCOMMAND | (hasSel ? MF_ENABLED : MF_GRAYED));
            EnableMenuItem(m, WM_PASTE, MF_BYCOMMAND |
                (SendMessageW(hwnd, EM_CANPASTE, 0, 0) ? MF_ENABLED : MF_GRAYED));

            SetForegroundWindow(hParent); // иначе меню не закрывается кликом вне
            TrackPopupMenu(m, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hParent, NULL);
            DestroyMenu(m);
            PostMessageW(hParent, WM_NULL, 0, 0);
            return 0;
        }
    }
    return CallWindowProcW(g_origEditProc, hwnd, msg, wParam, lParam);
}

static void ApplyDarkTheme(HWND hwnd, BOOL enable)
{
    g_bgColor = enable ? DARK_BG : LIGHT_BG;
    g_textColor = enable ? DARK_TEXT : LIGHT_TEXT;
    RecreateEditBrush();

    if (g_pSetPreferredAppMode) g_pSetPreferredAppMode(enable ? 2 : 0);

    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
    if (g_pAllowDarkModeForWindow)
    {
        g_pAllowDarkModeForWindow(hwnd, enable);
        if (hEdit) g_pAllowDarkModeForWindow(hEdit, enable);
    }

    if (g_pSetWindowTheme)
    {
        g_pSetWindowTheme(hwnd, enable ? L"Explorer" : NULL, NULL);
        if (hEdit) g_pSetWindowTheme(hEdit, enable ? L"Explorer" : NULL, NULL);
    }
    SendMessageW(hwnd, WM_THEMECHANGED, 0, 0);
    if (hEdit) SendMessageW(hEdit, WM_THEMECHANGED, 0, 0);

    if (g_pDwmSetWindowAttribute)
    {
        BOOL dark = enable;
        g_pDwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof(dark));
    }

    if (g_pRefreshImmersiveColorPolicyState) g_pRefreshImmersiveColorPolicyState();
    if (g_pFlushMenuThemes) g_pFlushMenuThemes();

    SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);

    if (hEdit)
    {
        // RichEdit красится сам: фон через EM_SETBKGNDCOLOR, цвет текста через
        // charformat. WM_CTLCOLOREDIT на RichEdit не действует.
        SendMessageW(hEdit, EM_SETBKGNDCOLOR, FALSE, (LPARAM)g_bgColor);
        ApplyEditorFont(hEdit);
        InvalidateRect(hEdit, NULL, TRUE);
    }
    InvalidateRect(hwnd, NULL, TRUE);
}

// Надёжное получение текста из RichEdit. GetWindowTextLength/GetWindowText
// для RichEdit могут возвращать некорректную длину, поэтому используем
// «родные» сообщения EM_GETTEXTLENGTHEX + EM_GETTEXTEX (UTF-16, codepage 1200).
static LONG GetEditTextLen(HWND hEdit)
{
    GETTEXTLENGTHEX gtl;
    gtl.flags = GTL_DEFAULT;
    gtl.codepage = 1200;
    return (LONG)SendMessageW(hEdit, EM_GETTEXTLENGTHEX, (WPARAM)&gtl, 0);
}

static wchar_t* GetEditText(HWND hEdit)
{
    LRESULT len = GetEditTextLen(hEdit);
    if (len < 0) return NULL;

    wchar_t* text = (wchar_t*)malloc(((size_t)len + 1) * sizeof(wchar_t));
    if (!text) return NULL;

    GETTEXTEX gt;
    gt.cb = (DWORD)(((size_t)len + 1) * sizeof(wchar_t));
    gt.flags = GT_DEFAULT;
    gt.codepage = 1200;
    gt.lpDefaultChar = NULL;
    gt.lpUsedDefChar = NULL;
    SendMessageW(hEdit, EM_GETTEXTEX, (WPARAM)&gt, (LPARAM)text);
    text[len] = L'\0';

    return text;
}

// Заголовок окна: звёздочка, когда есть несохранённые правки.
static void UpdateTitle(HWND hwnd)
{
    SetWindowTextW(hwnd, g_dirty ? L"MiniNote *" : L"MiniNote");
}

static void DoAutoSave(HWND hwnd)
{
    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
    if (!hEdit) return;

    wchar_t* text = GetEditText(hEdit);
    if (!text) return;

    // Сохраняем только если текст реально изменился с последнего сохранения.
    if (g_lastSavedText == NULL || wcscmp(text, g_lastSavedText) != 0)
    {
        if (SaveUTF8File(g_dataPath, text))
        {
            free(g_lastSavedText);
            g_lastSavedText = text; // передаём владение, не копируем заново
            text = NULL;
            g_lastSavedLen = GetEditTextLen(hEdit);
            g_dirty = FALSE;
            UpdateTitle(hwnd);
        }
    }
    free(text);
}

static void CaptureWindowPlacement(HWND hwnd)
{
    WINDOWPLACEMENT wp;
    wp.length = sizeof(wp);
    if (GetWindowPlacement(hwnd, &wp))
    {
        g_winX = wp.rcNormalPosition.left;
        g_winY = wp.rcNormalPosition.top;
        g_winW = wp.rcNormalPosition.right - wp.rcNormalPosition.left;
        g_winH = wp.rcNormalPosition.bottom - wp.rcNormalPosition.top;
    }
}

// =============================================================================
//
//                                СИСТЕМНЫЙ ТРЕЙ
//
// =============================================================================

static void AddTrayIcon(HWND hwnd)
{
    memset(&g_nid, 0, sizeof(g_nid));
    g_nid.cbSize = sizeof(NOTIFYICONDATAW);
    g_nid.hWnd = hwnd;
    g_nid.uID = TRAY_ICON_ID;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;
    g_nid.hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(1));
    wcscpy_s(g_nid.szTip, 128, L"MiniNote");
    Shell_NotifyIconW(NIM_ADD, &g_nid);
}

static void RemoveTrayIcon(void)
{
    g_nid.uFlags = 0;
    Shell_NotifyIconW(NIM_DELETE, &g_nid);
}

static void HideToTray(HWND hwnd)
{
    ShowWindow(hwnd, SW_HIDE);
}

static void ShowMainWindow(HWND hwnd)
{
    ShowWindow(hwnd, IsIconic(hwnd) ? SW_RESTORE : SW_SHOW);
    // Windows может отказать в SetForegroundWindow из-за foreground-лока
    // (например когда окно подняли повторным запуском из другой нити).
    // Классический обход: эмуляция нажатия Alt снимает лок на короткий миг.
    if (!SetForegroundWindow(hwnd))
    {
        keybd_event(VK_MENU, 0, 0, 0);
        keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, 0);
        SetForegroundWindow(hwnd);
    }
    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
    if (hEdit) SetFocus(hEdit);
}

static void ToggleMainWindow(HWND hwnd)
{
    if (IsWindowVisible(hwnd))
    {
        HideToTray(hwnd);
    }
    else
    {
        ShowMainWindow(hwnd);
    }
}

static void ShowTrayMenu(HWND hwnd)
{
    POINT pt;
    GetCursorPos(&pt);

    HMENU hMenu = CreatePopupMenu();
    AppendMenuW(hMenu, MF_STRING, IDM_TRAY_ABOUT, L"About");
    AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenu, MF_STRING | (g_topmost ? MF_CHECKED : 0), IDM_TRAY_TOPMOST, L"Always on top");
    AppendMenuW(hMenu, MF_STRING | (g_darkTheme ? MF_CHECKED : 0), IDM_TRAY_DARK, L"Dark theme");
    AppendMenuW(hMenu, MF_STRING | (g_wordWrap ? MF_CHECKED : 0), IDM_TRAY_WORDWRAP, L"Wrap words");
    AppendMenuW(hMenu, MF_STRING | (g_runAtStartup ? MF_CHECKED : 0), IDM_TRAY_STARTUP, L"Start with Windows");
    AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenu, MF_STRING, IDM_TRAY_SHOW, IsWindowVisible(hwnd) ?  L"Hide" : L"Show");
    AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenu, MF_STRING, IDM_TRAY_QUIT, L"Quit");

    // Окно должно быть foreground, иначе меню не закроется по клику вне его области
    SetForegroundWindow(hwnd);
    TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
    DestroyMenu(hMenu);

    PostMessageW(hwnd, WM_NULL, 0, 0);
}

// =============================================================================
//
//                                  ОКНО ABOUT
//
// =============================================================================

static void CloseAbout(HWND hwndAbout)
{
    if (!hwndAbout) return;
    HWND parent = g_hwndMain;
    DestroyWindow(hwndAbout);
    g_hwndAbout = NULL;
    if (g_hAboutFont) { DeleteObject(g_hAboutFont); g_hAboutFont = NULL; }
    if (parent)
    {
        EnableWindow(parent, TRUE);
        SetForegroundWindow(parent);
        HWND hEdit = GetDlgItem(parent, EDIT_ID);
        if (hEdit) SetFocus(hEdit);
    }
}

static LRESULT CALLBACK AboutProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_CREATE:
        {
            const int dpi = GetDpiY();

            NONCLIENTMETRICSW ncm;
            ncm.cbSize = sizeof(ncm);
            SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0);
            g_hAboutFont = CreateFontIndirectW(&ncm.lfMessageFont);

            HWND hText = CreateWindowExW(
                0, L"STATIC",
                L"MiniNote 1.1\r\n\r\n"
                L"Minimal dark notepad for quick notes.\r\n"
                L"Pure Win32. No frameworks, no bloat.\r\n\r\n"
                L"Copyright (C) 2026 Polina \"Aura\" N.\r\n"
                L"Copyright (C) 2026 Julia Nechaevskaya",
                WS_CHILD | WS_VISIBLE | SS_LEFT,
                MulDiv(18, dpi, 96), MulDiv(14, dpi, 96),
                MulDiv(324, dpi, 96), MulDiv(150, dpi, 96),
                hwnd, (HMENU)(INT_PTR)IDC_ABOUT_TEXT, g_hInst, NULL
            );

            HWND hBtn = CreateWindowExW(
                0, L"BUTTON", L"Close",
                WS_CHILD | WS_VISIBLE | BS_OWNERDRAW | BS_DEFPUSHBUTTON,
                MulDiv(132, dpi, 96), MulDiv(193, dpi, 96),
                MulDiv(96, dpi, 96), MulDiv(28, dpi, 96),
                hwnd, (HMENU)(INT_PTR)IDC_ABOUT_CLOSE, g_hInst, NULL
            );

            SendMessageW(hText, WM_SETFONT, (WPARAM)g_hAboutFont, TRUE);
            SendMessageW(hBtn, WM_SETFONT, (WPARAM)g_hAboutFont, TRUE);
            return 0;
        }
        case WM_ERASEBKGND:
        {
            RECT rc;
            GetClientRect(hwnd, &rc);
            FillRect((HDC)wParam, &rc, g_hEditBrush);
            return 1;
        }
        case WM_CTLCOLORSTATIC:
        {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, g_textColor);
            SetBkColor(hdc, g_bgColor);
            return (LRESULT)g_hEditBrush;
        }
        case WM_DRAWITEM:
        {
            LPDRAWITEMSTRUCT dis = (LPDRAWITEMSTRUCT)lParam;
            if (dis->CtlID == IDC_ABOUT_CLOSE)
            {
                BOOL pressed = (dis->itemState & ODS_SELECTED);
                COLORREF btnFace, btnText;
                if (g_darkTheme)
                {
                    btnFace = pressed ? RGB(80, 80, 80) : RGB(55, 55, 55);
                    btnText = DARK_TEXT;
                }
                else
                {
                    btnFace = pressed ? GetSysColor(COLOR_BTNSHADOW) : GetSysColor(COLOR_BTNFACE);
                    btnText = GetSysColor(COLOR_BTNTEXT);
                }

                HBRUSH hBr = CreateSolidBrush(btnFace);
                FillRect(dis->hDC, &dis->rcItem, hBr);
                DeleteObject(hBr);

                HPEN hPen = CreatePen(PS_SOLID, 1, g_darkTheme ? RGB(100, 100, 100) : GetSysColor(COLOR_BTNSHADOW));
                HPEN hOldPen = (HPEN)SelectObject(dis->hDC, hPen);
                HBRUSH hOldBr = (HBRUSH)SelectObject(dis->hDC, GetStockObject(NULL_BRUSH));
                Rectangle(dis->hDC, dis->rcItem.left, dis->rcItem.top, dis->rcItem.right, dis->rcItem.bottom);
                SelectObject(dis->hDC, hOldPen);
                SelectObject(dis->hDC, hOldBr);
                DeleteObject(hPen);

                SetBkMode(dis->hDC, TRANSPARENT);
                SetTextColor(dis->hDC, btnText);
                DrawTextW(dis->hDC, L"Close", -1, &dis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
            break;
        }
        case WM_COMMAND:
        {
            if (LOWORD(wParam) == IDC_ABOUT_CLOSE)
            {
                CloseAbout(hwnd);
                return 0;
            }
            break;
        }
        case WM_CLOSE:
        {
            CloseAbout(hwnd);
            return 0;
        }
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

static void ShowAbout(HWND parent)
{
    if (g_hwndAbout && IsWindow(g_hwndAbout))
    {
        SetForegroundWindow(g_hwndAbout);
        return;
    }

    WNDCLASSEXW tmp;
    if (!GetClassInfoExW(g_hInst, L"MiniNoteAboutClass", &tmp))
    {
        WNDCLASSEXW wc = {0};
        wc.cbSize = sizeof(WNDCLASSEXW);
        wc.style = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc = AboutProc;
        wc.hInstance = g_hInst;
        wc.hCursor = LoadCursor(NULL, IDC_ARROW);
        wc.hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(1));
        wc.hbrBackground = NULL; // фон красим сами в WM_ERASEBKGND
        wc.lpszClassName = L"MiniNoteAboutClass";
        if (!RegisterClassExW(&wc)) return;
    }

    int dpi = GetDpiY();

    // 245x235 - размер КЛИЕНТСКОЙ области. AdjustWindowRectEx добавит заголовок
    // и рамки, иначе контролы (кнопка) уезжают за нижний край окна.
    RECT rcWin = { 0, 0, MulDiv(245, dpi, 96), MulDiv(235, dpi, 96) };
    AdjustWindowRectEx(&rcWin, WS_POPUP | WS_CAPTION, FALSE, 0);
    int W = rcWin.right - rcWin.left;
    int H = rcWin.bottom - rcWin.top;
    int x = CW_USEDEFAULT, y = CW_USEDEFAULT;
    if (parent)
    {
        RECT rc;
        GetWindowRect(parent, &rc);
        x = rc.left + ((rc.right - rc.left) - W) / 2;
        y = rc.top + ((rc.bottom - rc.top) - H) / 2;
    }

    // Если главное окно topmost, About тоже должен быть topmost,
    // иначе оно окажется под главным окном и будет недоступно.
    DWORD exStyle = 0;
    if (parent)
    {
        LONG_PTR parentExStyle = GetWindowLongPtrW(parent, GWL_EXSTYLE);
        if (parentExStyle & WS_EX_TOPMOST)
        {
            exStyle = WS_EX_TOPMOST;
        }
    }

    g_hwndAbout = CreateWindowExW(
        exStyle, L"MiniNoteAboutClass", L"About MiniNote",
        WS_POPUP | WS_CAPTION,
        x, y, W, H,
        parent, NULL, g_hInst, NULL
    );
    if (!g_hwndAbout) return;

    if (parent) EnableWindow(parent, FALSE);

    // Тёмный заголовок окна под стать программе
    if (g_darkTheme)
    {
        if (g_pAllowDarkModeForWindow) g_pAllowDarkModeForWindow(g_hwndAbout, TRUE);
        if (g_pSetWindowTheme) g_pSetWindowTheme(g_hwndAbout, L"Explorer", NULL);
        if (g_pDwmSetWindowAttribute)
        {
            BOOL dark = TRUE;
            g_pDwmSetWindowAttribute(g_hwndAbout, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof(dark));
        }
    }

    ShowWindow(g_hwndAbout, SW_SHOW);
    UpdateWindow(g_hwndAbout);
    SetForegroundWindow(g_hwndAbout);
    HWND hBtn = GetDlgItem(g_hwndAbout, IDC_ABOUT_CLOSE);
    if (hBtn) SetFocus(hBtn);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    // Оболочка пересоздала трей (обычно рестарт explorer.exe) - наша иконка
    // пропала вместе со старым треем, хотя процесс жив. Регистрируем заново.
    // NIM_ADD по тому же uID идемпотентен, RemoveTrayIcon не нужен.
    if (g_uTaskbarCreated && msg == g_uTaskbarCreated)
    {
        AddTrayIcon(hwnd);
        return 0;
    }

    switch (msg)
    {
        case WM_CREATE:
        {
            // RichEdit (Msftedit.dll) вместо EDIT: даёт многоуровневый undo.
            HWND hEdit = CreateWindowExW(
                0, MSFTEDIT_CLASS, L"",
                WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_LEFT | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL,
                0, 0, 100, 100,
                hwnd, (HMENU)(INT_PTR)EDIT_ID, g_hInst, NULL
            );
            // Режим чистого текста: буфер RichEdit не может хранить форматирование,
            // вставка RTF/HTML из других программ приходит как plain text.
            // Ставим до загрузки текста (смена режима на непустом документе
            // с undo-историей может не пройти).
            SendMessageW(hEdit, EM_SETTEXTMODE, TM_PLAINTEXT, 0);
            SendMessageW(hEdit, EM_EXLIMITTEXT, 0, 0x7FFFFFFE);
            SendMessageW(hEdit, EM_SETUNDOLIMIT, 100, 0);
            ApplyWordWrap(hEdit); // перенос строк согласно конфигу
            SendMessageW(hEdit, EM_SETBKGNDCOLOR, FALSE, (LPARAM)g_bgColor);
            ApplyEditorFont(hEdit);

            // Subclass редактора (скролл/зум/вставка/контекстное меню).
            // Используем SetWindowLongPtr (старый способ), а не SetWindowSubclass
            // из comctl32, чтобы не добавлять зависимость на comctl32.lib.
            g_origEditProc = (WNDPROC)SetWindowLongPtrW(hEdit, GWLP_WNDPROC, (LONG_PTR)EditSubclassProc);

            // Загружаем текст из файла
            wchar_t* text = ReadUTF8File(g_dataPath);
            if (text)
            {
                SendMessageW(hEdit, WM_SETTEXT, 0, (LPARAM)text);
                // Запоминаем загруженный текст как «последний сохранённый»,
                // чтобы автосохранение не перезаписало файл при старте.
                g_lastSavedText = text; // передаём владение
                text = NULL;
            }
            g_lastSavedLen = GetEditTextLen(hEdit);

            // Редактор готов: теперь EN_UPDATE может честно считать звёздочку.
            g_editorReady = TRUE;
            UpdateTitle(hwnd);

            // Запускаем таймер автосохранения
            SetTimer(hwnd, TIMER_AUTOSAVE, AUTOSAVE_INTERVAL_MS, NULL);

            // Добавляем иконку в системный трей
            AddTrayIcon(hwnd);
            return 0;
        }
        case WM_SETFOCUS:
        {
            HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
            if (hEdit) SetFocus(hEdit);
            return 0;
        }
        case WM_SIZE:
        {
            HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
            if (hEdit) MoveWindow(hEdit, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
            return 0;
        }
        case WM_TIMER:
        {
            if (wParam == TIMER_AUTOSAVE)
            {
                DoAutoSave(hwnd);
            }
            return 0;
        }
        case WM_TRAYICON:
        {
            if (lParam == WM_RBUTTONUP)
            {
                ShowTrayMenu(hwnd);
                return 0;
            }
            if (lParam == WM_LBUTTONUP)
            {
                ToggleMainWindow(hwnd);
                return 0;
            }
            return 0;
        }
        case WM_SHOWINSTANCE:
        {
            // Второй экземпляр попросил показать окно (повторный запуск exe).
            // Разворачиваем окно из трея, если оно было скрыто.
            ShowMainWindow(hwnd);
            return 0;
        }
        case WM_SYSCOMMAND:
        {
            // Нами добавленные пункты системного меню приходят как
            // WM_SYSCOMMAND с id трея - перенаправляем в WM_COMMAND-диспетчер.
            switch ((WORD)wParam)
            {
                case IDM_TRAY_SHOW: case IDM_TRAY_QUIT: case IDM_TRAY_ABOUT:
                case IDM_TRAY_TOPMOST: case IDM_TRAY_DARK:
                case IDM_TRAY_WORDWRAP: case IDM_TRAY_STARTUP:
                    SendMessageW(hwnd, WM_COMMAND, wParam, 0);
                    return 0;
            }

            // Кнопка "свернуть" прячет окно в трей.
            // Маскирование (& 0xFFF0) для надёжности, Windows может добавлять
            // дополнительные биты к wParam.
            if ((wParam & 0xFFF0) == SC_MINIMIZE)
            {
                HideToTray(hwnd);
                return 0;
            }
            break;
        }
        case WM_INITMENUPOPUP:
        {
            // Обновляем галочки и Show/Hide при каждом открытии системного меню.
            HMENU hSys = GetSystemMenu(hwnd, FALSE);
            if (hSys && (HMENU)wParam == hSys)
            {
                CheckMenuItem(hSys, IDM_TRAY_TOPMOST,  MF_BYCOMMAND | (g_topmost     ? MF_CHECKED : MF_UNCHECKED));
                CheckMenuItem(hSys, IDM_TRAY_DARK,     MF_BYCOMMAND | (g_darkTheme   ? MF_CHECKED : MF_UNCHECKED));
                CheckMenuItem(hSys, IDM_TRAY_WORDWRAP, MF_BYCOMMAND | (g_wordWrap    ? MF_CHECKED : MF_UNCHECKED));
                CheckMenuItem(hSys, IDM_TRAY_STARTUP,  MF_BYCOMMAND | (g_runAtStartup? MF_CHECKED : MF_UNCHECKED));
                ModifyMenuW(hSys, IDM_TRAY_SHOW, MF_BYCOMMAND | MF_STRING, IDM_TRAY_SHOW,
                            IsWindowVisible(hwnd) ? L"Hide" : L"Show");
            }
            break;
        }
        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                // Команды из контекстного меню редактора - нативные сообщения EDIT.
                case WM_UNDO: case WM_CUT: case WM_COPY: case WM_PASTE: case WM_CLEAR:
                {
                    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
                    if (hEdit) SendMessageW(hEdit, LOWORD(wParam), 0, 0);
                    return 0;
                }

                // Изменение содержимого: считаем «грязность» (звёздочку в заголовке).
                // Разницы в длине достаточно; полное сравнение с копиями текста -
                // только когда длины совпали (undo, замена без изменения длины).
                case EDIT_ID:
                {
                    if (HIWORD(wParam) == EN_UPDATE && g_editorReady)
                    {
                        HWND hEdit = (HWND)lParam;
                        BOOL dirty;
                        if (GetEditTextLen(hEdit) != g_lastSavedLen)
                        {
                            dirty = TRUE; // длины уже всё сказали
                        }
                        else
                        {
                            wchar_t* text = GetEditText(hEdit);
                            dirty = text && (g_lastSavedText == NULL ||
                                             wcscmp(text, g_lastSavedText) != 0);
                            free(text);
                        }
                        if (dirty != g_dirty)
                        {
                            g_dirty = dirty;
                            UpdateTitle(hwnd);
                        }
                    }
                    return 0;
                }

                case IDM_SAVE:
                    DoAutoSave(hwnd); // сам сравнит с последним сохранённым
                    return 0;

                case IDM_ZOOM_RESET:
                {
                    // Ctrl+0 - вернуть размер шрифта по умолчанию.
                    g_fontSizePts = DEFAULT_FONT_SIZE_PTS;
                    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
                    if (hEdit) ApplyEditorFont(hEdit);
                    return 0;
                }

                case IDM_DATE_TIME:
                {
                    // F5 - вставить текущие дату и время (формат системной локали).
                    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
                    if (hEdit)
                    {
                        SYSTEMTIME st;
                        GetLocalTime(&st);
                        wchar_t date[64], tim[64], buf[160];
                        int nd = GetDateFormatW(LOCALE_USER_DEFAULT, DATE_SHORTDATE, &st, NULL, date, 64);
                        int nt = GetTimeFormatW(LOCALE_USER_DEFAULT, TIME_NOSECONDS, &st, NULL, tim, 64);
                        if (nd > 0 && nt > 0 &&
                            swprintf_s(buf, sizeof(buf) / sizeof(buf[0]), L"%s %s", date, tim) > 0)
                            SendMessageW(hEdit, EM_REPLACESEL, TRUE, (LPARAM)buf); // undoable
                    }
                    return 0;
                }

                case IDM_SELECT_ALL:
                {
                    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
                    if (hEdit) SendMessageW(hEdit, EM_SETSEL, 0, -1);
                    return 0;
                }

                case IDM_TRAY_ABOUT:
                    ShowAbout(hwnd);
                    return 0;

                case IDM_TRAY_TOPMOST:
                    g_topmost = !g_topmost;
                    SetWindowPos(hwnd, g_topmost ? HWND_TOPMOST : HWND_NOTOPMOST,
                                 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
                    return 0;

                case IDM_TRAY_DARK:
                    g_darkTheme = !g_darkTheme;
                    ApplyDarkTheme(hwnd, g_darkTheme);
                    return 0;

                case IDM_TRAY_WORDWRAP:
                {
                    g_wordWrap = !g_wordWrap;
                    HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
                    if (hEdit) ApplyWordWrap(hEdit);
                    return 0;
                }

                case IDM_TRAY_STARTUP:
                {
                    g_runAtStartup = !g_runAtStartup;
                    if (StartupSet(g_runAtStartup))
                    {
                        CFG_Save(g_iniPath); // фиксируем флаг и в ini сразу
                    }
                    else
                    {
                        g_runAtStartup = !g_runAtStartup; // реестр не дал - откатываем галку
                        MessageBoxW(hwnd, L"Cannot change autostart registry entry.",
                                    L"MiniNote", MB_OK | MB_ICONWARNING);
                    }
                    return 0;
                }

                case IDM_TRAY_SHOW:
                    ToggleMainWindow(hwnd);
                    return 0;

                case IDM_TRAY_QUIT:
                    g_quitRequested = TRUE;
                    PostMessageW(hwnd, WM_CLOSE, 0, 0);
                    return 0;
            }
            return 0;
        }
        case WM_CLOSE:
        {
            // Крестик прячет в трей. Настоящее закрытие только через Quit.
            if (!g_quitRequested)
            {
                HideToTray(hwnd);
                return 0;
            }
            KillTimer(hwnd, TIMER_AUTOSAVE);
            DoAutoSave(hwnd); // Финальное сохранение
            DestroyWindow(hwnd);
            return 0;
        }
        case WM_DESTROY:
        {
            RemoveTrayIcon();
            CaptureWindowPlacement(hwnd);
            CFG_Save(g_iniPath);

            // Убираем subclass RichEdit перед уничтожением окна.
            HWND hEdit = GetDlgItem(hwnd, EDIT_ID);
            if (hEdit && g_origEditProc)
            {
                SetWindowLongPtrW(hEdit, GWLP_WNDPROC, (LONG_PTR)g_origEditProc);
                g_origEditProc = NULL;
            }

            if (g_hEditBrush) { DeleteObject(g_hEditBrush); g_hEditBrush = NULL; }
            if (g_lastSavedText) { free(g_lastSavedText); g_lastSavedText = NULL; }

            PostQuitMessage(0);
            return 0;
        }
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// =============================================================================
//
//                                ОСНОВНОЙ ЦИКЛ
//
// =============================================================================

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow)
{
    (void)hPrevInstance;

    // Запуск из автозапуска («exe" /tray»): окно не показываем, сразу трей.
    BOOL startInTray = (wcsstr(lpCmdLine, STARTUP_TRAY_ARG) != NULL);

    // Запрет второго экземпляра: если мьютекс уже создан, то программа запущена.
    // Просим существующее окно показаться и тихо выходим, закрыв хэндл мьютекса
    // (в нормальном потоке хэндл не закрываем, он живёт до завершения процесса,
    // иначе второй экземпляр смог бы запуститься).
    HANDLE hMutex = CreateMutexW(NULL, FALSE, SINGLE_INSTANCE_MUTEX);
    if (hMutex && GetLastError() == ERROR_ALREADY_EXISTS)
    {
        HWND hExisting = FindWindowW(L"MiniNoteClass", NULL);
        if (hExisting && !startInTray)
        {
            // Этот экземпляр получил право "быть на переднем плане" от
            // запускающего процесса (клик по закреплённой иконке - это explorer),
            // и делегирует его уже запущенному экземпляру. Иначе его
            // SetForegroundWindow блокируется foreground-локом Windows.
            DWORD pidExisting = 0;
            GetWindowThreadProcessId(hExisting, &pidExisting);
            if (pidExisting) AllowSetForegroundWindow(pidExisting);
            SendMessageW(hExisting, WM_SHOWINSTANCE, 0, 0);
        }
        CloseHandle(hMutex);
        return 0;
    }

    InitDarkModeAPI();
    InitFontDefaults();
    InitPaths();

    // Номер широковещательного сообщения "трей пересоздан" (см. WndProc).
    g_uTaskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");

    if (!CFG_Load(g_iniPath))
    {
        CFG_Save(g_iniPath);
    }
    CFG_Check();

    // Самозалечивание автозапуска: ini - желаемое состояние, реестр - реальное.
    if (g_runAtStartup)
    {
        // Нужно «вкл»: молча перезаписываем, если ключа нет или путь устарел
        // (например после переезда exe в другую папку).
        if (!StartupIsEnabled() || !StartupPathCurrent())
            StartupSet(TRUE);
    }
    else if (StartupIsEnabled())
    {
        // В реестре добавлено вручную, а в ini выключено - не удаляем за
        // пользователем, а отражаем реальное состояние в флаге и меню.
        g_runAtStartup = TRUE;
    }

    // RichEdit живёт в отдельной DLL, грузим до создания окна, иначе
    // CreateWindowExW с классом MSFTEDIT_CLASS вернёт NULL.
    LoadLibraryW(L"Msftedit.dll");

    g_bgColor = g_darkTheme ? DARK_BG : LIGHT_BG;
    g_textColor = g_darkTheme ? DARK_TEXT : LIGHT_TEXT;
    RecreateEditBrush();

    g_hInst = hInstance;

    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(1));
    wc.hIconSm = (HICON)LoadImageW(hInstance, MAKEINTRESOURCEW(1), IMAGE_ICON,
                                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszMenuName = NULL; 
    wc.lpszClassName = L"MiniNoteClass";

    if (!RegisterClassExW(&wc)) return 0;

    int winX = CW_USEDEFAULT, winY = CW_USEDEFAULT;
    int winW = CW_USEDEFAULT, winH = CW_USEDEFAULT;
    if (g_winW > 0 && g_winH > 0)
    {
        RECT rcCheck = { g_winX, g_winY, g_winX + g_winW, g_winY + g_winH };
        if (MonitorFromRect(&rcCheck, MONITOR_DEFAULTTONULL) != NULL)
        {
            winX = g_winX;
            winY = g_winY;
            winW = g_winW;
            winH = g_winH;
        }
    }

    // Resizable за края (WS_THICKFRAME), без кнопки "развернуть".
    // WS_MINIMIZEBOX обязателен: без него Windows не считает окно сворачиваемым
    // и клик по кнопке на панели задач не шлёт SC_MINIMIZE (окно "не сворачивается").
    // Сам сворачиваем не в задачу, а в трей - см. перехват SC_MINIMIZE в WndProc.
    // Крестик (WS_SYSMENU) как и раньше прячет окно в трей.
    HWND hwnd = CreateWindowExW(
        0, L"MiniNoteClass", L"MiniNote",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME | WS_MINIMIZEBOX,
        winX, winY, winW, winH,
        NULL, NULL, hInstance, NULL
    );

    if (!hwnd) return 0;

    g_hwndMain = hwnd;

    // Системное меню (иконка заголовка / Alt+Space) зеркалим с трея.
    // Крестик прячет в трей, поэтому SC_CLOSE честно назван "Minimize to tray";
    // SC_MINIMIZE из меню убран - он дублировал бы его по смыслу (кнопка в
    // заголовке при этом работает: шлёт SC_MINIMIZE напрямую, минуя меню).
    // ВАЖНО: SC_MOVE и SC_SIZE оставляем, иначе Windows блокирует
    // перетаскивание и ресайз окна.
    HMENU hSysMenu = GetSystemMenu(hwnd, FALSE);
    if (hSysMenu)
    {
        RemoveMenu(hSysMenu, SC_RESTORE,   MF_BYCOMMAND);
        RemoveMenu(hSysMenu, SC_MAXIMIZE,  MF_BYCOMMAND);
        // ВАЖНО: SC_MINIMIZE/SC_CLOSE нельзя удалять - Windows по их наличию
        // решает, активны ли кнопки в заголовке (удаление SC_MINIMIZE
        // блокирует кнопку "свернуть"). Только переименовываем.
        ModifyMenuW(hSysMenu, SC_MINIMIZE, MF_BYCOMMAND | MF_STRING, SC_MINIMIZE, L"Minimize to tray");
        ModifyMenuW(hSysMenu, SC_CLOSE,    MF_BYCOMMAND | MF_STRING, SC_CLOSE,    L"Hide to tray");

        AppendMenuW(hSysMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hSysMenu, MF_STRING, IDM_TRAY_ABOUT, L"About");
        AppendMenuW(hSysMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hSysMenu, MF_STRING | (g_topmost ? MF_CHECKED : 0), IDM_TRAY_TOPMOST, L"Always on top");
        AppendMenuW(hSysMenu, MF_STRING | (g_darkTheme ? MF_CHECKED : 0), IDM_TRAY_DARK, L"Dark theme");
        AppendMenuW(hSysMenu, MF_STRING | (g_wordWrap ? MF_CHECKED : 0), IDM_TRAY_WORDWRAP, L"Wrap words");
        AppendMenuW(hSysMenu, MF_STRING | (g_runAtStartup ? MF_CHECKED : 0), IDM_TRAY_STARTUP, L"Start with Windows");
        AppendMenuW(hSysMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hSysMenu, MF_STRING, IDM_TRAY_SHOW, IsWindowVisible(hwnd) ? L"Hide" : L"Show");
        AppendMenuW(hSysMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hSysMenu, MF_STRING, IDM_TRAY_QUIT, L"Quit");
    }

    if (g_darkTheme) ApplyDarkTheme(hwnd, TRUE);

    // Кнопки "развернуть" больше нет, развёрнутое состояние не восстанавливаем,
    // иначе окно открылось бы maximized без возможности вернуть нормальный размер.
    // При /tray не показываем вовсе - окно живёт только в трее, до вызова.
    if (!startInTray)
    {
        ShowWindow(hwnd, nCmdShow);
        UpdateWindow(hwnd);
    }

    // Применяем "Always on top" из конфига ПОСЛЕ ShowWindow,
    // иначе флаг z-order потеряется при показе окна.
    if (g_topmost) SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    // Таблица горячих клавиш: Ctrl+A (выделить всё), Ctrl+S (сохранить), 
    // Ctrl+0 (сброс размера шрифта), F5 (вставить дату и время).
    ACCEL acc[] =
    {
        { FCONTROL | FVIRTKEY, 'A', IDM_SELECT_ALL },
        { FCONTROL | FVIRTKEY, 'S', IDM_SAVE },
        { FCONTROL | FVIRTKEY, '0', IDM_ZOOM_RESET },
        { FCONTROL | FVIRTKEY, VK_NUMPAD0, IDM_ZOOM_RESET },
        { FVIRTKEY, VK_F5, IDM_DATE_TIME },
    };
    HACCEL hAccel = CreateAcceleratorTableW(acc, 5);

    // Флаг-крышка: когда WM_KEYDOWN зум-клавиши съеден, за ним из того же
    // нажатия приходит WM_CHAR с управляющим кодом (Ctrl маскирует символы
    // через & 0x1F: '-' → 0x1F, '=' → 0x1D, '+' → 0x0B и т.п.). Если его
    // не проглотить, RichEdit вставит невидимый мусор.
    BOOL swallowZoomChar = FALSE;

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0))
    {
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_ESCAPE)
        {
            // ESC: если открыт About, закрываем его, иначе прячем окно в трей.
            // Ловим здесь, в цикле сообщений, а не в WndProc: фокус обычно на
            // EDIT, и до оконной процедуры нажатие просто не дошло бы.
            if (g_hwndAbout && IsWindow(g_hwndAbout))
            {
                CloseAbout(g_hwndAbout);
            }
            else
            {
                HideToTray(hwnd);
            }
            continue;
        }

        // Ctrl+«+»/Ctrl+«-» - клавиатурный зум шрифта. Смотрим на виртуальные
        // клавиши в WM_KEYDOWN, а НЕ на символы.
        if (msg.message == WM_KEYDOWN && (GetKeyState(VK_CONTROL) & 0x8000) &&
            msg.hwnd == GetDlgItem(hwnd, EDIT_ID))
        {
            int zoomStep = 0;
            if (msg.wParam == VK_OEM_PLUS || msg.wParam == VK_ADD) zoomStep = 1;
            else if (msg.wParam == VK_OEM_MINUS || msg.wParam == VK_SUBTRACT) zoomStep = -1;
            if (zoomStep)
            {
                int newSize = BETWEEN(4, 96, g_fontSizePts + zoomStep);
                if (newSize != g_fontSizePts)
                {
                    g_fontSizePts = newSize;
                    ApplyEditorFont(GetDlgItem(hwnd, EDIT_ID));
                }
                swallowZoomChar = TRUE; // следующий WM_CHAR - управляющий мусор
                continue;
            }
        }
        if (msg.message == WM_CHAR && swallowZoomChar)
        {
            // Снимаем флаг в любом случае, но молча проглатываем только
            // управляющий мусор (< 0x20) - реальный символ терять нельзя.
            swallowZoomChar = FALSE;
            if (msg.wParam < 0x20) continue;
        }

        if (!TranslateAcceleratorW(hwnd, hAccel, &msg))
        {
            // RichEdit группирует весь непрерывный ввод в одну undo-запись.
            // Чтобы Ctrl+Z откатывал по словам, ставим границу undo-группы
            // ПЕРЕД вводом разделителя (пробел / перевод строки / табуляция).
            if (msg.message == WM_CHAR && msg.hwnd == GetDlgItem(hwnd, EDIT_ID))
            {
                wchar_t ch = (wchar_t)msg.wParam;
                if (ch == L' ' || ch == L'\r' || ch == L'\n' || ch == L'\t')
                {
                    SendMessageW(msg.hwnd, EM_STOPGROUPTYPING, 0, 0);
                }
            }

            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }

    DestroyAcceleratorTable(hAccel);

    return (int)msg.wParam;
}
