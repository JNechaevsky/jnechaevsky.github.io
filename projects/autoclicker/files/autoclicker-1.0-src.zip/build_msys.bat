@echo off
setlocal

rem ---------------------------------------------------------------------------
rem Auto Clicker - build with MSYS2 / MinGW-w64 (GCC) or clang.
rem
rem Adjust MSYS_ROOT if your MSYS2 lives somewhere else. The script is a
rem convenience wrapper for people without Visual Studio; Build Tools remains
rem the recommended toolchain.
rem ---------------------------------------------------------------------------

if not defined MSYS_ROOT set "MSYS_ROOT=R:\MSYS"
if not exist "%MSYS_ROOT%\mingw64\bin\gcc.exe" (
    echo [error] gcc.exe not found under %MSYS_ROOT%\mingw64\bin
    exit /b 1
)

set "PATH=%MSYS_ROOT%\mingw64\bin;%MSYS_ROOT%\usr\bin;%PATH%"

echo [1/2] Compiling resources...
windres autoclicker.rc -O coff -o autoclicker.res
if errorlevel 1 goto fail

echo [2/2] Compiling and linking...
gcc -std=c99 -O2 -Wall -Wextra -mwindows -DUNICODE -D_UNICODE -municode ^
    src\main.c src\ui.c src\theme.c src\config.c src\clicker.c src\hotkey.c ^
    autoclicker.res -o autoclicker.exe ^
    -luser32 -lgdi32 -lshell32 -ladvapi32 -lwinmm -lcomctl32 -ldwmapi
if errorlevel 1 goto fail

echo.
echo Build finished: autoclicker.exe
exit /b 0

:fail
echo.
echo Build failed.
exit /b 1
