﻿// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef AC_CLICKER_H
#define AC_CLICKER_H

#include "common.h"

typedef enum
{
    AC_STATE_IDLE = 0,
    AC_STATE_RUNNING,
    AC_STATE_STOPPING
} AcRunState;

typedef struct
{
    AcSettings settings;    // snapshot taken at start, never touched by the UI
    UINT       totalClicks; // 0 => unlimited
    POINT      target;      // resolved once, in physical pixels
    BOOL       useTarget;   // FALSE => follow the live cursor
} AcRunJob;

// Starts the worker thread. Returns FALSE if already running or if windows
// refuses to grant the requested timer resolution.
BOOL AcClickerStart(const AcRunJob *job);

// Asks the worker to stop as soon as possible. Non-blocking.
void AcClickerStop(void);

// Blocks until the worker thread has fully exited.
void AcClickerWait(void);

BOOL AcClickerIsRunning(void);

// Reaps a worker that finished by itself (finite repeat count).
BOOL AcClickerPoll(void);
AcRunState AcClickerGetState(void);

// Number of clicks completed in the current / last run.
unsigned long long AcClickerGetClickCount(void);

// Timestamp (GetTickCount64) when the current run started, or 0.
ULONGLONG AcClickerGetStartTick(void);

#endif // AC_CLICKER_H
