// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - settings persistence.
//
// The INI lives next to autoclicker.exe. That is the only location: the whole
// folder can be moved or copied without leaving anything behind in the system.
//

#include "common.h"
#include "config.h"
#include "theme.h"

static wchar_t g_dir[MAX_PATH];   // folder that holds autoclicker.exe
static wchar_t g_path[MAX_PATH];  // portable autoclicker.ini

static BOOL FileExists(const wchar_t *path)
{
    DWORD attr = GetFileAttributesW(path);
    return (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) ? TRUE : FALSE;
}

static void BuildPaths(void)
{
    wchar_t exe[MAX_PATH];
    DWORD   len;

    g_dir[0]  = L'\0';
    g_path[0] = L'\0';

    len = GetModuleFileNameW(NULL, exe, MAX_PATH);
    if (len == 0 || len >= MAX_PATH)
        return;

    {
        wchar_t *slash = wcsrchr(exe, L'\\');

        if (slash != NULL)
            *slash = L'\0';
    }

    wcsncpy(g_dir, exe, MAX_PATH - 1);
    g_dir[MAX_PATH - 1] = L'\0';

    _snwprintf(g_path, MAX_PATH, L"%s\\%s", g_dir, AC_CONFIG_FILE);
    g_path[MAX_PATH - 1] = L'\0';
}

void AcConfigGetPath(wchar_t *buf, int cch)
{
    if (cch <= 0) return;
    if (g_path[0] == L'\0')
        BuildPaths();
    wcsncpy(buf, g_path, (size_t)cch - 1);
    buf[cch - 1] = L'\0';
}

// Lightweight key=value reader. Tolerates CRLF, comments (';' and '#'),
// surrounding whitespace and is case-insensitive on keys.
static BOOL ReadKey(const wchar_t *path, const wchar_t *key, wchar_t *out, int cch)
{
    wchar_t line[512];
    FILE   *fp = NULL;
    BOOL    found = FALSE;

    out[0] = L'\0';
    if (_wfopen_s(&fp, path, L"rt") != 0 || fp == NULL)
        return FALSE;

    while (fgetws(line, 512, fp))
    {
        wchar_t *p = line;
        wchar_t *eq;

        if (*p == 0xFEFF) p++;                       // BOM
        while (*p == L' ' || *p == L'\t') p++;
        if (*p == L';' || *p == L'#' || *p == L'[' || *p == L'\r' || *p == L'\n' || *p == 0)
            continue;

        eq = wcschr(p, L'=');
        if (eq == NULL)
            continue;

        *eq = L'\0';

        // trim key
        {
            wchar_t *end = eq - 1;
            while (end >= p && (*end == L' ' || *end == L'\t')) *end-- = L'\0';
        }

        if (_wcsicmp(p, key) != 0)
            continue;

        p = eq + 1;
        while (*p == L' ' || *p == L'\t') p++;

        // trim trailing whitespace
        {
            size_t len = wcslen(p);
            while (len > 0 && (p[len - 1] == L'\r' || p[len - 1] == L'\n' ||
                               p[len - 1] == L' '  || p[len - 1] == L'\t'))
                p[--len] = L'\0';
        }

        wcsncpy(out, p, (size_t)cch - 1);
        out[cch - 1] = L'\0';
        found = TRUE;
        break;
    }

    fclose(fp);
    return found;
}

static int ReadInt(const wchar_t *path, const wchar_t *key, int fallback)
{
    wchar_t buf[64];
    if (!ReadKey(path, key, buf, 64) || buf[0] == L'\0')
        return fallback;
    return (int)wcstol(buf, NULL, 10);
}

static BOOL ReadBool(const wchar_t *path, const wchar_t *key, BOOL fallback)
{
    wchar_t buf[64];
    if (!ReadKey(path, key, buf, 64) || buf[0] == L'\0')
        return fallback;
    if (!_wcsicmp(buf, L"1") || !_wcsicmp(buf, L"true") || !_wcsicmp(buf, L"yes"))
        return TRUE;
    if (!_wcsicmp(buf, L"0") || !_wcsicmp(buf, L"false") || !_wcsicmp(buf, L"no"))
        return FALSE;
    return fallback;
}

static void ReadSettings(const wchar_t *path, AcSettings *out)
{
    wchar_t value[128];
    int     interval = AC_AC_DEFAULT_INTERVAL;

    if (out == NULL) return;


    // Interval: stored as "hours", "mins", "secs", "msecs" so the file stays
    // human editable, then collapsed into a single millisecond count.
    {
        int h  = ReadInt(path, L"hours", -1);
        int m  = ReadInt(path, L"mins",  -1);
        int s  = ReadInt(path, L"secs",  -1);
        int ms = ReadInt(path, L"msecs", -1);

        if (h >= 0 || m >= 0 || s >= 0 || ms >= 0)
        {
            long long total = 0;
            if (h  > 0) total += (long long)h  * 3600LL * 1000LL;
            if (m  > 0) total += (long long)m  *   60LL * 1000LL;
            if (s  > 0) total += (long long)s  *         1000LL;
            /* milliseconds are added even when zero: they are the primary
               unit of the field, hours/mins/secs are optional extras */
            total += (long long)(ms > 0 ? ms : 0);
            if (total <= 0)
                total = AC_AC_DEFAULT_INTERVAL;
            if (total > (long long)AC_AC_MAX_INTERVAL_MS)
                total = (long long)AC_AC_MAX_INTERVAL_MS;
            interval = (int)total;
        }
    }
    out->intervalMs = (UINT)AcClampInt(interval, AC_AC_MIN_INTERVAL_MS, (int)AC_AC_MAX_INTERVAL_MS);

    out->button = (AcMouseButton)AcClampInt(ReadInt(path, L"button", AC_BUTTON_LEFT),
                                           0, AC_BUTTON_COUNT - 1);
    out->clickType = (AcClickType)AcClampInt(ReadInt(path, L"click_type", AC_CLICK_SINGLE),
                                             0, AC_CLICK_TYPE_COUNT - 1);

    out->repeatUntilStopped = ReadBool(path, L"repeat_until_stopped", TRUE);
    out->repeatCount = AcClampInt(ReadInt(path, L"repeat_count", AC_AC_DEFAULT_REPEAT),
                                  1, AC_AC_MAX_REPEAT);

    out->cursorMode = (AcCursorMode)AcClampInt(ReadInt(path, L"cursor_mode", AC_CURSOR_CURRENT),
                                               0, 1);

    out->fixedPoint.x = ReadInt(path, L"pos_x", 0);
    out->fixedPoint.y = ReadInt(path, L"pos_y", 0);

    out->hotkeyVk   = (UINT)AcClampInt(ReadInt(path, L"hotkey_vk", VK_F6), 0, 0xFF);
    out->hotkeyMods = (UINT)AcClampInt(ReadInt(path, L"hotkey_mods", 0), 0, 0xFF);
    if (ReadKey(path, L"hotkey", value, 128))
    {
        // reserved for a future human readable format
    }
}


void AcConfigLoad(AcSettings *out)
{
    if (out == NULL) return;

    BuildPaths();

    if (g_path[0] != L'\0' && FileExists(g_path))
    {
        ReadSettings(g_path, out);
        return;
    }

    out->intervalMs         = AC_AC_DEFAULT_INTERVAL;
    out->button             = AC_BUTTON_LEFT;
    out->clickType          = AC_CLICK_SINGLE;
    out->repeatUntilStopped = TRUE;
    out->repeatCount        = AC_AC_DEFAULT_REPEAT;
    out->cursorMode         = AC_CURSOR_CURRENT;
    out->fixedPoint.x       = 0;
    out->fixedPoint.y       = 0;
    out->hotkeyVk           = VK_F6;
    out->hotkeyMods         = 0;
}

static BOOL WriteSettings(const wchar_t *path, const AcSettings *in)
{
    wchar_t tmp[MAX_PATH];
    FILE   *fp = NULL;
    UINT    ms;
    int     h, m, s, rem;

    if (in == NULL) return FALSE;

    if (path == NULL || path[0] == L'\0')
        return FALSE;

    _snwprintf(tmp, MAX_PATH, L"%s.tmp", path);
    tmp[MAX_PATH - 1] = L'\0';

    if (_wfopen_s(&fp, tmp, L"wt") != 0 || fp == NULL)
        return FALSE;

    fwprintf(fp, L"; Auto Clicker %s - portable settings\n", AC_APP_VERSION);
    fwprintf(fp, L"; Safe to edit by hand, but the app rewrites it on exit.\n\n");

    ms  = in->intervalMs;
    h   = (int)(ms / 3600000u);
    ms %= 3600000u;
    m   = (int)(ms / 60000u);
    ms %= 60000u;
    s   = (int)(ms / 1000u);
    rem = (int)(ms % 1000u);

    fwprintf(fp, L"hours=%d\n", h);
    fwprintf(fp, L"mins=%d\n",  m);
    fwprintf(fp, L"secs=%d\n",  s);
    fwprintf(fp, L"msecs=%d\n\n", rem);

    fwprintf(fp, L"button=%d\n",     (int)in->button);
    fwprintf(fp, L"click_type=%d\n", (int)in->clickType);

    fwprintf(fp, L"repeat_until_stopped=%d\n", in->repeatUntilStopped ? 1 : 0);
    fwprintf(fp, L"repeat_count=%d\n\n", in->repeatCount);

    fwprintf(fp, L"cursor_mode=%d\n", (int)in->cursorMode);
    fwprintf(fp, L"pos_x=%ld\n", in->fixedPoint.x);
    fwprintf(fp, L"pos_y=%ld\n\n", in->fixedPoint.y);

    fwprintf(fp, L"hotkey_vk=%u\n", in->hotkeyVk);
    fwprintf(fp, L"hotkey_mods=%u\n", in->hotkeyMods);

    fclose(fp);

    if (!MoveFileExW(tmp, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
    {
        DeleteFileW(tmp);
        return FALSE;
    }

    return TRUE;
}
BOOL AcConfigSave(const AcSettings *in)
{
    if (in == NULL) return FALSE;

    BuildPaths();
    if (g_path[0] == L'\0')
        return FALSE;

    return WriteSettings(g_path, in);
}
