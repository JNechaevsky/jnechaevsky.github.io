// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - common definitions shared by all modules.
//

#ifndef AC_COMMON_H
#define AC_COMMON_H

#include <windows.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// ---------------------------------------------------------------------------
// Application identity
// ---------------------------------------------------------------------------

#define AC_APP_NAME      L"Auto Clicker"
#define AC_APP_VERSION   L"1.0"
#define AC_WINDOW_CLASS  L"AutoClickerWindow"
#define AC_CONFIG_FILE   L"autoclicker.ini"

// ---------------------------------------------------------------------------
// Bounds and defaults
// ---------------------------------------------------------------------------

#define AC_AC_MIN_INTERVAL_MS   1
#define AC_AC_MAX_INTERVAL_MS   (24u * 60u * 60u * 1000u)
#define AC_AC_DEFAULT_INTERVAL  100
#define AC_AC_DEFAULT_REPEAT    1
#define AC_AC_MAX_REPEAT        999999

#define AC_PICK_DELAY_MS        3000

// ---------------------------------------------------------------------------
// Window geometry, in 96 DPI logical units
// ---------------------------------------------------------------------------

#define AC_BASE_W        480
#define AC_BASE_H        330
#define AC_MIN_W         AC_BASE_W
#define AC_MIN_H         AC_BASE_H

// ---------------------------------------------------------------------------
// Mouse buttons and click types
// ---------------------------------------------------------------------------

typedef enum
{
    AC_BUTTON_LEFT = 0,
    AC_BUTTON_RIGHT,
    AC_BUTTON_MIDDLE,
    AC_BUTTON_COUNT
} AcMouseButton;

typedef enum
{
    AC_CLICK_SINGLE = 0,
    AC_CLICK_DOUBLE,
    AC_CLICK_TYPE_COUNT
} AcClickType;

// ---------------------------------------------------------------------------
// Cursor mode
// ---------------------------------------------------------------------------

typedef enum
{
    AC_CURSOR_CURRENT = 0,
    AC_CURSOR_FIXED
} AcCursorMode;

// ---------------------------------------------------------------------------
// Settings (persisted between runs)
// ---------------------------------------------------------------------------

typedef struct
{
    UINT           intervalMs;
    AcMouseButton  button;
    AcClickType    clickType;
    BOOL           repeatUntilStopped;
    int            repeatCount;
    AcCursorMode   cursorMode;
    POINT          fixedPoint;
    UINT           hotkeyVk;    // 0 = no hotkey
    UINT           hotkeyMods;  // MOD_* flags, 0 = no modifiers
} AcSettings;

// ---------------------------------------------------------------------------
// Visual theme (all colors in 0x00BBGGRR, i.e. RGB() macro order)
// ---------------------------------------------------------------------------

typedef struct
{
    COLORREF bg;           // window / panel background
    COLORREF panel;        // grouped section fill
    COLORREF border;       // section border
    COLORREF field;        // edit field background
    COLORREF fieldBorder;  // edit field border
    COLORREF button;       // button face
    COLORREF buttonHover;  // button hover face
    COLORREF buttonDown;   // button pressed face
    COLORREF text;         // primary text
    COLORREF textDim;      // secondary text
    COLORREF textDisabled; // disabled text
    COLORREF accent;       // accent color (radio dot, focus rings)
    COLORREF accentSoft;   // accent on hover
    COLORREF accentText;   // text on accent background
    COLORREF track;        // slider / scrollbar track
    COLORREF selection;    // edit selection background
    COLORREF accentBorder; // accent-colored outline on hover
    COLORREF closeHover;   // window close button hover
} AcTheme;

extern AcSettings g_settings;
extern AcTheme    g_theme;

// ---------------------------------------------------------------------------
// Metrics, recomputed on every DPI change
// ---------------------------------------------------------------------------

typedef struct
{
    UINT  dpi;
    int   s;      // scale for coordinates (round(base * dpi / 96))
    int   fontS;  // scale for font sizes (floor(base * dpi / 96))
    HFONT font;
    HFONT fontBold;
    HFONT fontSmall;
    HFONT fontSmallBold;
    int   lineH;
    int   smallLineH;
    int   pad;
    int   sectionTitleH;
    int   rowH;
    int   buttonH;
    int   editPadX;
    int   checkBox;
    int   radio;
    int   gutter;
} AcMetrics;

extern AcMetrics g_metrics;
extern HINSTANCE g_instance;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

int  AcScale(int base);
int  AcScaleFont(int base);
int  AcClampInt(int v, int lo, int hi);
void AcWideToAnsi(const wchar_t *src, char *dst, int dstSize);
BOOL AcIsHighContrast(void);
BOOL AcDarkModeEnabled(void);

#endif // AC_COMMON_H
