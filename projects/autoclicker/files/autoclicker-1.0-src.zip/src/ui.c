// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - self drawn control surface.
//
// Everything inside the client area is painted by hand. That is the only way
// to get a genuinely consistent dark UI: the stock EDIT / BUTTON / COMBOBOX
// classes leak light system colors in a dozen places, and mixing themed and
// unthemed controls looks worse than drawing all of them.
//
// Layers: layout (rectangles), painting (pure GDI), input (mutates g_ui and
// asks the owner window to react through the notification callback).
//

#include "common.h"
#include "theme.h"
#include "ui.h"
#include "ui_id.h"
#include "hotkey.h"

#define AC_CARET_BLINK_MS 530

typedef struct
{
    RECT rc;
    BOOL enabled;
    BOOL hover;
    BOOL pressed;
} AcBox;

AcUiState g_ui;

static AcBox       g_box[ACW_COUNT];
static RECT        g_popupRc;
static RECT        g_statusRc;
static int         g_focus     = -1;
static int         g_hot       = -1;
static int         g_pressed   = -1;
static int         g_editPos   = 0;
static BOOL        g_zeroSlot  = FALSE;  // typing replaces a lone "0"
static BOOL        g_recording = FALSE;
static int         g_clientW   = 0;
static int         g_clientH   = 0;
static DWORD       g_caretTick = 0;
static BOOL        g_caretOn   = TRUE;
static AcUiStatus  g_status;
static AcUiNotify  g_notify    = NULL;

static RECT        g_secInterval;
static RECT        g_secOptions;
static RECT        g_secRepeat;
static RECT        g_secCursor;
static RECT        g_rcInterval[4];
static RECT        g_rcIntervalLabel[4];
static RECT        g_rcButtonLabel;
static RECT        g_rcClickLabel;
static RECT        g_rcRepeatLabel;
static RECT        g_rcRepeatTimes;
static RECT        g_rcUntilStopped;
static RECT        g_rcCurLoc;
static RECT        g_rcFixedLoc;
static RECT        g_rcPosXLabel;
static RECT        g_rcPosYLabel;

static const wchar_t *kIntervalUnits[4] = { L"hours", L"mins", L"secs", L"ms" };
static const wchar_t *kButtonNames[AC_BUTTON_COUNT] = { L"Left", L"Right", L"Middle" };
static const wchar_t *kClickNames[AC_CLICK_TYPE_COUNT] = { L"Single", L"Double" };

// ---------------------------------------------------------------------------
// Interval conversion (milliseconds <-> h/m/s/ms components)
// ---------------------------------------------------------------------------

void AcIntervalSplit(UINT totalMs, AcIntervalParts *out)
{
    UINT ms = totalMs;

    out->hours = (int)(ms / 3600000u); ms %= 3600000u;
    out->mins  = (int)(ms / 60000u);   ms %= 60000u;
    out->secs  = (int)(ms / 1000u);
    out->msecs = (int)(ms % 1000u);
}

UINT AcIntervalJoin(const AcIntervalParts *in)
{
    long long total = 0;

    total += (long long)in->hours * 3600000LL;
    total += (long long)in->mins  *   60000LL;
    total += (long long)in->secs  *    1000LL;
    total += (long long)in->msecs;

    if (total > (long long)AC_AC_MAX_INTERVAL_MS)
        total = (long long)AC_AC_MAX_INTERVAL_MS;

    return (UINT)total;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static RECT RectL(int l, int t, int r, int b)
{
    RECT rc;
    rc.left = l; rc.top = t; rc.right = r; rc.bottom = b;
    return rc;
}

static int RectH(const RECT *rc) { return rc->bottom - rc->top; }

static BOOL Hit(const RECT *rc, int x, int y)
{
    return (x >= rc->left && x < rc->right && y >= rc->top && y < rc->bottom) ? TRUE : FALSE;
}

static void InsetRect(RECT *rc, int dx, int dy)
{
    rc->left += dx; rc->right -= dx;
    rc->top  += dy; rc->bottom -= dy;
}

static BOOL IsIntervalField(int id)
{
    return (id >= ACW_INT_H && id <= ACW_INT_MS) ? TRUE : FALSE;
}

static BOOL IsTextField(int id)
{
    return (IsIntervalField(id) || id == ACW_REPEAT ||
            id == ACW_POS_X     || id == ACW_POS_Y) ? TRUE : FALSE;
}

static BOOL IsCombo(int id)
{
    return (id == ACW_BUTTON || id == ACW_CLICK_TYPE) ? TRUE : FALSE;
}

static wchar_t *FieldText(int id)
{
    switch (id)
    {
    case ACW_INT_H:  return g_ui.hours;
    case ACW_INT_M:  return g_ui.mins;
    case ACW_INT_S:  return g_ui.secs;
    case ACW_INT_MS: return g_ui.msecs;
    case ACW_REPEAT: return g_ui.repeat;
    case ACW_POS_X:  return g_ui.posX;
    case ACW_POS_Y:  return g_ui.posY;
    default:         return NULL;
    }
}

static int ParseInt(const wchar_t *text, int lo, int hi, int fallback)
{
    wchar_t *end = NULL;
    long     v;

    if (text == NULL || text[0] == L'\0')
        return fallback;

    v = wcstol(text, &end, 10);
    if (end == text)
        return fallback;

    if (v < (long)lo) v = (long)lo;
    if (v > (long)hi) v = (long)hi;
    return (int)v;
}

static void FormatInt(wchar_t *buf, int len, int value)
{
    _snwprintf(buf, (size_t)len, L"%d", value);
    buf[len - 1] = L'\0';
}

// Rewrites the four interval fields from the committed total. Called only on
// commit (focus loss, wheel, start), never while the user is typing, so it
// cannot fight the keyboard - but it kills artefacts like "01 mins".
static void NormalizeIntervalFields(void)
{
    AcIntervalParts parts;

    AcIntervalSplit(g_settings.intervalMs, &parts);
    FormatInt(g_ui.hours, AC_FIELD_LEN, parts.hours);
    FormatInt(g_ui.mins,  AC_FIELD_LEN, parts.mins);
    FormatInt(g_ui.secs,  AC_FIELD_LEN, parts.secs);
    FormatInt(g_ui.msecs, AC_FIELD_LEN, parts.msecs);
}

static void Notify(int widget)
{
    if (g_notify)
    {
        AcUiCommitToSettings();
        g_notify(widget);
    }
}

// ---------------------------------------------------------------------------
// State <-> settings
// ---------------------------------------------------------------------------

void AcUiLoadFromSettings(void)
{
    AcIntervalParts parts;

    AcIntervalSplit(g_settings.intervalMs, &parts);
    FormatInt(g_ui.hours, AC_FIELD_LEN, parts.hours);
    FormatInt(g_ui.mins,  AC_FIELD_LEN, parts.mins);
    FormatInt(g_ui.secs,  AC_FIELD_LEN, parts.secs);
    FormatInt(g_ui.msecs, AC_FIELD_LEN, parts.msecs);

    FormatInt(g_ui.repeat,   AC_FIELD_LEN, g_settings.repeatCount);
    FormatInt(g_ui.posX,     AC_FIELD_LEN, (int)g_settings.fixedPoint.x);
    FormatInt(g_ui.posY,     AC_FIELD_LEN, (int)g_settings.fixedPoint.y);

    g_ui.button        = g_settings.button;
    g_ui.clickType     = g_settings.clickType;
    g_ui.repeatStopped = g_settings.repeatUntilStopped;
    g_ui.fixedCursor   = (g_settings.cursorMode == AC_CURSOR_FIXED);
}

BOOL AcUiCommitToSettings(void)
{
    AcIntervalParts parts;
    UINT            interval;
    int             repeat = ParseInt(g_ui.repeat, 1, AC_AC_MAX_REPEAT, AC_AC_DEFAULT_REPEAT);
    int             px     = ParseInt(g_ui.posX, -99999, 99999, 0);
    int             py     = ParseInt(g_ui.posY, -99999, 99999, 0);

    parts.hours = ParseInt(g_ui.hours, 0, 9999, 0);
    parts.mins  = ParseInt(g_ui.mins,  0, 9999, 0);
    parts.secs  = ParseInt(g_ui.secs,  0, 9999, 0);
    parts.msecs = ParseInt(g_ui.msecs, 0, 9999, 0);

    {
        long long total = (long long)parts.hours * 3600000LL
                        + (long long)parts.mins  *   60000LL
                        + (long long)parts.secs  *    1000LL
                        + (long long)parts.msecs;

        if (total > (long long)AC_AC_MAX_INTERVAL_MS)
        {
            // Clamp and rewrite the fields only when the sum is impossible;
            // ordinary typing is never interrupted by a rewrite.
            AcIntervalSplit((UINT)AC_AC_MAX_INTERVAL_MS, &parts);
            FormatInt(g_ui.hours, AC_FIELD_LEN, parts.hours);
            FormatInt(g_ui.mins,  AC_FIELD_LEN, parts.mins);
            FormatInt(g_ui.secs,  AC_FIELD_LEN, parts.secs);
            FormatInt(g_ui.msecs, AC_FIELD_LEN, parts.msecs);
            interval = AC_AC_MAX_INTERVAL_MS;
        }
        else
        {
            interval = (UINT)total;
            if (interval < AC_AC_MIN_INTERVAL_MS)
                interval = AC_AC_MIN_INTERVAL_MS;
        }
    }

    FormatInt(g_ui.repeat, AC_FIELD_LEN, repeat);
    FormatInt(g_ui.posX,   AC_FIELD_LEN, px);
    FormatInt(g_ui.posY,   AC_FIELD_LEN, py);

    g_settings.intervalMs         = interval;
    g_settings.button             = g_ui.button;
    g_settings.clickType          = g_ui.clickType;
    g_settings.repeatUntilStopped = g_ui.repeatStopped;
    g_settings.repeatCount        = repeat;
    g_settings.cursorMode         = g_ui.fixedCursor ? AC_CURSOR_FIXED : AC_CURSOR_CURRENT;
    g_settings.fixedPoint.x       = (LONG)px;
    g_settings.fixedPoint.y       = (LONG)py;

    NormalizeIntervalFields();
    return TRUE;
}

void AcUiSetCursorMode(BOOL fixed)
{
    if (g_ui.fixedCursor == fixed)
        return;

    g_ui.fixedCursor = fixed;
    AcUiCommitToSettings();
    Notify(ACW_CURRENT_POS);
}

void AcUiSetRepeatMode(BOOL untilStopped)
{
    if (g_ui.repeatStopped == untilStopped)
        return;

    g_ui.repeatStopped = untilStopped;
    AcUiCommitToSettings();
    Notify(ACW_REPEAT);
}

void AcUiSetFixedPoint(POINT pt)
{
    FormatInt(g_ui.posX, AC_FIELD_LEN, (int)pt.x);
    FormatInt(g_ui.posY, AC_FIELD_LEN, (int)pt.y);
    AcUiCommitToSettings();
    Notify(ACW_POS_X);
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------

static void SetBox(int id, int x, int y, int w, int h, BOOL enabled)
{
    g_box[id].rc = RectL(x, y, x + w, y + h);
    g_box[id].enabled = enabled;
}

static RECT LabelRect(int x, int y, int w, int h)
{
    return RectL(x, y, x + w, y + h);
}

void AcUiRelayout(void)
{
    if (g_clientW > 0 && g_clientH > 0)
        AcUiLayout(g_clientW, g_clientH);
}

void AcUiLayout(int clientW, int clientH)
{
    const int m      = AcScale(10);
    const int gap    = AcScale(6);
    const int pad    = AcScale(10);
    const int rowH   = g_metrics.rowH;
    const int btnH   = g_metrics.buttonH;
    const int titleH = g_metrics.sectionTitleH;
    const int innerW = clientW - m * 2;
    const int secGap = AcScale(8);
    const int colGap = AcScale(8);

    int y = m;

    g_clientW = clientW;
    g_clientH = clientH;

    // ---- Click interval ---------------------------------------------------
    {
        int top  = y;
        int h    = titleH + AcScale(6) + rowH + AcScale(10);
        int rowY = top + titleH + AcScale(10);
        int fw   = AcScale(52);
        int lw   = AcScale(44);
        int cell = (innerW - pad * 2) / 4;
        int x0   = m + pad;
        int k;

        g_secInterval = RectL(m, top, m + innerW, top + h);

        for (k = 0; k < 4; k++)
        {
            int x = x0 + k * cell;
            g_rcInterval[k]      = RectL(x, rowY, x + fw, rowY + rowH);
            g_rcIntervalLabel[k] = LabelRect(x + fw, rowY, lw, rowH);
        }

        SetBox(ACW_INT_H,  g_rcInterval[0].left, rowY, fw, rowH, TRUE);
        SetBox(ACW_INT_M,  g_rcInterval[1].left, rowY, fw, rowH, TRUE);
        SetBox(ACW_INT_S,  g_rcInterval[2].left, rowY, fw, rowH, TRUE);
        SetBox(ACW_INT_MS, g_rcInterval[3].left, rowY, fw, rowH, TRUE);

        y = top + h;
    }

    // ---- Click options | Click repeat --------------------------------------
    {
        int top  = y + secGap;
        int colW = (innerW - colGap) / 2;
        int h    = titleH + AcScale(6) + rowH * 2 + gap + AcScale(10);
        int secPad = AcScale(4);
        int rowY = top + titleH + AcScale(10);
        int lx   = m + pad;
        int rx   = m + colW + colGap + pad;

        g_secOptions = RectL(m,                  top, m + colW, top + h);
        g_secRepeat  = RectL(m + colW + colGap,  top, m + innerW, top + h);

        {
            int labelW = AcScale(64);
            int ctlX   = lx + labelW + AcScale(6);
            int ctlW   = (m + colW - pad) - ctlX;

            g_rcButtonLabel = LabelRect(lx, rowY + secPad, labelW, rowH);
            g_rcClickLabel  = LabelRect(lx, rowY + secPad + rowH + gap, labelW, rowH);

            SetBox(ACW_BUTTON,     ctlX, rowY + secPad, ctlW, rowH, TRUE);
            SetBox(ACW_CLICK_TYPE, ctlX, rowY + secPad + rowH + gap, ctlW, rowH, TRUE);
        }

        g_rcRepeatLabel = LabelRect(rx, rowY + secPad, AcScale(78), rowH);
        SetBox(ACW_REPEAT, rx + AcScale(80), rowY + secPad, AcScale(54), rowH, !g_ui.repeatStopped);
        g_rcRepeatTimes = LabelRect(rx + AcScale(80) + AcScale(54) + AcScale(6), rowY + secPad, AcScale(44), rowH);

        g_rcUntilStopped = LabelRect(rx, rowY + secPad + rowH + gap, colW - pad * 2, rowH);

        y = top + h;
    }

    // ---- Cursor position ----------------------------------------------------
    {
        int top   = y + secGap;
        int h     = titleH + AcScale(6) + rowH + AcScale(10);
        int rowY  = top + titleH + AcScale(10);
        int x     = m + pad;
        int pickW = AcScale(88);
        int cb    = g_metrics.checkBox;

        g_secCursor = RectL(m, top, m + innerW, top + h);

        g_rcCurLoc = LabelRect(x, rowY, AcScale(132), rowH);
        x += AcScale(132) + AcScale(6);

        g_rcFixedLoc = LabelRect(x, rowY, cb + AcScale(6), rowH);
        x += cb + AcScale(14);

        SetBox(ACW_PICK, x, rowY, pickW, rowH, g_ui.fixedCursor);
        x += pickW + AcScale(12);

        g_rcPosXLabel = LabelRect(x, rowY, AcScale(14), rowH);
        x += AcScale(14) + AcScale(4);
        SetBox(ACW_POS_X, x, rowY, AcScale(52), rowH, g_ui.fixedCursor);
        x += AcScale(52) + AcScale(12);

        g_rcPosYLabel = LabelRect(x, rowY, AcScale(14), rowH);
        x += AcScale(14) + AcScale(4);
        SetBox(ACW_POS_Y, x, rowY, AcScale(52), rowH, g_ui.fixedCursor);

        y = top + h;
    }

    // ---- Bottom bar ----------------------------------------------------------
    {
        int top  = clientH - m - btnH * 2 - gap;
        int half = (innerW - gap) / 2;

        if (top < y + AcScale(14))
            top = y + AcScale(14);

        SetBox(ACW_START,  m,              top,              half, btnH, g_status.canRun);
        SetBox(ACW_STOP,   m + half + gap, top,              half, btnH, g_status.running);
        SetBox(ACW_HOTKEY, m,              top + btnH + gap, half, btnH, !g_status.running);

        g_statusRc = RectL(m + half + gap + AcScale(6), top + btnH + gap,
                           m + innerW, top + btnH * 2 + gap);
    }
}

// ---------------------------------------------------------------------------
// Clipping helpers
// ---------------------------------------------------------------------------

static int  g_clipStack = 0;

static void PushClip(HDC dc, const RECT *rc)
{
    if (g_clipStack == 0)
        SaveDC(dc);
    g_clipStack++;
    IntersectClipRect(dc, rc->left, rc->top, rc->right, rc->bottom);
}

static void PopClip(HDC dc)
{
    if (g_clipStack > 0)
    {
        g_clipStack--;
        if (g_clipStack == 0)
            RestoreDC(dc, -1);
    }
}

// ---------------------------------------------------------------------------
// Painting helpers
// ---------------------------------------------------------------------------

static void FillRound(HDC dc, const RECT *rc, int radius, COLORREF fill, COLORREF outline)
{
    HBRUSH  brush = CreateSolidBrush(fill);
    HPEN    pen   = CreatePen(PS_SOLID, 1, outline);
    HGDIOBJ ob    = SelectObject(dc, brush);
    HGDIOBJ op    = SelectObject(dc, pen);

    if (radius > 0)
        RoundRect(dc, rc->left, rc->top, rc->right, rc->bottom, radius * 2, radius * 2);
    else
        Rectangle(dc, rc->left, rc->top, rc->right, rc->bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(brush);
    DeleteObject(pen);
}

static void TextOutRect(HDC dc, HFONT font, COLORREF color, const wchar_t *text,
                        const RECT *rc, UINT flags)
{
    RECT r = *rc;
    SelectObject(dc, font);
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    DrawTextW(dc, text, -1, &r, flags | DT_NOPREFIX);
}

static void DrawSection(HDC dc, const RECT *sec, const wchar_t *title)
{
    RECT r = *sec;

    FillRound(dc, sec, AcScale(6), g_theme.panel, g_theme.border);

    r.left  += AcScale(14);
    r.top   += AcScale(8);
    r.right -= AcScale(14);
    r.bottom = r.top + g_metrics.sectionTitleH;

    TextOutRect(dc, g_metrics.fontSmallBold, g_theme.textDim, title, &r,
                DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}

static void DrawRadioGlyph(HDC dc, int x, int y, int size, BOOL checked, BOOL hover)
{
    RECT     rc   = RectL(x, y, x + size, y + size);
    HBRUSH   fill = CreateSolidBrush(g_theme.field);
    HPEN     pen  = CreatePen(PS_SOLID, AcScale(1), (hover || checked) ? g_theme.accent : g_theme.fieldBorder);
    HGDIOBJ  ob   = SelectObject(dc, fill);
    HGDIOBJ  op   = SelectObject(dc, pen);

    Ellipse(dc, rc.left, rc.top, rc.right, rc.bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(fill);
    DeleteObject(pen);

    if (!checked)
        return;

    InsetRect(&rc, size / 3, size / 3);
    fill = CreateSolidBrush(g_theme.accent);
    pen  = CreatePen(PS_NULL, 0, g_theme.accent);
    ob   = SelectObject(dc, fill);
    op   = SelectObject(dc, pen);

    Ellipse(dc, rc.left, rc.top + 1, rc.right - 1, rc.bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(fill);
    DeleteObject(pen);
}

static void DrawCaret(HDC dc, int id, const wchar_t *text, BOOL focused)
{
    SIZE sz = { 0, 0 };
    RECT rc = g_box[id].rc;
    RECT caret;

    if (!focused || !g_caretOn)
        return;

    InsetRect(&rc, g_metrics.editPadX, 0);
    SelectObject(dc, g_metrics.font);
    GetTextExtentPoint32W(dc, text, (int)wcslen(text), &sz);

    caret.left   = rc.left + sz.cx + 1;
    caret.right  = caret.left + AcScale(1) + 1;
    caret.top    = rc.top + AcScale(6);
    caret.bottom = rc.bottom - AcScale(6);

    FillRound(dc, &caret, 0, g_theme.accent, g_theme.accent);
}

static void DrawField(HDC dc, int id, BOOL focused, BOOL hover)
{
    const AcBox   *b    = &g_box[id];
    RECT           rc   = b->rc;
    const wchar_t *text = FieldText(id);
    COLORREF       border;

    border = focused ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.fieldBorder);

    FillRound(dc, &rc, AcScale(4), g_theme.field, border);
    InsetRect(&rc, g_metrics.editPadX, 0);

    PushClip(dc, &rc);
    TextOutRect(dc, g_metrics.font, b->enabled ? g_theme.text : g_theme.textDisabled,
                (text && text[0]) ? text : L"0", &rc,
                DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    PopClip(dc);
}

static void DrawCombo(HDC dc, int id, BOOL hover, BOOL open)
{
    const AcBox   *b    = &g_box[id];
    RECT           rc   = b->rc;
    const wchar_t *value = (id == ACW_BUTTON) ? kButtonNames[g_ui.button] : kClickNames[g_ui.clickType];
    int            arrow = AcScale(9);
    int            cx    = rc.right - AcScale(16);
    RECT           tr    = rc;

    FillRound(dc, &rc, AcScale(4), g_theme.field,
              open ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.fieldBorder));

    tr.left  += g_metrics.editPadX + AcScale(2);
    tr.right -= arrow + AcScale(10);

    PushClip(dc, &tr);
    TextOutRect(dc, g_metrics.font, b->enabled ? g_theme.text : g_theme.textDisabled,
                value, &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    PopClip(dc);

    {
        HPEN    pen = CreatePen(PS_SOLID, AcScale(2), b->enabled ? g_theme.textDim : g_theme.textDisabled);
        HGDIOBJ op  = SelectObject(dc, pen);
        int     cy  = rc.top + RectH(&rc) / 2;

        MoveToEx(dc, cx - arrow / 2, cy - arrow / 5, NULL);
        LineTo(dc,   cx,             cy + arrow / 5);
        LineTo(dc,   cx + arrow / 2, cy - arrow / 5);

        SelectObject(dc, op);
        DeleteObject(pen);
    }
}

static void DrawButton(HDC dc, int id, const wchar_t *caption, BOOL enabled,
                       BOOL primary, BOOL hover, BOOL pressed)
{
    const AcBox *b  = &g_box[id];
    RECT         rc = b->rc;
    COLORREF     fill;
    COLORREF     text;

    if (!enabled)
    {
        fill = g_theme.panel;
        text = g_theme.textDisabled;
    }
    else if (primary)
    {
        fill = pressed ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.accent);
        text = g_theme.accentText;
    }
    else
    {
        fill = pressed ? g_theme.buttonDown : (hover ? g_theme.buttonHover : g_theme.button);
        text = g_theme.text;
    }

    FillRound(dc, &rc, AcScale(5), fill, g_theme.border);
    TextOutRect(dc, g_metrics.font, text, caption, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

// ---------------------------------------------------------------------------
// Paint
// ---------------------------------------------------------------------------


void AcUiPaint(HDC hdc)
{
    RECT full = RectL(0, 0, g_clientW, g_clientH);
    int  i;

    FillRound(hdc, &full, 0, g_theme.bg, g_theme.bg);

    DrawSection(hdc, &g_secInterval, L"Click interval");
    DrawSection(hdc, &g_secOptions,  L"Click options");
    DrawSection(hdc, &g_secRepeat,   L"Click repeat");
    DrawSection(hdc, &g_secCursor,   L"Cursor position");

    // ---- Interval ---------------------------------------------------------
    {
        int k;

        for (k = 0; k < 4; k++)
        {
            int id = ACW_INT_H + k;
            RECT lr = g_rcIntervalLabel[k];

            DrawField(hdc, id, g_focus == id, g_box[id].hover);
            DrawCaret(hdc, id, FieldText(id), g_focus == id);

            lr.left += AcScale(5);
            TextOutRect(hdc, g_metrics.font, g_theme.textDim, kIntervalUnits[k],
                        &lr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        }
    }

    // ---- Options ----------------------------------------------------------
    {
        TextOutRect(hdc, g_metrics.font, g_theme.text, L"Button", &g_rcButtonLabel,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        DrawCombo(hdc, ACW_BUTTON, g_box[ACW_BUTTON].hover,
                  g_ui.openPopup && g_ui.popupFor == ACW_BUTTON);

        TextOutRect(hdc, g_metrics.font, g_theme.text, L"Click type", &g_rcClickLabel,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        DrawCombo(hdc, ACW_CLICK_TYPE, g_box[ACW_CLICK_TYPE].hover,
                  g_ui.openPopup && g_ui.popupFor == ACW_CLICK_TYPE);
    }

    // ---- Repeat -----------------------------------------------------------
    {
        int  cb = g_metrics.checkBox;
        RECT rr = g_rcRepeatLabel;
        int  cy = rr.top + RectH(&rr) / 2 - cb / 2;
        RECT tr;

        DrawRadioGlyph(hdc, rr.left, cy, cb, !g_ui.repeatStopped, FALSE);
        tr = LabelRect(rr.left + cb + AcScale(8), rr.top,
                       rr.right - rr.left - cb - AcScale(8), RectH(&rr));
        TextOutRect(hdc, g_metrics.font, g_ui.repeatStopped ? g_theme.textDim : g_theme.text,
                    L"Repeat", &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

        DrawField(hdc, ACW_REPEAT, g_focus == ACW_REPEAT, g_box[ACW_REPEAT].hover);
        DrawCaret(hdc, ACW_REPEAT, g_ui.repeat, g_focus == ACW_REPEAT);

        TextOutRect(hdc, g_metrics.font, g_theme.textDim, L"times", &g_rcRepeatTimes,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);

        {
            RECT ur  = g_rcUntilStopped;
            int  ucy = ur.top + RectH(&ur) / 2 - cb / 2;

            DrawRadioGlyph(hdc, ur.left, ucy, cb, g_ui.repeatStopped, g_hot == ACW_UNTIL_STOPPED);
            tr = LabelRect(ur.left + cb + AcScale(8), ur.top,
                           ur.right - ur.left - cb - AcScale(8), RectH(&ur));
            TextOutRect(hdc, g_metrics.font, g_ui.repeatStopped ? g_theme.text : g_theme.textDim,
                        L"Until stopped", &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        }
    }

    // ---- Cursor position ----------------------------------------------------
    {
        int  cb = g_metrics.checkBox;
        RECT tr;

        {
            RECT cl = g_rcCurLoc;
            int  cy = cl.top + RectH(&cl) / 2 - cb / 2;

            DrawRadioGlyph(hdc, cl.left, cy, cb, !g_ui.fixedCursor, g_hot == ACW_CURRENT_POS);
            tr = LabelRect(cl.left + cb + AcScale(8), cl.top,
                           cl.right - cl.left - cb - AcScale(8), RectH(&cl));
            TextOutRect(hdc, g_metrics.font, g_ui.fixedCursor ? g_theme.textDim : g_theme.text,
                        L"Current location", &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        }

        {
            RECT fl = g_rcFixedLoc;
            int  cy = fl.top + RectH(&fl) / 2 - cb / 2;

            DrawRadioGlyph(hdc, fl.left, cy, cb, g_ui.fixedCursor, g_hot == ACW_FIXED_POS);
        }

        DrawButton(hdc, ACW_PICK, L"Pick location", g_box[ACW_PICK].enabled, FALSE,
                   g_box[ACW_PICK].hover, g_box[ACW_PICK].pressed);

        TextOutRect(hdc, g_metrics.font, g_theme.textDim, L"X", &g_rcPosXLabel,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        DrawField(hdc, ACW_POS_X, g_focus == ACW_POS_X, g_box[ACW_POS_X].hover);
        DrawCaret(hdc, ACW_POS_X, g_ui.posX, g_focus == ACW_POS_X);

        TextOutRect(hdc, g_metrics.font, g_theme.textDim, L"Y", &g_rcPosYLabel,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        DrawField(hdc, ACW_POS_Y, g_focus == ACW_POS_Y, g_box[ACW_POS_Y].hover);
        DrawCaret(hdc, ACW_POS_Y, g_ui.posY, g_focus == ACW_POS_Y);
    }

    // ---- Bottom -------------------------------------------------------------
    {
        wchar_t cap[96];

        _snwprintf(cap, 96, L"Start  (%s)", g_status.hotkeyText[0] ? g_status.hotkeyText : L"None");
        cap[95] = L'\0';
        DrawButton(hdc, ACW_START, cap, g_box[ACW_START].enabled, TRUE,
                   g_box[ACW_START].hover, g_box[ACW_START].pressed);

        _snwprintf(cap, 96, L"Stop  (%s)", g_status.hotkeyText[0] ? g_status.hotkeyText : L"None");
        cap[95] = L'\0';
        DrawButton(hdc, ACW_STOP, cap, g_box[ACW_STOP].enabled, FALSE,
                   g_box[ACW_STOP].hover, g_box[ACW_STOP].pressed);

        {
            wchar_t label[96];
            _snwprintf(label, 96, L"Hotkey: %s", g_status.hotkeyText[0] ? g_status.hotkeyText : L"None");
            label[95] = L'\0';
            DrawButton(hdc, ACW_HOTKEY, label, g_box[ACW_HOTKEY].enabled, FALSE,
                       g_box[ACW_HOTKEY].hover, g_box[ACW_HOTKEY].pressed);
        }

        {
            RECT           sr    = g_statusRc;
            COLORREF       color = g_status.running ? g_theme.accent : g_theme.textDim;
            const wchar_t *txt   = g_status.statusText;

            if (g_recording)
                txt = L"Press the key combination\u2026";

            TextOutRect(hdc, g_metrics.fontSmall, color, txt, &sr,
                        DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        }
    }

    // ---- Combo popup (painted last, on top of everything) -------------------
    if (g_ui.openPopup)
    {
        int  count = (g_ui.popupFor == ACW_BUTTON) ? AC_BUTTON_COUNT : AC_CLICK_TYPE_COUNT;
        int  h     = count * g_metrics.rowH + AcScale(4);
        RECT base  = g_box[g_ui.popupFor].rc;

        g_popupRc = RectL(base.left, base.bottom + AcScale(2),
                          base.right, base.bottom + AcScale(2) + h);

        FillRound(hdc, &g_popupRc, AcScale(5), g_theme.panel, g_theme.border);

        for (i = 0; i < count; i++)
        {
            RECT item = RectL(g_popupRc.left + AcScale(2),
                              g_popupRc.top + AcScale(2) + i * g_metrics.rowH,
                              g_popupRc.right - AcScale(2),
                              g_popupRc.top + AcScale(2) + (i + 1) * g_metrics.rowH);
            RECT tr;

            if (i == g_ui.popupSel)
                FillRound(hdc, &item, AcScale(4), g_theme.buttonHover, g_theme.buttonHover);

            tr = item;
            InsetRect(&tr, AcScale(8), 0);
            TextOutRect(hdc, g_metrics.font, g_theme.text,
                        (g_ui.popupFor == ACW_BUTTON) ? kButtonNames[i] : kClickNames[i],
                        &tr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        }
    }
}

// ---------------------------------------------------------------------------
// Hit testing and input
// ---------------------------------------------------------------------------
BOOL AcUiPopupOpen(void)
{
    return g_ui.openPopup;
}

BOOL AcUiWantsTextInput(void)
{
    return (g_focus >= 0 && IsTextField(g_focus)) ? TRUE : FALSE;
}

BOOL AcUiIsWidgetEnabled(int widget)
{
    return (widget >= 0 && widget < ACW_COUNT && g_box[widget].enabled) ? TRUE : FALSE;
}

void AcUiDismissPopup(void)
{
    g_ui.openPopup = FALSE;
    g_ui.popupFor  = -1;
}

void AcUiSetRecording(BOOL on)
{
    g_recording = on;
}

BOOL AcUiIsRecording(void)
{
    return g_recording;
}

void AcUiSetNotify(AcUiNotify notify)
{
    g_notify = notify;
}

void AcUiSetStatus(const AcUiStatus *status)
{
    if (status)
        g_status = *status;
}

static void OpenPopup(int id)
{
    g_ui.openPopup = TRUE;
    g_ui.popupFor  = id;
    g_ui.popupSel  = (id == ACW_BUTTON) ? (int)g_ui.button : (int)g_ui.clickType;
}

BOOL AcUiOnMouseMove(int x, int y)
{
    int  i;
    BOOL changed = FALSE;
    int  hit     = -1;
    if (g_ui.openPopup && Hit(&g_popupRc, x, y))
        hit = g_ui.popupFor;

    for (i = 0; i < ACW_COUNT && hit < 0; i++)
    {
        if (g_box[i].enabled && Hit(&g_box[i].rc, x, y))
            hit = i;
    }

    if (hit < 0)
    {
        if (Hit(&g_rcRepeatLabel, x, y))       hit = ACW_REPEAT;
        else if (Hit(&g_rcUntilStopped, x, y)) hit = ACW_UNTIL_STOPPED;
        else if (Hit(&g_rcCurLoc, x, y))       hit = ACW_CURRENT_POS;
        else if (Hit(&g_rcFixedLoc, x, y))     hit = ACW_FIXED_POS;
    }

    if (hit != g_hot)
    {
        g_hot = hit;
        changed = TRUE;
    }

    for (i = 0; i < ACW_COUNT; i++)
    {
        BOOL h = (hit == i);

        if (g_box[i].hover != h)
        {
            g_box[i].hover = h;
            changed = TRUE;
        }
    }

    if (g_ui.openPopup && hit == g_ui.popupFor && Hit(&g_popupRc, x, y))
    {
        int count = (g_ui.popupFor == ACW_BUTTON) ? AC_BUTTON_COUNT : AC_CLICK_TYPE_COUNT;
        int rel   = y - g_popupRc.top - AcScale(2);
        int idx   = rel / g_metrics.rowH;

        if (idx >= 0 && idx < count && g_ui.popupSel != idx)
        {
            g_ui.popupSel = idx;
            changed = TRUE;
        }
    }

    return changed;
}

BOOL AcUiOnMouseWheel(int x, int y, int delta)
{
    int      id = -1;
    int      i;
    wchar_t *text;
    int      lo, hi, step, value;

    if (delta == 0)
        return FALSE;

    for (i = 0; i < ACW_COUNT; i++)
    {
        if (g_box[i].enabled && Hit(&g_box[i].rc, x, y))
        {
            id = i;
            break;
        }
    }

    if (id < 0 || !IsTextField(id))
        return FALSE;

    text = FieldText(id);

    if (IsIntervalField(id))
    {
        lo = 0;
        hi = (id == ACW_INT_H) ? 24 : 9999;
    }
    else if (id == ACW_REPEAT)
    {
        lo = 1;
        hi = AC_AC_MAX_REPEAT;
    }
    else
    {
        lo = -99999;
        hi = 99999;
    }

    step  = (delta > 0) ? 1 : -1;
    value = ParseInt(text, lo, hi, (id == ACW_INT_MS) ? AC_AC_DEFAULT_INTERVAL : 0) + step;

    if (value < lo) value = lo;
    if (value > hi) value = hi;

    FormatInt(text, AC_FIELD_LEN, value);
    g_editPos  = (int)wcslen(text);
    g_zeroSlot = FALSE;

    Notify(id);
    return TRUE;
}

BOOL AcUiOnMouseLeave(void)
{
    int  i;
    BOOL changed = FALSE;

    for (i = 0; i < ACW_COUNT; i++)
    {
        if (g_box[i].hover)   { g_box[i].hover = FALSE; changed = TRUE; }
        if (g_box[i].pressed) { g_box[i].pressed = FALSE; changed = TRUE; }
    }

    if (g_hot >= 0)
    {
        g_hot = -1;
        changed = TRUE;
    }

    return changed;
}

BOOL AcUiOnMouseDown(int x, int y)
{
    int id;

    // ---- Popup handling first -------------------------------------------
    if (g_ui.openPopup)
    {
        if (Hit(&g_popupRc, x, y))
        {
            int count = (g_ui.popupFor == ACW_BUTTON) ? AC_BUTTON_COUNT : AC_CLICK_TYPE_COUNT;
            int rel   = y - g_popupRc.top - AcScale(2);
            int idx   = rel / g_metrics.rowH;
            int owner = g_ui.popupFor;

            if (idx < 0) idx = 0;
            if (idx >= count) idx = count - 1;

            if (owner == ACW_BUTTON)
                g_ui.button = (AcMouseButton)idx;
            else
                g_ui.clickType = (AcClickType)idx;

            AcUiDismissPopup();
            Notify(owner);
            return TRUE;
        }

        {
            int owner = g_ui.popupFor;
            AcUiDismissPopup();
            if (Hit(&g_box[owner].rc, x, y))
                return TRUE;
        }
        return TRUE;
    }

    // ---- Radios -----------------------------------------------------------
    if (Hit(&g_rcRepeatLabel, x, y))
    {
        AcUiSetRepeatMode(FALSE);
        g_focus = -1;
        return TRUE;
    }
    if (Hit(&g_rcUntilStopped, x, y))
    {
        AcUiSetRepeatMode(TRUE);
        g_focus = -1;
        return TRUE;
    }
    if (Hit(&g_rcCurLoc, x, y))
    {
        AcUiSetCursorMode(FALSE);
        g_focus = -1;
        return TRUE;
    }
    if (Hit(&g_rcFixedLoc, x, y))
    {
        AcUiSetCursorMode(TRUE);
        g_focus = -1;
        return TRUE;
    }

    id = -1;
    {
        int i;
        for (i = 0; i < ACW_COUNT; i++)
        {
            if (g_box[i].enabled && Hit(&g_box[i].rc, x, y))
            {
                id = i;
                break;
            }
        }
    }

    if (id < 0)
    {
        int hadFocus = (g_focus >= 0);
        g_focus = -1;
        if (hadFocus)
        {
            AcUiCommitToSettings();
            Notify(-1);
            return TRUE;
        }
        return FALSE;
    }

    if (IsTextField(id))
    {
        if (g_focus >= 0 && g_focus != id)
            AcUiCommitToSettings();

        g_focus     = id;
        g_editPos   = (int)wcslen(FieldText(id));
        g_zeroSlot  = (g_editPos == 1 && FieldText(id)[0] == L'0') ? TRUE : FALSE;
        g_caretTick = GetTickCount();
        g_caretOn   = TRUE;
        return TRUE;
    }

    if (IsCombo(id))
    {
        OpenPopup(id);
        return TRUE;
    }

    g_pressed = id;
    g_box[id].pressed = TRUE;
    return TRUE;
}

BOOL AcUiOnMouseUp(int x, int y)
{
    int pressed = g_pressed;

    if (pressed < 0)
        return FALSE;

    g_box[pressed].pressed = FALSE;
    g_pressed = -1;

    if (Hit(&g_box[pressed].rc, x, y))
        Notify(pressed);

    return TRUE;
}

BOOL AcUiOnCaptureLost(void)
{
    int i;

    for (i = 0; i < ACW_COUNT; i++)
        g_box[i].pressed = FALSE;

    g_pressed = -1;
    return TRUE;
}

BOOL AcUiOnKeyDown(int vk)
{
    if (g_ui.openPopup)
    {
        int count = (g_ui.popupFor == ACW_BUTTON) ? AC_BUTTON_COUNT : AC_CLICK_TYPE_COUNT;

        switch (vk)
        {
        case VK_UP:
            g_ui.popupSel = (g_ui.popupSel + count - 1) % count;
            return TRUE;
        case VK_DOWN:
            g_ui.popupSel = (g_ui.popupSel + 1) % count;
            return TRUE;
        case VK_RETURN:
            if (g_ui.popupFor == ACW_BUTTON)
                g_ui.button = (AcMouseButton)g_ui.popupSel;
            else
                g_ui.clickType = (AcClickType)g_ui.popupSel;
            AcUiDismissPopup();
            return TRUE;
        case VK_ESCAPE:
            AcUiDismissPopup();
            return TRUE;
        default:
            return FALSE;
        }
    }

    if (g_focus >= 0 && IsTextField(g_focus))
    {
        wchar_t *text = FieldText(g_focus);
        int      len  = (int)wcslen(text);

        switch (vk)
        {
        case VK_BACK:
            g_zeroSlot = FALSE;
            if (g_editPos > 0)
            {
                memmove(&text[g_editPos - 1], &text[g_editPos],
                        (size_t)(len - g_editPos + 1) * sizeof(wchar_t));
                g_editPos--;
            }
            return TRUE;

        case VK_DELETE:
            g_zeroSlot = FALSE;
            if (g_editPos < len)
            {
                memmove(&text[g_editPos], &text[g_editPos + 1],
                        (size_t)(len - g_editPos) * sizeof(wchar_t));
            }
            return TRUE;

        case VK_LEFT:
            g_zeroSlot = FALSE;
            if (g_editPos > 0) g_editPos--;
            return TRUE;

        case VK_RIGHT:
            g_zeroSlot = FALSE;
            if (g_editPos < len) g_editPos++;
            return TRUE;

        case VK_HOME:
            g_zeroSlot = FALSE;
            g_editPos = 0;
            return TRUE;

        case VK_END:
            g_zeroSlot = FALSE;
            g_editPos = len;
            return TRUE;

        case VK_RETURN:
        case VK_TAB:
            g_focus = -1;
            g_zeroSlot = FALSE;
            AcUiCommitToSettings();
            Notify(-1);
            return TRUE;

        case VK_ESCAPE:
            g_focus = -1;
            g_zeroSlot = FALSE;
            AcUiLoadFromSettings();
            Notify(-1);
            return TRUE;

        default:
            break;
        }
    }

    return FALSE;
}

BOOL AcUiOnChar(wchar_t ch)
{
    wchar_t *text;
    int      len;
    BOOL     allowMinus;

    if (g_focus < 0 || !IsTextField(g_focus))
        return FALSE;

    if (ch == L'\r' || ch == L'\b' || ch == 0x1B || ch < 32)
        return FALSE;

    allowMinus = (g_focus == ACW_POS_X || g_focus == ACW_POS_Y) ? TRUE : FALSE;

    if (!(ch >= L'0' && ch <= L'9') && !(allowMinus && ch == L'-'))
        return FALSE;

    text = FieldText(g_focus);
    len  = (int)wcslen(text);

    if (g_zeroSlot)
    {
        text[0] = L'\0';
        len = 0;
        g_editPos = 0;
        g_zeroSlot = FALSE;
    }

    if (ch == L'-' && (g_editPos != 0 || len > 0))
        return FALSE;

    if (len >= AC_FIELD_LEN - 1)
        return FALSE;

    memmove(&text[g_editPos + 1], &text[g_editPos],
            (size_t)(len - g_editPos + 1) * sizeof(wchar_t));
    text[g_editPos] = ch;
    g_editPos++;

    g_caretTick = GetTickCount();
    g_caretOn   = TRUE;
    return TRUE;
}

void AcUiTick(void)
{
    if (g_focus >= 0 && IsTextField(g_focus))
    {
        DWORD now = GetTickCount();

        if (now - g_caretTick >= AC_CARET_BLINK_MS)
        {
            g_caretTick = now;
            g_caretOn   = !g_caretOn;
        }
    }
    else
    {
        g_caretOn = FALSE;
    }
}

BOOL AcUiIsEditing(void)
{
    return (g_focus >= 0 && IsTextField(g_focus)) ? TRUE : FALSE;
}
