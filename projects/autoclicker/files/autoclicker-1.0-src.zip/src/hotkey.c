// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - global hotkey support.
//

#include "common.h"
#include "hotkey.h"

static BOOL g_registered = FALSE;
static UINT g_vk   = 0;
static UINT g_mods = 0;

static const wchar_t *VkName(UINT vk, wchar_t *buf, int cch)
{
    switch (vk)
    {
    case VK_F1:  return L"F1";
    case VK_F2:  return L"F2";
    case VK_F3:  return L"F3";
    case VK_F4:  return L"F4";
    case VK_F5:  return L"F5";
    case VK_F6:  return L"F6";
    case VK_F7:  return L"F7";
    case VK_F8:  return L"F8";
    case VK_F9:  return L"F9";
    case VK_F10: return L"F10";
    case VK_F11: return L"F11";
    case VK_F12: return L"F12";
    case VK_SPACE:   return L"Space";
    case VK_RETURN:  return L"Enter";
    case VK_ESCAPE:  return L"Esc";
    case VK_TAB:     return L"Tab";
    case VK_BACK:    return L"Backspace";
    case VK_INSERT:  return L"Insert";
    case VK_DELETE:  return L"Delete";
    case VK_HOME:    return L"Home";
    case VK_END:     return L"End";
    case VK_PRIOR:   return L"PageUp";
    case VK_NEXT:    return L"PageDown";
    case VK_LEFT:    return L"Left";
    case VK_RIGHT:   return L"Right";
    case VK_UP:      return L"Up";
    case VK_DOWN:    return L"Down";
    case VK_PAUSE:   return L"Pause";
    case VK_SCROLL:  return L"ScrollLock";
    case VK_SNAPSHOT:return L"PrintScreen";
    case 0:          return L"None";
    default:         break;
    }

    if (vk >= 'A' && vk <= 'Z')
    {
        buf[0] = (wchar_t)vk;
        buf[1] = L'\0';
        return buf;
    }
    if (vk >= '0' && vk <= '9')
    {
        buf[0] = (wchar_t)vk;
        buf[1] = L'\0';
        return buf;
    }
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9)
    {
        _snwprintf(buf, (size_t)cch, L"Num%d", (int)(vk - VK_NUMPAD0));
        return buf;
    }

    _snwprintf(buf, (size_t)cch, L"VK 0x%02X", vk);
    return buf;
}

void AcHotkeyFormat(UINT vk, UINT mods, wchar_t *buf, int cch)
{
    wchar_t        key[32];
    const wchar_t *name;
    int            len;

    if (cch <= 0) return;
    buf[0] = L'\0';

    if (vk == 0)
    {
        wcsncpy(buf, L"None", (size_t)cch - 1);
        buf[cch - 1] = L'\0';
        return;
    }

    if (mods & MOD_CONTROL) wcscat(buf, L"Ctrl+");
    if (mods & MOD_SHIFT)   wcscat(buf, L"Shift+");
    if (mods & MOD_ALT)     wcscat(buf, L"Alt+");
    if (mods & MOD_WIN)     wcscat(buf, L"Win+");

    name = VkName(vk & 0xFF, key, 32);
    len  = (int)wcslen(buf);
    wcsncat(buf, name, (size_t)(cch - 1 - len));
    buf[cch - 1] = L'\0';
}

void AcHotkeyRelease(HWND hwnd)
{
    if (g_registered)
    {
        UnregisterHotKey(hwnd, AC_HOTKEY_ID_START);
        g_registered = FALSE;
    }
}

BOOL AcHotkeyApply(HWND hwnd, UINT vk, UINT mods)
{
    AcHotkeyRelease(hwnd);

    g_vk   = vk;
    g_mods = mods;

    if (vk == 0 || hwnd == NULL)
        return TRUE; // "no hotkey" is a valid configuration

    // RegisterHotKey requires a modification code to avoid swallowing plain
    // typing; MOD_NOREPEAT additionally prevents auto-repeat while held.
    // A single id is enough: the owner window treats the key as a toggle,
    // so "start" and "stop" share one physical combination.
    if (!RegisterHotKey(hwnd, AC_HOTKEY_ID_START, mods | MOD_NOREPEAT, vk))
        return FALSE;

    g_registered = TRUE;
    return TRUE;
}

BOOL AcHotkeyIsRegistered(void)
{
    return g_registered;
}
