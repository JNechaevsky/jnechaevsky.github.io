// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef AC_UI_H
#define AC_UI_H

#include "common.h"

#define AC_FIELD_LEN 12

typedef struct
{
    wchar_t       hours[AC_FIELD_LEN];
    wchar_t       mins[AC_FIELD_LEN];
    wchar_t       secs[AC_FIELD_LEN];
    wchar_t       msecs[AC_FIELD_LEN];
    AcMouseButton button;
    AcClickType   clickType;
    wchar_t       repeat[AC_FIELD_LEN];
    BOOL          repeatStopped;
    BOOL          fixedCursor;
    wchar_t       posX[AC_FIELD_LEN];
    wchar_t       posY[AC_FIELD_LEN];
    BOOL          openPopup;
    int           popupFor;
    int           popupSel;
} AcUiState;

extern AcUiState g_ui;

typedef struct
{
    BOOL               running;
    BOOL               canRun;
    unsigned long long clicks;
    int                intervalMs;
    wchar_t            hotkeyText[64];
    wchar_t            statusText[160];
} AcUiStatus;

typedef void (*AcUiNotify)(int widget);

void AcUiSetNotify(AcUiNotify notify);
void AcUiSetStatus(const AcUiStatus *status);

void AcUiLoadFromSettings(void);
BOOL AcUiCommitToSettings(void);

// Radio helpers: they update g_ui, commit and notify in one go.
void AcUiSetCursorMode(BOOL fixed);
void AcUiSetRepeatMode(BOOL untilStopped);
void AcUiSetFixedPoint(POINT pt);

void AcUiLayout(int clientW, int clientH);
void AcUiRelayout(void);   // re-runs layout with the last known client size
void AcUiPaint(HDC hdc);


BOOL AcUiOnMouseMove(int x, int y);
BOOL AcUiOnMouseDown(int x, int y);
BOOL AcUiOnMouseUp(int x, int y);
BOOL AcUiOnMouseLeave(void);
BOOL AcUiOnMouseWheel(int x, int y, int delta);
BOOL AcUiOnKeyDown(int vk);
BOOL AcUiOnChar(wchar_t ch);
BOOL AcUiOnCaptureLost(void);

void AcUiTick(void);

BOOL AcUiWantsTextInput(void);
BOOL AcUiIsEditing(void);
BOOL AcUiPopupOpen(void);
void  AcUiDismissPopup(void);
BOOL AcUiIsWidgetEnabled(int widget);

typedef struct
{
    int hours, mins, secs, msecs;
} AcIntervalParts;

void AcIntervalSplit(UINT totalMs, AcIntervalParts *out);
UINT AcIntervalJoin(const AcIntervalParts *in);

void AcUiSetRecording(BOOL on);
BOOL AcUiIsRecording(void);

#endif // AC_UI_H
