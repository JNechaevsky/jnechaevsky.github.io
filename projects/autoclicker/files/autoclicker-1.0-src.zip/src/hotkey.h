﻿// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef AC_HOTKEY_H
#define AC_HOTKEY_H

#include "common.h"

#define AC_HOTKEY_ID_START 0xAC01
#define AC_HOTKEY_ID_STOP  0xAC02

// Formats a virtual key + modifier mask as e.g. "F6", "Ctrl+Shift+K".
void AcHotkeyFormat(UINT vk, UINT mods, wchar_t *buf, int cch);

// (Un)registers the global hotkey pair. Returns FALSE when Windows refuses
// (usually because another process owns the combination).
BOOL AcHotkeyApply(HWND hwnd, UINT vk, UINT mods);

void AcHotkeyRelease(HWND hwnd);

BOOL AcHotkeyIsRegistered(void);

#endif // AC_HOTKEY_H
