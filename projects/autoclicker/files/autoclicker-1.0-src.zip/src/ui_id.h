﻿// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef AC_UI_ID_H
#define AC_UI_ID_H

typedef enum
{
    ACW_INT_H = 0,
    ACW_INT_M,
    ACW_INT_S,
    ACW_INT_MS,
    ACW_BUTTON,
    ACW_CLICK_TYPE,
    ACW_REPEAT,
    ACW_UNTIL_STOPPED,
    ACW_CURRENT_POS,
    ACW_FIXED_POS,
    ACW_PICK,
    ACW_POS_X,
    ACW_POS_Y,
    ACW_START,
    ACW_STOP,
    ACW_HOTKEY,

    ACW_COUNT
} AcWidgetId;

#endif // AC_UI_ID_H
