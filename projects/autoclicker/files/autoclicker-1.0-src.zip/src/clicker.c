﻿// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - the actual clicking engine.
//
// Design notes
// ------------
// * One dedicated worker thread. The UI thread only flips flags and never
//   blocks, so the window stays responsive while clicking.
// * Deadline based scheduling: every click is due at an absolute moment on a
//   high resolution clock. A slow click cannot push the following ones back,
//   so the average rate stays honest instead of drifting.
// * WaitForSingleObject on the stop event is used for sleeping instead of
//   Sleep(), which means "Stop" is reacted to instantly, even for very long
//   intervals (minutes, hours).
// * Clicks are sent with SendInput, never with mouse_event(), because only
//   SendInput goes through the normal input pipeline together with any
//   injected flags.
//

#include "common.h"
#include "clicker.h"

#define AC_PRECISE_SLEEP_US 1500   // spin the last ~1.5 ms for accuracy
#define AC_STOP_WAIT_MS     2000

static HANDLE           g_thread      = NULL;
static HANDLE           g_threadReady = NULL;  // signaled once the job is copied
static HANDLE           g_stopEvent   = NULL;
static volatile LONG    g_running     = 0;
static volatile LONG    g_state       = AC_STATE_IDLE;
static AcRunJob         g_job;
static BOOL             g_jobValid    = FALSE;
static volatile unsigned long long g_clickCount = 0;
static volatile ULONGLONG          g_startTick  = 0;
static DWORD_PTR        g_oldTimerMask = 0;
static BOOL             g_timerRaised  = FALSE;

// ---------------------------------------------------------------------------
// Timing helpers
// ---------------------------------------------------------------------------

static LONGLONG QpcNow(void)
{
    LARGE_INTEGER t;
    QueryPerformanceCounter(&t);
    return t.QuadPart;
}

static LONGLONG QpcFreq(void)
{
    static LONGLONG freq = 0;
    if (freq == 0)
    {
        LARGE_INTEGER f;
        QueryPerformanceFrequency(&f);
        freq = (f.QuadPart > 0) ? f.QuadPart : 1;
    }
    return freq;
}

static void QpcSpinUntil(LONGLONG deadline)
{
    while (QpcNow() < deadline)
        YieldProcessor();
}

// Sleeps until *deadline* (QPC ticks) or until the stop event fires.
// Returns TRUE if the deadline was reached, FALSE if we were asked to stop.
static BOOL WaitUntilQpc(LONGLONG deadline)
{
    for (;;)
    {
        LONGLONG now  = QpcNow();
        LONGLONG left = deadline - now;

        if (left <= 0)
            return TRUE;

        {
            LONGLONG freq  = QpcFreq();
            DWORD    ms    = (DWORD)((left * 1000) / freq);
            DWORD    wait;

            if (ms > 1)
            {
                wait = ms - 1; // coarse part, leaves ~1 ms for fine tuning
            }
            else if (left > (AC_PRECISE_SLEEP_US * freq) / 1000000)
            {
                wait = 1;
            }
            else
            {
                QpcSpinUntil(deadline);
                return TRUE;
            }

            if (WaitForSingleObject(g_stopEvent, wait) == WAIT_OBJECT_0)
                return FALSE;
        }
    }
}

// ---------------------------------------------------------------------------
// Mouse injection
// ---------------------------------------------------------------------------

static DWORD ButtonDownFlag(AcMouseButton b)
{
    switch (b)
    {
    case AC_BUTTON_RIGHT:  return MOUSEEVENTF_RIGHTDOWN;
    case AC_BUTTON_MIDDLE: return MOUSEEVENTF_MIDDLEDOWN;
    default:               return MOUSEEVENTF_LEFTDOWN;
    }
}

static DWORD ButtonUpFlag(AcMouseButton b)
{
    switch (b)
    {
    case AC_BUTTON_RIGHT:  return MOUSEEVENTF_RIGHTUP;
    case AC_BUTTON_MIDDLE: return MOUSEEVENTF_MIDDLEUP;
    default:               return MOUSEEVENTF_LEFTUP;
    }
}

// Moves to the target with SetCursorPos (absolute, physical pixels, DPI aware
// process) and issues the down/up pair.
static void DoOneClick(const AcRunJob *job)
{
    INPUT inputs[2];
    ZeroMemory(inputs, sizeof(inputs));

    if (job->useTarget)
    {
        // Re-assert the position on every click: some games and fullscreen
        // apps recenter the cursor behind our back.
        SetCursorPos(job->target.x, job->target.y);
    }

    inputs[0].type       = INPUT_MOUSE;
    inputs[0].mi.dwFlags = ButtonDownFlag(job->settings.button);

    inputs[1].type       = INPUT_MOUSE;
    inputs[1].mi.dwFlags = ButtonUpFlag(job->settings.button);

    SendInput(2, inputs, sizeof(INPUT));
}

// ---------------------------------------------------------------------------
// Worker
// ---------------------------------------------------------------------------

static DWORD WINAPI ClickerThread(LPVOID param)
{
    AcRunJob job;
    LONGLONG intervalTicks;
    LONGLONG next;
    UINT     total;
    UINT     done = 0;

    (void)param;

    job       = g_job;
    g_jobValid = FALSE;
    total     = job.totalClicks;

    g_clickCount = 0;

    intervalTicks = ((LONGLONG)job.settings.intervalMs * QpcFreq()) / 1000;
    if (intervalTicks < 1)
        intervalTicks = 1;

    g_startTick = GetTickCount64();
    SetEvent(g_threadReady);

    next = QpcNow();

    for (;;)
    {
        if (WaitForSingleObject(g_stopEvent, 0) == WAIT_OBJECT_0)
            break;

        if (total > 0 && done >= total)
            break;

        DoOneClick(&job);
        done++;
        InterlockedIncrement64((volatile LONG64 *)&g_clickCount);

        if (total > 0 && done >= total)
            break;

        next += intervalTicks;
        if (!WaitUntilQpc(next))
            break;
    }

    return 0;
}

// ---------------------------------------------------------------------------
// Public interface
// ---------------------------------------------------------------------------

BOOL AcClickerStart(const AcRunJob *job)
{
    DWORD threadId;

    if (job == NULL)
        return FALSE;

    if (InterlockedCompareExchange(&g_running, 1, 0) != 0)
        return FALSE;

    g_job       = *job;
    g_jobValid  = TRUE;
    g_clickCount = 0;
    g_startTick  = 0;
    InterlockedExchange(&g_state, AC_STATE_RUNNING);

    if (g_stopEvent == NULL)
        g_stopEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (g_threadReady == NULL)
        g_threadReady = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (g_stopEvent == NULL || g_threadReady == NULL)
        goto fail;

    ResetEvent(g_stopEvent);
    ResetEvent(g_threadReady);

    // Ask for a 1 ms system timer. Without it Sleep() granularity is ~15.6 ms
    // which makes sub-50 ms intervals noticeably jittery. Failure is ignored:
    // the engine simply becomes slightly less precise.
    g_oldTimerMask = timeBeginPeriod(1);
    g_timerRaised  = TRUE;

    g_thread = CreateThread(NULL, 0, ClickerThread, NULL, 0, &threadId);
    if (g_thread == NULL)
        goto fail;

    // Do not return before the worker has copied the job structure.
    WaitForSingleObject(g_threadReady, 1000);
    return TRUE;

fail:
    if (g_timerRaised)
    {
        timeEndPeriod(1);
        g_timerRaised = FALSE;
    }
    g_jobValid = FALSE;
    InterlockedExchange(&g_state, AC_STATE_IDLE);
    InterlockedExchange(&g_running, 0);
    return FALSE;
}

void AcClickerStop(void)
{
    if (InterlockedCompareExchange(&g_state, AC_STATE_STOPPING, AC_STATE_RUNNING) != AC_STATE_RUNNING)
        return;

    if (g_stopEvent)
        SetEvent(g_stopEvent);
}

void AcClickerWait(void)
{
    if (g_thread)
    {
        WaitForSingleObject(g_thread, AC_STOP_WAIT_MS);
        CloseHandle(g_thread);
        g_thread = NULL;
    }

    if (g_timerRaised)
    {
        timeEndPeriod(1);
        g_timerRaised = FALSE;
    }

    g_jobValid = FALSE;
    InterlockedExchange(&g_state, AC_STATE_IDLE);
    InterlockedExchange(&g_running, 0);
}

// Reaps a worker that finished on its own (repeat count reached). Must be
// called from the UI thread; returns TRUE if the state changed to idle.
BOOL AcClickerPoll(void)
{
    if (g_thread == NULL)
        return FALSE;

    if (WaitForSingleObject(g_thread, 0) != WAIT_OBJECT_0)
        return FALSE;

    CloseHandle(g_thread);
    g_thread = NULL;

    if (g_timerRaised)
    {
        timeEndPeriod(1);
        g_timerRaised = FALSE;
    }

    InterlockedExchange(&g_state, AC_STATE_IDLE);
    InterlockedExchange(&g_running, 0);
    return TRUE;
}

BOOL AcClickerIsRunning(void)
{
    return (g_thread != NULL && g_state == AC_STATE_RUNNING) ? TRUE : FALSE;
}

AcRunState AcClickerGetState(void)
{
    return (AcRunState)g_state;
}

unsigned long long AcClickerGetClickCount(void)
{
    return (unsigned long long)InterlockedCompareExchange64((volatile LONG64 *)&g_clickCount, 0, 0);
}

ULONGLONG AcClickerGetStartTick(void)
{
    return g_startTick;
}
