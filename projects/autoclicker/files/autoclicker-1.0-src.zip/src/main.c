// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Auto Clicker - window, message loop and application logic.
//
// Written in C99 against the plain Win32 API. No frameworks, no runtime
// dependencies beyond what ships with Windows.
//

/*

    Compile under MS Build Tools (preferred):

        build.bat

    or by hand, from an "x64 Native Tools" prompt:

        rc /nologo /fo autoclicker.res autoclicker.rc
        cl /nologo /O2 /W4 /utf-8 src\*.c autoclicker.res /Fe:autoclicker.exe ^
           /link user32.lib gdi32.lib shell32.lib advapi32.lib winmm.lib ^
           comctl32.lib dwmapi.lib /SUBSYSTEM:WINDOWS ^
           /MANIFEST:EMBED /MANIFESTINPUT:autoclicker.manifest


    Compile under MSYS / GCC:

        build_msys.bat

    or by hand:

        windres autoclicker.rc -O coff -o autoclicker.res
        gcc -std=c99 -O2 -Wall -Wextra -mwindows -o autoclicker.exe all sources
            autoclicker.res -luser32 -lgdi32 -lshell32 -ladvapi32 -lwinmm \
            -lcomctl32 -ldwmapi

*/

#include <windows.h>
#include <windowsx.h>
#include <dwmapi.h>

#include "common.h"
#include "theme.h"
#include "config.h"
#include "clicker.h"
#include "hotkey.h"
#include "ui.h"
#include "ui_id.h"

#ifndef DWMWA_USE_IMMERSIVE_DARK_MODE
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#endif

#define TIMER_TICK 1
#define TIMER_PICK 2
#define TIMER_RUN  3

#define TICK_MS    40
#define RUN_MS     100

static HWND    g_hwnd      = NULL;
static UINT    g_dpi       = 96;
static BOOL    g_picking   = FALSE;
static BOOL    g_recording = FALSE;
static UINT    g_pickLeft  = 0;
static wchar_t g_status[160] = L"";

// ---------------------------------------------------------------------------
// Dark window frame
// ---------------------------------------------------------------------------

static void ApplyDarkFrame(HWND hwnd)
{
    BOOL    dark = AcDarkModeEnabled();
    HMODULE dwm  = LoadLibraryW(L"dwmapi.dll");

    if (dwm)
    {
        typedef HRESULT (WINAPI *PFN_DwmSetWindowAttribute)(HWND, DWORD, LPCVOID, DWORD);
        PFN_DwmSetWindowAttribute fn =
            (PFN_DwmSetWindowAttribute)(void *)GetProcAddress(dwm, "DwmSetWindowAttribute");

        if (fn)
        {
            fn(hwnd, (DWORD)DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof(dark));
            fn(hwnd, 19u, &dark, sizeof(dark)); // pre-20H1 attribute id
        }
        FreeLibrary(dwm);
    }
}

// ---------------------------------------------------------------------------
// Status line
// ---------------------------------------------------------------------------

static void UpdateStatus(void)
{
    AcUiStatus         st;
    unsigned long long clicks;
    ULONGLONG          started;
    AcRunState         state = AcClickerGetState();

    ZeroMemory(&st, sizeof(st));

    clicks  = AcClickerGetClickCount();
    started = AcClickerGetStartTick();

    st.clicks     = clicks;
    st.intervalMs = (int)g_settings.intervalMs;
    st.running    = (state == AC_STATE_RUNNING);
    st.canRun     = (state == AC_STATE_IDLE);

    AcHotkeyFormat(g_settings.hotkeyVk, g_settings.hotkeyMods, st.hotkeyText, 64);

    if (g_recording)
    {
        wcsncpy(g_status, L"Press the key combination\u2026", 160);
    }
    else if (g_picking)
    {
        _snwprintf(g_status, 160, L"Pick location in %u\u2026", g_pickLeft);
    }
    else if (state == AC_STATE_RUNNING)
    {
        ULONGLONG secs = (GetTickCount64() - started) / 1000;

        _snwprintf(g_status, 160, L"Running: %llu clicks, %llu:%02llu",
                   clicks, secs / 60, secs % 60);
    }
    else if (state == AC_STATE_STOPPING)
    {
        wcsncpy(g_status, L"Stopping\u2026", 160);
    }
    else if (clicks > 0)
    {
        _snwprintf(g_status, 160, L"Done: %llu clicks", clicks);
    }
    else
    {
        wcsncpy(g_status, L"Ready: %u ms interval", 160);
        _snwprintf(g_status, 160, L"Ready: %u ms interval", g_settings.intervalMs);
    }

    g_status[159] = L'\0';
    wcsncpy(st.statusText, g_status, 160);
    st.statusText[159] = L'\0';

    AcUiSetStatus(&st);
    AcUiRelayout();
}

// ---------------------------------------------------------------------------
// DPI plumbing
// ---------------------------------------------------------------------------

static UINT QueryDpi(HWND hwnd)
{
    typedef UINT (WINAPI *PFN_GetDpiForWindow)(HWND);
    static PFN_GetDpiForWindow fn = NULL;
    static BOOL tried = FALSE;

    if (!tried)
    {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32)
            fn = (PFN_GetDpiForWindow)(void *)GetProcAddress(user32, "GetDpiForWindow");
        tried = TRUE;
    }

    if (fn)
    {
        UINT dpi = fn(hwnd);
        if (dpi)
            return dpi;
    }
    return 96;
}

static void AdjustForDpi(RECT *rc, HWND hwnd, UINT dpi)
{
    typedef BOOL (WINAPI *PFN_AdjustWindowRectExForDpi)(RECT *, DWORD, BOOL, DWORD, UINT);
    static PFN_AdjustWindowRectExForDpi fn = NULL;
    static BOOL tried = FALSE;

    if (!tried)
    {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32)
            fn = (PFN_AdjustWindowRectExForDpi)(void *)GetProcAddress(user32, "AdjustWindowRectExForDpi");
        tried = TRUE;
    }

    if (fn)
        fn(rc, GetWindowLongW(hwnd, GWL_STYLE), FALSE, GetWindowLongW(hwnd, GWL_EXSTYLE), dpi);
    else
        AdjustWindowRectEx(rc, GetWindowLongW(hwnd, GWL_STYLE), FALSE, GetWindowLongW(hwnd, GWL_EXSTYLE));
}

static void ApplyMetrics(HWND hwnd, UINT dpi, BOOL resizeToFit)
{
    RECT rc;

    g_dpi = dpi;
    AcMetricsInit(dpi);

    if (resizeToFit)
    {
        RECT want = { 0, 0, AcScale(AC_BASE_W), AcScale(AC_BASE_H) };

        AdjustForDpi(&want, hwnd, dpi);

        SetWindowPos(hwnd, NULL, 0, 0,
                     want.right - want.left, want.bottom - want.top,
                     SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    }

    GetClientRect(hwnd, &rc);
    AcUiLayout(rc.right - rc.left, rc.bottom - rc.top);
    InvalidateRect(hwnd, NULL, FALSE);
}

// ---------------------------------------------------------------------------
// Clicking
// ---------------------------------------------------------------------------

static void StartClicking(void)
{
    AcRunJob job;

    if (AcClickerGetState() != AC_STATE_IDLE)
        return;

    AcUiCommitToSettings();

    ZeroMemory(&job, sizeof(job));
    job.settings    = g_settings;
    job.totalClicks = g_settings.repeatUntilStopped ? 0u : (UINT)g_settings.repeatCount;
    job.useTarget   = (g_settings.cursorMode == AC_CURSOR_FIXED);
    job.target      = g_settings.fixedPoint;

    if (!AcClickerStart(&job))
    {
        MessageBoxW(g_hwnd, L"Could not start the clicker.", AC_APP_NAME,
                    MB_ICONERROR | MB_OK);
        return;
    }

    SetTimer(g_hwnd, TIMER_RUN, RUN_MS, NULL);
    UpdateStatus();
    InvalidateRect(g_hwnd, NULL, FALSE);
}

static void StopClicking(void)
{
    if (AcClickerGetState() == AC_STATE_IDLE)
        return;

    AcClickerStop();
    AcClickerWait();
    KillTimer(g_hwnd, TIMER_RUN);
    UpdateStatus();
    InvalidateRect(g_hwnd, NULL, FALSE);
}

// ---------------------------------------------------------------------------
// Hotkey recording
// ---------------------------------------------------------------------------

static BOOL IsModifierKey(int vk)
{
    return (vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU ||
            vk == VK_LWIN  || vk == VK_RWIN);
}

static void EndRecording(BOOL accepted, int vk, int mods)
{
    g_recording = FALSE;
    AcUiSetRecording(FALSE);

    if (!accepted)
    {
        UpdateStatus();
        InvalidateRect(g_hwnd, NULL, FALSE);
        return;
    }

    if (vk == 0)
    {
        AcHotkeyRelease(g_hwnd);
        g_settings.hotkeyVk   = 0;
        g_settings.hotkeyMods = 0;
    }
    else if (!AcHotkeyApply(g_hwnd, (UINT)vk, (UINT)mods))
    {
        wchar_t combo[64];
        wchar_t msg[256];

        AcHotkeyFormat((UINT)vk, (UINT)mods, combo, 64);
        _snwprintf(msg, 256,
                   L"%s is already taken by another program.\n"
                   L"The previous hotkey is kept.", combo);
        msg[255] = L'\0';

        AcHotkeyApply(g_hwnd, g_settings.hotkeyVk, g_settings.hotkeyMods);
        MessageBoxW(g_hwnd, msg, AC_APP_NAME, MB_ICONWARNING | MB_OK);
    }
    else
    {
        g_settings.hotkeyVk   = (UINT)vk;
        g_settings.hotkeyMods = (UINT)mods;
    }

    AcConfigSave(&g_settings);
    UpdateStatus();
    InvalidateRect(g_hwnd, NULL, FALSE);
}

// ---------------------------------------------------------------------------
// UI notification
// ---------------------------------------------------------------------------

static void OnUiNotify(int widget)
{
    switch (widget)
    {
    case ACW_START:
        StartClicking();
        break;

    case ACW_STOP:
        StopClicking();
        break;

    case ACW_HOTKEY:
        g_recording = TRUE;
        AcUiSetRecording(TRUE);
        UpdateStatus();
        break;

    case ACW_PICK:
        if (AcClickerGetState() == AC_STATE_IDLE && !g_picking)
        {
            g_picking  = TRUE;
            g_pickLeft = 3;
            SetTimer(g_hwnd, TIMER_PICK, 1000, NULL);
            UpdateStatus();
        }
        break;

    default:
        UpdateStatus();
        break;
    }

    InvalidateRect(g_hwnd, NULL, FALSE);
}

// ---------------------------------------------------------------------------
// Window procedure
// ---------------------------------------------------------------------------

static LRESULT OnCreate(HWND hwnd)
{
    g_hwnd = hwnd;

    AcThemeInit();
    ApplyDarkFrame(hwnd);

    AcConfigLoad(&g_settings);
    AcUiLoadFromSettings();
    AcUiSetNotify(OnUiNotify);

    if (!AcHotkeyApply(hwnd, g_settings.hotkeyVk, g_settings.hotkeyMods))
    {
        g_settings.hotkeyVk   = 0;
        g_settings.hotkeyMods = 0;
    }

    // Metrics and the initial size are applied by wWinMain once the window is
    // associated with a monitor: GetDpiForWindow() is not reliable yet inside
    // WM_CREATE, and a wrong guess here would leave the UI at 96 DPI.
    SetTimer(hwnd, TIMER_TICK, TICK_MS, NULL);
    return 0;
}

static void OnDestroy(HWND hwnd)
{
    KillTimer(hwnd, TIMER_TICK);
    KillTimer(hwnd, TIMER_PICK);
    KillTimer(hwnd, TIMER_RUN);

    if (AcClickerGetState() != AC_STATE_IDLE)
    {
        AcClickerStop();
        AcClickerWait();
    }

    AcHotkeyRelease(hwnd);
    AcUiCommitToSettings();
    AcConfigSave(&g_settings);
    AcMetricsFree();

    PostQuitMessage(0);
}

static void PaintWindow(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT        rc;
    HDC         dc;
    HDC         mem;
    HBITMAP     bmp;
    HGDIOBJ     old;

    dc = BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);

    if (rc.right <= 0 || rc.bottom <= 0)
    {
        EndPaint(hwnd, &ps);
        return;
    }

    mem = CreateCompatibleDC(dc);
    bmp = CreateCompatibleBitmap(dc, rc.right, rc.bottom);
    old = SelectObject(mem, bmp);

    AcUiPaint(mem);

    BitBlt(dc, 0, 0, rc.right, rc.bottom, mem, 0, 0, SRCCOPY);

    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);

    EndPaint(hwnd, &ps);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
        return OnCreate(hwnd);

    case WM_DESTROY:
        OnDestroy(hwnd);
        return 0;

    case WM_CLOSE:
        StopClicking();
        DestroyWindow(hwnd);
        return 0;

    case WM_PAINT:
        PaintWindow(hwnd);
        return 0;

    case WM_ERASEBKGND:
        return 1;

    case WM_GETMINMAXINFO:
    {
        MINMAXINFO *mmi  = (MINMAXINFO *)lParam;
        RECT        want = { 0, 0, AcScale(AC_MIN_W), AcScale(AC_MIN_H) };

        // Never derive the frame size from the current window geometry: while
        // the window is minimised GetClientRect() is (0,0), which used to make
        // the minimum track size (and therefore the restored width) drift.
        AdjustForDpi(&want, hwnd, g_metrics.dpi);

        mmi->ptMinTrackSize.x = want.right - want.left;
        mmi->ptMinTrackSize.y = want.bottom - want.top;
        return 0;
    }

    case WM_SIZE:
        AcUiLayout(LOWORD(lParam), HIWORD(lParam));
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_DPICHANGED:
    {
        RECT *sug = (RECT *)lParam;
        RECT  want = { 0, 0, AcScale(AC_BASE_W), AcScale(AC_BASE_H) };
        RECT  rc;

        // The window is fixed-size, so the "suggested" rectangle is only used
        // for its position: the size always follows our design at the new DPI.
        g_dpi = HIWORD(wParam);
        AcMetricsInit(g_dpi);
        AdjustForDpi(&want, hwnd, g_dpi);

        SetWindowPos(hwnd, NULL, sug->left, sug->top,
                     want.right - want.left, want.bottom - want.top,
                     SWP_NOZORDER | SWP_NOACTIVATE);

        GetClientRect(hwnd, &rc);
        AcUiLayout(rc.right - rc.left, rc.bottom - rc.top);
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_TIMER:
        switch (wParam)
        {
        case TIMER_TICK:
            AcUiTick();
            if (AcUiIsEditing())
                InvalidateRect(hwnd, NULL, FALSE);
            if (AcClickerGetState() != AC_STATE_IDLE)
            {
                UpdateStatus();
                InvalidateRect(hwnd, NULL, FALSE);
            }
            return 0;

        case TIMER_PICK:
            if (g_pickLeft > 0)
                g_pickLeft--;

            if (g_pickLeft == 0)
            {
                POINT pt;

                GetCursorPos(&pt);
                KillTimer(hwnd, TIMER_PICK);
                g_picking = FALSE;

                AcUiSetCursorMode(TRUE);
                AcUiSetFixedPoint(pt);
            }

            UpdateStatus();
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;

        case TIMER_RUN:
            AcClickerPoll();
            UpdateStatus();
            InvalidateRect(hwnd, NULL, FALSE);

            if (AcClickerGetState() == AC_STATE_IDLE)
                KillTimer(hwnd, TIMER_RUN);
            return 0;

        default:
            return 0;
        }

    case WM_MOUSEMOVE:
    {
        TRACKMOUSEEVENT tme;

        tme.cbSize      = sizeof(tme);
        tme.dwFlags     = TME_LEAVE;
        tme.hwndTrack   = hwnd;
        tme.dwHoverTime = 0;
        TrackMouseEvent(&tme);

        if (AcUiOnMouseMove(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_MOUSEWHEEL:
    {
        POINT pt;

        pt.x = GET_X_LPARAM(lParam);
        pt.y = GET_Y_LPARAM(lParam);
        ScreenToClient(hwnd, &pt);

        if (AcUiOnMouseWheel(pt.x, pt.y, GET_WHEEL_DELTA_WPARAM(wParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_MOUSELEAVE:
        if (AcUiOnMouseLeave())
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_LBUTTONDOWN:
        SetCapture(hwnd);
        SetFocus(hwnd);
        SetActiveWindow(hwnd);

        if (AcUiOnMouseDown(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_LBUTTONUP:
        if (AcUiOnMouseUp(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);

        if (GetCapture() == hwnd)
            ReleaseCapture();
        return 0;

    case WM_ACTIVATE:
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_CAPTURECHANGED:
        AcUiOnCaptureLost();
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_KEYDOWN:
        if (g_recording)
        {
            int vk = (int)wParam;

            if (vk == VK_ESCAPE)
            {
                EndRecording(FALSE, 0, 0);
                return 0;
            }

            if (!IsModifierKey(vk))
            {
                int mods = 0;

                if (GetKeyState(VK_CONTROL) & 0x8000) mods |= MOD_CONTROL;
                if (GetKeyState(VK_SHIFT)   & 0x8000) mods |= MOD_SHIFT;
                if (GetKeyState(VK_MENU)    & 0x8000) mods |= MOD_ALT;
                if ((GetKeyState(VK_LWIN) & 0x8000) || (GetKeyState(VK_RWIN) & 0x8000))
                    mods |= MOD_WIN;

                if ((vk >= 'A' && vk <= 'Z') && mods == 0)
                {
                    // A bare letter would swallow normal typing everywhere.
                    MessageBoxW(hwnd, L"Please add Ctrl, Alt, Shift or Win to a letter key.",
                                AC_APP_NAME, MB_ICONINFORMATION | MB_OK);
                    return 0;
                }

                EndRecording(TRUE, vk, mods);
            }
            return 0;
        }

        if (AcUiOnKeyDown((int)wParam))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_CHAR:
        if (!g_recording && AcUiOnChar((wchar_t)wParam))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_KILLFOCUS:
        if (g_recording)
            EndRecording(FALSE, 0, 0);
        return 0;

    case WM_HOTKEY:
        if (g_recording)
            return 0;

        if ((UINT)wParam == AC_HOTKEY_ID_START || (UINT)wParam == AC_HOTKEY_ID_STOP)
        {
            if (AcClickerGetState() == AC_STATE_RUNNING)
                StopClicking();
            else if (AcClickerGetState() == AC_STATE_IDLE)
                StartClicking();

            InvalidateRect(hwnd, NULL, FALSE);
            return 0;
        }
        break;

    case WM_SETTINGCHANGE:
        if (wParam == SPI_SETHIGHCONTRAST)
        {
            AcThemeInit();
            InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;

    default:
        break;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, PWSTR cmdline, int show)
{
    WNDCLASSEXW wc;
    MSG         msg;
    HWND        hwnd;
    HMONITOR    mon;

    (void)prev; (void)cmdline;

    g_instance = inst;

    // DPI awareness is declared in the manifest (PerMonitorV2). The runtime
    // call is deliberately NOT repeated here: calling it after the first
    // window exists is rejected by Windows, and calling it before CreateWindow
    // while the manifest already set the mode is unnecessary.

    ZeroMemory(&wc, sizeof(wc));
    wc.cbSize        = sizeof(wc);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = inst;
    wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
    wc.hIcon         = LoadIconW(inst, MAKEINTRESOURCEW(1));
    wc.hIconSm       = wc.hIcon;
    wc.hbrBackground = NULL;
    wc.lpszClassName = AC_WINDOW_CLASS;

    if (!RegisterClassExW(&wc))
        return 0;

    hwnd = CreateWindowExW(0, AC_WINDOW_CLASS, AC_APP_NAME,
                           WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
                           CW_USEDEFAULT, CW_USEDEFAULT,
                           AcScale(AC_BASE_W), AcScale(AC_BASE_H),
                           NULL, NULL, inst, NULL);

    if (hwnd == NULL)
        return 0;

    ApplyMetrics(hwnd, QueryDpi(hwnd), TRUE);
    UpdateStatus();

    mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
    if (mon)
    {
        MONITORINFO mi;
        RECT        wr;
        int         x, y;

        mi.cbSize = sizeof(mi);
        if (GetMonitorInfoW(mon, &mi))
        {
            GetWindowRect(hwnd, &wr);
            x = mi.rcWork.left + ((mi.rcWork.right - mi.rcWork.left) - (wr.right - wr.left)) / 2;
            y = mi.rcWork.top  + ((mi.rcWork.bottom - mi.rcWork.top) - (wr.bottom - wr.top)) / 2;
            SetWindowPos(hwnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }

    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);

    while (GetMessageW(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return (int)msg.wParam;
}
