Russian Doom PNG fonts
----------------------

PNG font atlases from Russian Doom project
http://jnechaevsky.sf.net/rusdoom

Feel free to use them for any noncommercial purposes.


-Julian Nechaevsky
11:37 16.09.2018