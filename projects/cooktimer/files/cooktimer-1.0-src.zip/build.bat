@echo off
setlocal

rem ---------------------------------------------------------------------------
rem Cook Timer - build with the Microsoft C toolchain.
rem
rem Requires "Build Tools for Visual Studio" (or complete Visual Studio) with
rem the "Desktop development with C++" workload. Run this file from anywhere;
rem it locates vcvars64.bat automatically.
rem ---------------------------------------------------------------------------

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
    echo [error] vswhere.exe not found. Install "Build Tools for Visual Studio".
    exit /b 1
)

for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSDIR=%%i"

if not defined VSDIR (
    echo [error] Visual Studio installation with C++ tools not found.
    exit /b 1
)

call "%VSDIR%\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 (
    echo [error] Could not initialise the MSVC environment.
    exit /b 1
)

echo [1/2] Compiling resources...
rc /nologo /fo cooktimer.res cooktimer.rc
if errorlevel 1 goto fail

echo [2/2] Compiling and linking...
cl /nologo /O2 /W4 /utf-8 /DUNICODE /D_UNICODE /D_CRT_SECURE_NO_WARNINGS ^
    src\main.c src\ui.c src\theme.c src\config.c src\countdown.c src\bell.c src\taskbar.c ^
    cooktimer.res /Fe:cooktimer.exe ^
    /link user32.lib gdi32.lib shell32.lib advapi32.lib winmm.lib comctl32.lib dwmapi.lib ^
    ole32.lib uuid.lib /SUBSYSTEM:WINDOWS /MANIFEST:NO
if errorlevel 1 goto fail

echo.
echo Build finished: cooktimer.exe
exit /b 0

:fail
echo.
echo Build failed.
exit /b 1
