// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - the countdown itself.
//
// State is derived from one absolute deadline instead of a decremented
// counter, so a late WM_TIMER tick can never make the timer drift. The UI
// thread owns this module; there is no worker thread to synchronise with.
//

#include "common.h"
#include "countdown.h"
#include "bell.h"

static CtState   g_state      = CT_STATE_IDLE;
static int       g_totalSec   = 3 * 60;
static int       g_pausedSec  = 3 * 60;
static ULONGLONG g_deadline   = 0;
static ULONGLONG g_restartAt  = 0;
static int       g_round      = 1;
static BOOL      g_autoRestart = FALSE;
static BOOL      g_ringForever = FALSE;

static int CeilRemaining(void)
{
    ULONGLONG now  = GetTickCount64();
    ULONGLONG left = (g_deadline > now) ? (g_deadline - now) : 0;

    if (left == 0)
        return 0;

    return (int)((left + 999) / 1000);
}

void CtSetDuration(int seconds)
{
    if (g_state != CT_STATE_IDLE)
        return;

    g_totalSec  = CtClampInt(seconds, 0, CT_MAX_TOTAL_SEC);
    g_pausedSec = g_totalSec;
}

void CtStart(void)
{
    if (g_state != CT_STATE_IDLE)
        return;

    if (g_totalSec < CT_MIN_TOTAL_SEC)
        return;

    CtBellStop();

    g_deadline = GetTickCount64() + (ULONGLONG)g_totalSec * 1000ULL;
    g_round    = 1;
    g_state    = CT_STATE_RUNNING;
}

void CtPause(void)
{
    if (g_state != CT_STATE_RUNNING)
        return;

    g_pausedSec = CeilRemaining();
    if (g_pausedSec < 1)
        g_pausedSec = 1;

    g_state = CT_STATE_PAUSED;
}

void CtResume(void)
{
    if (g_state != CT_STATE_PAUSED)
        return;

    g_deadline = GetTickCount64() + (ULONGLONG)g_pausedSec * 1000ULL;
    g_state    = CT_STATE_RUNNING;
}

void CtReset(void)
{
    CtBellStop();

    g_state     = CT_STATE_IDLE;
    g_pausedSec = g_totalSec;
    g_round     = 1;
    g_restartAt = 0;
}

void CtSetAutoRestart(BOOL on)
{
    g_autoRestart = on;

    // Turning it on while the bell is already sounding should still work;
    // turning it off during the short pause before a restart must cancel it.
    if (g_state == CT_STATE_DONE)
    {
        if (on && g_restartAt == 0)
            g_restartAt = GetTickCount64() + CT_RESTART_DELAY_MS;
        else if (!on)
            g_restartAt = 0;
    }
}

void CtSetRingForever(BOOL on)
{
    g_ringForever = on;

    if (g_state == CT_STATE_DONE)
    {
        // Unchecking "Ring forever" while the alarm sounds should silence it;
        // checking it mid-ring turns the one-shot pattern into a loop.
        CtBellStop();
        if (on)
            CtBellStart(TRUE);
    }
}

static void BeginRestart(void)
{
    if (g_totalSec < CT_MIN_TOTAL_SEC)
    {
        g_state = CT_STATE_DONE;
        return;
    }

    CtBellStop();

    g_round++;
    g_deadline  = GetTickCount64() + (ULONGLONG)g_totalSec * 1000ULL;
    g_restartAt = 0;
    g_state     = CT_STATE_RUNNING;
}

static void HandleTimeUp(void)
{
    g_pausedSec = 0;
    g_state     = CT_STATE_DONE;

    CtBellStart(g_ringForever);

    if (g_autoRestart && g_totalSec >= CT_MIN_TOTAL_SEC)
        g_restartAt = GetTickCount64() + CT_RESTART_DELAY_MS;
    else
        g_restartAt = 0;
}

void CtTick(void)
{
    ULONGLONG now = GetTickCount64();

    if (g_state == CT_STATE_RUNNING)
    {
        if (now >= g_deadline)
            HandleTimeUp();
        return;
    }

    if (g_state == CT_STATE_DONE && g_restartAt != 0 && now >= g_restartAt)
        BeginRestart();
}

CtState CtGetState(void)
{
    return g_state;
}

int CtGetTotalSec(void)
{
    return g_totalSec;
}

int CtGetRemainingSec(void)
{
    switch (g_state)
    {
    case CT_STATE_RUNNING: return CeilRemaining();
    case CT_STATE_PAUSED:  return g_pausedSec;
    case CT_STATE_DONE:    return 0;
    default:               return g_totalSec;
    }
}

int CtGetDisplaySec(void)
{
    return (g_state == CT_STATE_IDLE) ? g_totalSec : CtGetRemainingSec();
}

int CtGetRound(void)
{
    return g_round;
}

void CtFormatClock(int seconds, wchar_t *buf, int cch)
{
    int h, m, s;

    if (buf == NULL || cch <= 0)
        return;

    seconds = CtClampInt(seconds, 0, CT_MAX_TOTAL_SEC);

    h = seconds / 3600; seconds %= 3600;
    m = seconds / 60;
    s = seconds % 60;

    _snwprintf(buf, (size_t)cch, L"%02d:%02d:%02d", h, m, s);
    buf[cch - 1] = L'\0';
}
