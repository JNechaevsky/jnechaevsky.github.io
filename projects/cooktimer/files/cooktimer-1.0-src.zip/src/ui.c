// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - self drawn control surface.
//
// Everything inside the client area is painted by hand, same as in the Auto
// Clicker: stock buttons and edits cannot follow a dark palette, and mixing
// themed and unthemed controls looks worse than drawing all of them.
//
// Layers: layout (rectangles), painting (pure GDI), input (mutates g_ui and
// asks the owner window to react through the notification callback).
//

#include "common.h"
#include "theme.h"
#include "countdown.h"
#include "ui.h"
#include "ui_id.h"

#define CT_CARET_BLINK_MS 530

typedef struct
{
    RECT rc;
    BOOL enabled;
    BOOL hover;
    BOOL pressed;
} CtBox;

CtUiState g_ui;

static CtBox      g_box[CTW_COUNT];

static RECT       g_presetsRc;
static RECT       g_presetRc[4];
static RECT       g_presetRadioRc[4];
static RECT       g_presetLabelRc[4];
static int        g_presetLabelW[4];

static RECT       g_fieldsRc;
static RECT       g_fieldRc[3];
static RECT       g_fieldLabelRc[3];
static RECT       g_spinRc[3][2];

static RECT       g_clockRc;

static RECT       g_progressRc;
static RECT       g_barRc;
static RECT       g_progressTitleRc;

static RECT       g_checkRc[2];
static RECT       g_checkLabelRc[2];
static int        g_dividerX;

static int        g_clientW    = 0;
static int        g_clientH    = 0;
static int        g_focus      = -1;
static int        g_hot        = -1;
static int        g_pressed    = -1;
static int        g_spinHot    = -1;
static int        g_spinHotDir = 0;
static int        g_editPos    = 0;
static BOOL       g_zeroSlot   = FALSE;
static DWORD      g_caretTick  = 0;
static BOOL       g_caretOn    = TRUE;
static CtUiNotify g_notify     = NULL;

static const wchar_t *kPresetNames[4] = { L"3 min", L"5 min", L"10 min", L"Custom" };
static const wchar_t *kFieldNames[3]  = { L"Hours", L"Minutes", L"Seconds" };

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

static RECT RectL(int l, int t, int r, int b)
{
    RECT rc;
    rc.left = l; rc.top = t; rc.right = r; rc.bottom = b;
    return rc;
}

static int RectH(const RECT *rc) { return rc->bottom - rc->top; }

static BOOL Hit(const RECT *rc, int x, int y)
{
    return (x >= rc->left && x < rc->right && y >= rc->top && y < rc->bottom) ? TRUE : FALSE;
}

static void InsetRect(RECT *rc, int dx, int dy)
{
    rc->left += dx; rc->right -= dx;
    rc->top  += dy; rc->bottom -= dy;
}

static BOOL IsField(int id)
{
    return (id >= CTW_HOURS && id <= CTW_SECS) ? TRUE : FALSE;
}

static wchar_t *FieldText(int id)
{
    switch (id)
    {
    case CTW_HOURS: return g_ui.hours;
    case CTW_MINS:  return g_ui.mins;
    case CTW_SECS:  return g_ui.secs;
    default:        return NULL;
    }
}

static int PresetSeconds(int preset)
{
    switch (preset)
    {
    case CT_PRESET_3:  return 3 * 60;
    case CT_PRESET_5:  return 5 * 60;
    case CT_PRESET_10: return 10 * 60;
    default:           return 0;
    }
}

static int FieldLimit(int id)
{
    switch (id)
    {
    case CTW_HOURS: return CT_MAX_HOURS;
    case CTW_MINS:  return CT_MAX_MINUTES;
    default:        return CT_MAX_SECONDS;
    }
}

static int ParseInt(const wchar_t *text, int lo, int hi, int fallback)
{
    wchar_t *end = NULL;
    long     v;

    if (text == NULL || text[0] == L'\0')
        return fallback;

    v = wcstol(text, &end, 10);
    if (end == text)
        return fallback;

    if (v < (long)lo) v = (long)lo;
    if (v > (long)hi) v = (long)hi;
    return (int)v;
}

static void FormatInt(wchar_t *buf, int len, int value)
{
    _snwprintf(buf, (size_t)len, L"%d", value);
    buf[len - 1] = L'\0';
}

int CtUiDurationSec(void)
{
    int h = ParseInt(g_ui.hours, 0, CT_MAX_HOURS, 0);
    int m = ParseInt(g_ui.mins,  0, CT_MAX_MINUTES, 0);
    int s = ParseInt(g_ui.secs,  0, CT_MAX_SECONDS, 0);

    return h * 3600 + m * 60 + s;
}

static int MeasureText(const wchar_t *text)
{
    HDC   dc = GetDC(NULL);
    SIZE  sz = { 0, 0 };
    HFONT old;

    if (dc == NULL)
        return 0;

    old = (HFONT)SelectObject(dc, g_metrics.font);
    GetTextExtentPoint32W(dc, text, (int)wcslen(text), &sz);
    SelectObject(dc, old);
    ReleaseDC(NULL, dc);
    return sz.cx;
}

// ---------------------------------------------------------------------------
// State <-> settings
// ---------------------------------------------------------------------------

void CtUiLoadFromSettings(void)
{
    int total;

    g_ui.preset      = g_settings.preset;
    g_ui.autoRestart = g_settings.autoRestart;
    g_ui.ringForever = g_settings.ringForever;

    if (g_ui.preset != CT_PRESET_CUSTOM)
        total = PresetSeconds(g_ui.preset);
    else
        total = g_settings.hours * 3600 + g_settings.mins * 60 + g_settings.secs;

    FormatInt(g_ui.hours, CT_FIELD_LEN, total / 3600);
    FormatInt(g_ui.mins,  CT_FIELD_LEN, (total / 60) % 60);
    FormatInt(g_ui.secs,  CT_FIELD_LEN, total % 60);

    CtSetDuration(total);
    CtSetAutoRestart(g_ui.autoRestart);
    CtSetRingForever(g_ui.ringForever);
}

void CtUiCommitToSettings(void)
{
    int h = ParseInt(g_ui.hours, 0, CT_MAX_HOURS, 0);
    int m = ParseInt(g_ui.mins,  0, CT_MAX_MINUTES, 0);
    int s = ParseInt(g_ui.secs,  0, CT_MAX_SECONDS, 0);
    int total = h * 3600 + m * 60 + s;

    FormatInt(g_ui.hours, CT_FIELD_LEN, h);
    FormatInt(g_ui.mins,  CT_FIELD_LEN, m);
    FormatInt(g_ui.secs,  CT_FIELD_LEN, s);

    g_settings.preset = g_ui.preset;
    g_settings.hours  = h;
    g_settings.mins   = m;
    g_settings.secs   = s;

    if (g_settings.autoRestart != g_ui.autoRestart)
    {
        g_settings.autoRestart = g_ui.autoRestart;
        CtSetAutoRestart(g_ui.autoRestart);
    }

    if (g_settings.ringForever != g_ui.ringForever)
    {
        g_settings.ringForever = g_ui.ringForever;
        CtSetRingForever(g_ui.ringForever);
    }

    CtSetDuration(total);
}

static void Notify(int widget)
{
    CtUiCommitToSettings();

    if (g_notify)
        g_notify(widget);
}

// While the user types, the big clock and the Start button should already
// follow the draft value. The engine is updated, but the fields are not
// normalised here - that only happens on commit, so editing is never fought.
static void DraftChanged(void)
{
    if (CtGetState() == CT_STATE_IDLE)
        CtSetDuration(CtUiDurationSec());
}

static void SelectPreset(int preset)
{
    int total;

    if (preset < CT_PRESET_3 || preset >= CT_PRESET_COUNT)
        return;

    g_ui.preset = (CtPreset)preset;

    if (preset != CT_PRESET_CUSTOM)
    {
        total = PresetSeconds(preset);
        FormatInt(g_ui.hours, CT_FIELD_LEN, total / 3600);
        FormatInt(g_ui.mins,  CT_FIELD_LEN, (total / 60) % 60);
        FormatInt(g_ui.secs,  CT_FIELD_LEN, total % 60);
    }

    g_focus = -1;
    Notify(CTW_PRESET_3 + preset);
}

void CtUiSetNotify(CtUiNotify notify)
{
    g_notify = notify;
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------

static void SetBox(int id, int x, int y, int w, int h, BOOL enabled)
{
    g_box[id].rc      = RectL(x, y, x + w, y + h);
    g_box[id].enabled = enabled;
}

void CtUiRelayout(void)
{
    if (g_clientW > 0 && g_clientH > 0)
        CtUiLayout(g_clientW, g_clientH);
}

void CtUiLayout(int clientW, int clientH)
{
    const int m       = CtScale(10);
    const int innerW  = clientW - m * 2;
    const int rightW  = CtScale(140);
    const int colGap  = CtScale(14);
    const int leftW   = innerW - rightW - colGap;
    const int leftX   = m;
    const int rightX  = m + leftW + colGap;
    const int titleH  = g_metrics.sectionTitleH;
    const int rowH    = g_metrics.rowH;
    const int btnH    = g_metrics.buttonH;
    const int radio   = g_metrics.radio;
    const int cb      = g_metrics.checkBox;
    const int padX    = CtScale(14);

    CtState state = CtGetState();
    BOOL    idle  = (state == CT_STATE_IDLE);
    BOOL    custom = (g_ui.preset == CT_PRESET_CUSTOM);
    int     fieldW, fieldGap, fieldsW, fieldX, labelH, fieldH;
    int     i, k;

    g_clientW = clientW;
    g_clientH = clientH;

    // ---- Presets ----------------------------------------------------------
    {
        int top    = m;
        int h      = titleH + CtScale(6) + rowH + CtScale(4);
        int rowY   = top + titleH + CtScale(6);
        int widths[4];
        int sum    = 0;
        int gap, total, x;

        g_presetsRc = RectL(leftX, top, leftX + leftW, top + h);

        for (i = 0; i < 4; i++)
        {
            g_presetLabelW[i] = MeasureText(kPresetNames[i]);
            widths[i] = radio + CtScale(6) + g_presetLabelW[i];
            sum += widths[i];
        }

        // Spread the choices evenly, but do not let the gaps grow into holes
        // or shrink until the labels touch.
        gap = (leftW - CtScale(20) - sum) / 3;
        gap = CtClampInt(gap, CtScale(10), CtScale(22));
        total = sum + gap * 3;

        x = leftX + (leftW - total) / 2;
        if (x < leftX + CtScale(6))
            x = leftX + CtScale(6);

        for (i = 0; i < 4; i++)
        {
            int ry = rowY + (rowH - radio) / 2;

            g_presetRc[i]      = RectL(x, rowY, x + widths[i], rowY + rowH);
            g_presetRadioRc[i] = RectL(x, ry, x + radio, ry + radio);
            g_presetLabelRc[i] = RectL(x + radio + CtScale(6), rowY,
                                       x + widths[i], rowY + rowH);
            SetBox(CTW_PRESET_3 + i, x, rowY, widths[i], rowH, idle);

            x += widths[i] + gap;
        }
    }

    // ---- Time fields ------------------------------------------------------
    {
        int labelTop = g_presetsRc.bottom + CtScale(4);

        labelH = g_metrics.smallLineH;
        fieldH = CtScale(28);
        fieldW = CtScale(80);
        fieldGap = CtScale(14);
        fieldsW = fieldW * 3 + fieldGap * 2;
        fieldX = leftX + (leftW - fieldsW) / 2;

        g_fieldsRc = RectL(leftX, labelTop, leftX + leftW, labelTop + CtScale(16) + fieldH);

        for (i = 0; i < 3; i++)
        {
            int x = fieldX + i * (fieldW + fieldGap);
            int y = labelTop + CtScale(16);

            g_fieldRc[i]      = RectL(x, y, x + fieldW, y + fieldH);
            g_fieldLabelRc[i] = RectL(x, labelTop, x + fieldW, labelTop + labelH);

            g_spinRc[i][0] = RectL(x + fieldW - CtScale(18), y, x + fieldW - 1, y + fieldH / 2);
            g_spinRc[i][1] = RectL(x + fieldW - CtScale(18), y + fieldH / 2, x + fieldW - 1, y + fieldH);

            SetBox(CTW_HOURS + i, x, y, fieldW, fieldH, idle && custom);
        }
    }

    // ---- Big clock --------------------------------------------------------
    {
        int top = g_fieldsRc.bottom + CtScale(2);
        int h   = CtScale(64);

        g_clockRc = RectL(leftX, top, leftX + leftW, top + h);
    }

    // ---- Progress panel ---------------------------------------------------
    {
        int h   = CtScale(50);
        int top = clientH - m - h;

        if (top < g_clockRc.bottom + CtScale(8))
            top = g_clockRc.bottom + CtScale(8);

        g_progressRc = RectL(leftX, top, leftX + innerW, top + h);

        g_progressTitleRc = RectL(leftX + padX, top + CtScale(8),
                                  leftX + innerW - padX, top + CtScale(8) + titleH);

        g_barRc = RectL(leftX + padX, top + CtScale(30),
                        leftX + innerW - padX, top + CtScale(30) + CtScale(10));
    }

    // ---- Right column -----------------------------------------------------
    {
        int startTop = g_presetsRc.top + CtScale(16);
        int startH   = btnH + CtScale(6);
        int resetTop = startTop + startH + CtScale(8);
        int resetH   = btnH + CtScale(2);
        int checkTop = resetTop + resetH + CtScale(22);

        g_dividerX = leftX + leftW + colGap / 2;

        SetBox(CTW_START, rightX, startTop, rightW, startH,
               !idle || CtUiDurationSec() >= CT_MIN_TOTAL_SEC);
        SetBox(CTW_RESET, rightX, resetTop, rightW, resetH, TRUE);

        for (k = 0; k < 2; k++)
        {
            int y = checkTop + k * CtScale(26);

            g_checkRc[k]      = RectL(rightX, y, rightX + cb, y + cb);
            g_checkLabelRc[k] = RectL(rightX + cb + CtScale(8), y - CtScale(4),
                                      rightX + rightW, y + cb);
        }

        SetBox(CTW_AUTORESTART, rightX, checkTop - CtScale(4), rightW, cb + CtScale(8), TRUE);
        SetBox(CTW_RINGFOREVER, rightX, checkTop + CtScale(26) - CtScale(4),
               rightW, cb + CtScale(8), TRUE);
    }
}

// ---------------------------------------------------------------------------
// Painting helpers
// ---------------------------------------------------------------------------

static void PushClip(HDC dc, const RECT *rc)
{
    SaveDC(dc);
    IntersectClipRect(dc, rc->left, rc->top, rc->right, rc->bottom);
}

static void PopClip(HDC dc)
{
    RestoreDC(dc, -1);
}

static void FillRectColor(HDC dc, const RECT *rc, COLORREF color)
{
    HBRUSH  brush = CreateSolidBrush(color);
    HGDIOBJ old   = SelectObject(dc, brush);

    FillRect(dc, rc, brush);

    SelectObject(dc, old);
    DeleteObject(brush);
}

static void FillRound(HDC dc, const RECT *rc, int radius, COLORREF fill, COLORREF outline)
{
    HBRUSH  brush = CreateSolidBrush(fill);
    HPEN    pen   = CreatePen(PS_SOLID, 1, outline);
    HGDIOBJ ob    = SelectObject(dc, brush);
    HGDIOBJ op    = SelectObject(dc, pen);

    if (radius > 0)
        RoundRect(dc, rc->left, rc->top, rc->right, rc->bottom, radius * 2, radius * 2);
    else
        Rectangle(dc, rc->left, rc->top, rc->right, rc->bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(brush);
    DeleteObject(pen);
}

static void TextOutRect(HDC dc, HFONT font, COLORREF color, const wchar_t *text,
                        const RECT *rc, UINT flags)
{
    RECT r = *rc;
    SelectObject(dc, font);
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    DrawTextW(dc, text, -1, &r, flags | DT_NOPREFIX);
}

static void DrawSection(HDC dc, const RECT *sec, const wchar_t *title)
{
    RECT r = *sec;

    FillRound(dc, sec, CtScale(6), g_theme.panel, g_theme.border);

    r.left  += CtScale(14);
    r.top   += CtScale(8);
    r.right -= CtScale(14);
    r.bottom = r.top + g_metrics.sectionTitleH;

    TextOutRect(dc, g_metrics.fontSmallBold, g_theme.textDim, title, &r,
                DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}

static void DrawRadioGlyph(HDC dc, int x, int y, int size, BOOL checked, BOOL hover, BOOL enabled)
{
    RECT     rc   = RectL(x, y, x + size, y + size);
    COLORREF edge = g_theme.fieldBorder;
    HBRUSH   fill;
    HPEN     pen;
    HGDIOBJ  ob, op;

    if (!enabled)
        edge = g_theme.border;
    else if (hover || checked)
        edge = g_theme.accent;

    fill = CreateSolidBrush(g_theme.field);
    pen  = CreatePen(PS_SOLID, CtScale(1), edge);
    ob   = SelectObject(dc, fill);
    op   = SelectObject(dc, pen);

    Ellipse(dc, rc.left, rc.top, rc.right, rc.bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(fill);
    DeleteObject(pen);

    if (!checked)
        return;

    InsetRect(&rc, size / 3, size / 3);
    fill = CreateSolidBrush(enabled ? g_theme.accent : g_theme.textDisabled);
    pen  = CreatePen(PS_NULL, 0, g_theme.accent);
    ob   = SelectObject(dc, fill);
    op   = SelectObject(dc, pen);

    Ellipse(dc, rc.left, rc.top + 1, rc.right - 1, rc.bottom);

    SelectObject(dc, ob);
    SelectObject(dc, op);
    DeleteObject(fill);
    DeleteObject(pen);
}

static void DrawCaret(HDC dc, int id, const wchar_t *text, BOOL focused)
{
    SIZE  sz = { 0, 0 };
    RECT  rc = g_box[id].rc;
    RECT  caret;

    if (!focused || !g_caretOn)
        return;

    InsetRect(&rc, g_metrics.editPadX, 0);
    rc.right -= CtScale(18);

    SelectObject(dc, g_metrics.font);
    GetTextExtentPoint32W(dc, text, (int)wcslen(text), &sz);

    caret.left   = rc.left + sz.cx + 1;
    caret.right  = caret.left + CtScale(1) + 1;
    caret.top    = rc.top + CtScale(7);
    caret.bottom = rc.bottom - CtScale(7);

    FillRound(dc, &caret, 0, g_theme.accent, g_theme.accent);
}

static void DrawSpinField(HDC dc, int id, BOOL focused, BOOL hover)
{
    const CtBox *b      = &g_box[id];
    RECT         rc     = b->rc;
    const wchar_t *text = FieldText(id);
    BOOL         on     = b->enabled;
    RECT         tr     = rc;
    int          spinW  = CtScale(18);
    int          i;

    FillRound(dc, &rc, CtScale(4), g_theme.field,
              focused ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.fieldBorder));

    // Separator between the number and the little spinner arrows.
    {
        RECT line = RectL(rc.right - spinW, rc.top + CtScale(4),
                          rc.right - spinW, rc.bottom - CtScale(4));

        FillRectColor(dc, &line, g_theme.border);
    }

    tr.left  += g_metrics.editPadX;
    tr.right -= spinW + CtScale(2);

    PushClip(dc, &tr);
    TextOutRect(dc, g_metrics.font, on ? g_theme.text : g_theme.textDisabled,
                (text && text[0]) ? text : L"0", &tr,
                DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    PopClip(dc);

    for (i = 0; i < 2; i++)
    {
        RECT zone = g_spinRc[id - CTW_HOURS][i];
        COLORREF color = on ? g_theme.textDim : g_theme.textDisabled;
        POINT   p[3];
        HBRUSH  brush;
        HPEN    pen;
        HGDIOBJ ob, op;
        int     cx = (zone.left + zone.right) / 2;
        int     cy = (zone.top + zone.bottom) / 2;
        int     a  = CtScale(3);

        if (on && g_box[id].enabled && g_spinHot == id && g_spinHotDir == i)
            color = g_theme.accentSoft;

        if (i == 0)
        {
            p[0].x = cx - a; p[0].y = cy + a - CtScale(1);
            p[1].x = cx;     p[1].y = cy - a;
            p[2].x = cx + a; p[2].y = cy + a - CtScale(1);
        }
        else
        {
            p[0].x = cx - a; p[0].y = cy - a + CtScale(1);
            p[1].x = cx;     p[1].y = cy + a;
            p[2].x = cx + a; p[2].y = cy - a + CtScale(1);
        }

        brush = CreateSolidBrush(color);
        pen   = CreatePen(PS_SOLID, 1, color);
        ob    = SelectObject(dc, brush);
        op    = SelectObject(dc, pen);
        Polygon(dc, p, 3);
        SelectObject(dc, ob);
        SelectObject(dc, op);
        DeleteObject(brush);
        DeleteObject(pen);
    }
}

static void DrawButton(HDC dc, int id, const wchar_t *caption, int style,
                       BOOL hover, BOOL pressed)
{
    const CtBox *b  = &g_box[id];
    RECT         rc = b->rc;
    COLORREF     fill;
    COLORREF     text;
    COLORREF     border = g_theme.border;

    if (!b->enabled)
    {
        fill = g_theme.panel;
        text = g_theme.textDisabled;
    }
    else if (style == 1)
    {
        fill = pressed ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.accent);
        text = g_theme.accentText;
        if (hover)
            border = g_theme.accentSoft;
    }
    else if (style == 2)
    {
        fill   = g_theme.warning;
        text   = g_theme.accentText;
        border = hover ? g_theme.accentSoft : g_theme.warning;
    }
    else
    {
        fill = pressed ? g_theme.buttonDown : (hover ? g_theme.buttonHover : g_theme.button);
        text = g_theme.text;
    }

    FillRound(dc, &rc, CtScale(5), fill, border);
    TextOutRect(dc, g_metrics.font, text, caption, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawCheckGlyph(HDC dc, int x, int y, int size, BOOL checked, BOOL hover)
{
    RECT     rc = RectL(x, y, x + size, y + size);
    COLORREF border = checked ? g_theme.accent : (hover ? g_theme.accentSoft : g_theme.fieldBorder);

    FillRound(dc, &rc, CtScale(3), checked ? g_theme.accent : g_theme.field, border);

    if (checked)
    {
        HPEN    pen = CreatePen(PS_SOLID, CtScale(2), g_theme.accentText);
        HGDIOBJ op  = SelectObject(dc, pen);

        MoveToEx(dc, x + size / 4, y + size / 2, NULL);
        LineTo(dc, x + size * 2 / 5, y + size * 7 / 10);
        LineTo(dc, x + size * 3 / 4, y + size / 3);

        SelectObject(dc, op);
        DeleteObject(pen);
    }
}

static void DrawProgressBar(HDC dc)
{
    CtState  state = CtGetState();
    int      total = CtGetTotalSec();
    int      left  = CtGetRemainingSec();
    int      h     = RectH(&g_barRc);
    COLORREF fill  = (state == CT_STATE_DONE) ? g_theme.warning : g_theme.accent;
    double   frac  = 0.0;
    RECT     f     = g_barRc;

    if (total > 0)
    {
        if (state == CT_STATE_DONE)
            frac = 1.0;
        else if (state == CT_STATE_RUNNING || state == CT_STATE_PAUSED)
            frac = (double)(total - left) / (double)total;
    }

    if (frac < 0.0) frac = 0.0;
    if (frac > 1.0) frac = 1.0;

    FillRound(dc, &g_barRc, h / 2, g_theme.track, g_theme.track);

    if (frac > 0.0)
    {
        int w = (int)((double)(g_barRc.right - g_barRc.left) * frac);

        // A fraction smaller than the bar height is still shown, as a small
        // round cap: the bar must visibly start moving on the first second.
        if (w < h)
            w = h;

        f.right = f.left + w;
        if (f.right > g_barRc.right)
            f.right = g_barRc.right;

        FillRound(dc, &f, h / 2, fill, fill);
    }
}

static void DrawPresets(HDC dc)
{
    BOOL idle = (CtGetState() == CT_STATE_IDLE) ? TRUE : FALSE;
    int  i;

    for (i = 0; i < 4; i++)
    {
        int  id      = CTW_PRESET_3 + i;
        BOOL checked = (g_ui.preset == (CtPreset)i) ? TRUE : FALSE;
        RECT lr      = g_presetLabelRc[i];
        COLORREF color;

        DrawRadioGlyph(dc, g_presetRadioRc[i].left, g_presetRadioRc[i].top,
                       g_metrics.radio, checked, g_box[id].hover, idle);

        if (!idle)
            color = g_theme.textDisabled;
        else
            color = checked ? g_theme.text : (g_box[id].hover ? g_theme.text : g_theme.textDim);

        TextOutRect(dc, g_metrics.font, color, kPresetNames[i], &lr,
                    DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    }
}

static void DrawFields(HDC dc)
{
    int i;

    for (i = 0; i < 3; i++)
    {
        int id = CTW_HOURS + i;

        TextOutRect(dc, g_metrics.fontSmall,
                    g_box[id].enabled ? g_theme.textDim : g_theme.textDisabled,
                    kFieldNames[i], &g_fieldLabelRc[i],
                    DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        DrawSpinField(dc, id, g_focus == id, g_box[id].hover);
        DrawCaret(dc, id, FieldText(id), g_focus == id);
    }
}

static void DrawClock(HDC dc)
{
    CtState state = CtGetState();
    wchar_t clock[16];
    COLORREF color;

    CtFormatClock(CtGetDisplaySec(), clock, 16);

    switch (state)
    {
    case CT_STATE_PAUSED: color = g_theme.textDim; break;
    case CT_STATE_DONE:   color = g_theme.warning; break;
    default:              color = g_theme.text;    break;
    }

    TextOutRect(dc, g_metrics.fontClock, color, clock, &g_clockRc,
                DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawProgressPanel(HDC dc)
{
    CtState   state = CtGetState();
    int       total = CtGetTotalSec();
    int       left  = CtGetRemainingSec();
    const wchar_t *status;
    COLORREF  statusColor;
    COLORREF  percentColor;
    wchar_t   title[64];
    wchar_t   pct[16];
    int       percent = 0;

    switch (state)
    {
    case CT_STATE_RUNNING:
        status      = L"Cooking";
        statusColor = g_theme.accent;
        break;
    case CT_STATE_PAUSED:
        status      = L"Paused";
        statusColor = g_theme.text;
        break;
    case CT_STATE_DONE:
        status      = L"Time's up!";
        statusColor = g_theme.warning;
        break;
    default:
        status      = L"Ready";
        statusColor = g_theme.textDim;
        break;
    }

    // The status doubles as the panel title; a repeating round is noted here
    // instead of in a separate hint line.
    if (state == CT_STATE_RUNNING && CtGetRound() > 1)
        _snwprintf(title, 64, L"%s \u00b7 round %d", status, CtGetRound());
    else
        wcsncpy(title, status, 64);

    title[63] = L'\0';

    if (total > 0)
    {
        percent = (int)(((long long)(total - left) * 100) / total);
        if (percent < 0) percent = 0;
        if (percent > 100) percent = 100;
    }

    _snwprintf(pct, 16, L"%d%%", percent);
    pct[15] = L'\0';

    FillRound(dc, &g_progressRc, CtScale(6), g_theme.panel, g_theme.border);

    TextOutRect(dc, g_metrics.fontSmallBold, statusColor, title, &g_progressTitleRc,
                DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    percentColor = (state == CT_STATE_DONE) ? g_theme.warning : g_theme.textDim;
    TextOutRect(dc, g_metrics.fontSmall, percentColor, pct, &g_progressTitleRc,
                DT_RIGHT | DT_VCENTER | DT_SINGLELINE);

    DrawProgressBar(dc);
}

// ---------------------------------------------------------------------------
// Paint
// ---------------------------------------------------------------------------

void CtUiPaint(HDC hdc)
{
    RECT full = RectL(0, 0, g_clientW, g_clientH);
    CtState state = CtGetState();
    wchar_t caption[96];
    int i;

    FillRectColor(hdc, &full, g_theme.bg);

    DrawSection(hdc, &g_presetsRc, L"Presets");
    DrawPresets(hdc);
    DrawFields(hdc);
    DrawClock(hdc);
    DrawProgressPanel(hdc);

    {
        RECT line = RectL(g_dividerX, CtScale(10), g_dividerX + 1,
                          g_progressRc.top - CtScale(6));

        FillRectColor(hdc, &line, g_theme.border);
    }

    // ---- Start / Reset ----------------------------------------------------
    switch (state)
    {
    case CT_STATE_RUNNING: wcsncpy(caption, L"Pause", 96);        break;
    case CT_STATE_PAUSED:  wcsncpy(caption, L"Resume", 96);       break;
    case CT_STATE_DONE:    wcsncpy(caption, L"Stop", 96);         break;
    default:               wcsncpy(caption, L"Start", 96);        break;
    }
    caption[95] = L'\0';

    DrawButton(hdc, CTW_START, caption,
               (state == CT_STATE_DONE) ? 2 : 1,
               g_box[CTW_START].hover, g_box[CTW_START].pressed);

    DrawButton(hdc, CTW_RESET, L"Reset", 0,
               g_box[CTW_RESET].hover, g_box[CTW_RESET].pressed);

    // ---- Check boxes ------------------------------------------------------
    {
        BOOL checked[2];
        const wchar_t *labels[2] = { L"Automatic restart", L"Ring forever" };

        checked[0] = g_ui.autoRestart;
        checked[1] = g_ui.ringForever;

        for (i = 0; i < 2; i++)
        {
            int id = CTW_AUTORESTART + i;

            DrawCheckGlyph(hdc, g_checkRc[i].left, g_checkRc[i].top,
                           g_metrics.checkBox, checked[i], g_box[id].hover);

            TextOutRect(hdc, g_metrics.font, g_theme.text, labels[i], &g_checkLabelRc[i],
                        DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        }
    }
}

// ---------------------------------------------------------------------------
// Hit testing and input
// ---------------------------------------------------------------------------

BOOL CtUiIsWidgetEnabled(int widget)
{
    return (widget >= 0 && widget < CTW_COUNT && g_box[widget].enabled) ? TRUE : FALSE;
}

BOOL CtUiWantsTextInput(void)
{
    return (g_focus >= 0 && IsField(g_focus)) ? TRUE : FALSE;
}

BOOL CtUiIsEditing(void)
{
    return (g_focus >= 0 && IsField(g_focus)) ? TRUE : FALSE;
}

static void SetFocusField(int id)
{
    if (!IsField(id) || !g_box[id].enabled)
        return;

    if (g_focus >= 0 && g_focus != id)
        CtUiCommitToSettings();

    g_focus     = id;
    g_editPos   = (int)wcslen(FieldText(id));
    g_zeroSlot  = (g_editPos == 1 && FieldText(id)[0] == L'0') ? TRUE : FALSE;
    g_caretTick = GetTickCount();
    g_caretOn   = TRUE;
}

static void MoveFocus(int dir)
{
    int id = (g_focus < 0) ? CTW_HOURS : g_focus;
    int i;

    if (!CtUiIsEditing())
        return;

    CtUiCommitToSettings();

    for (i = 1; i <= 3; i++)
    {
        int next = CTW_HOURS + ((id - CTW_HOURS + dir * i) % 3 + 3) % 3;

        if (g_box[next].enabled)
        {
            SetFocusField(next);
            return;
        }
    }

    g_focus = -1;
}

static void StepField(int id, int delta)
{
    int lo = 0;
    int hi = FieldLimit(id);
    int v;

    if (!g_box[id].enabled)
        return;

    v = ParseInt(FieldText(id), lo, hi, 0) + delta;
    if (v < lo) v = lo;
    if (v > hi) v = hi;

    FormatInt(FieldText(id), CT_FIELD_LEN, v);
    g_editPos  = (int)wcslen(FieldText(id));
    g_zeroSlot = FALSE;

    Notify(id);
}

static int SpinAt(int x, int y, int *dirOut)
{
    int i, k;

    for (i = 0; i < 3; i++)
    {
        if (!g_box[CTW_HOURS + i].enabled)
            continue;

        for (k = 0; k < 2; k++)
        {
            if (Hit(&g_spinRc[i][k], x, y))
            {
                if (dirOut) *dirOut = (k == 0) ? 1 : -1;
                return CTW_HOURS + i;
            }
        }
    }

    return -1;
}

BOOL CtUiOnMouseMove(int x, int y)
{
    int  i;
    int  hit = -1;
    int  spinDir = 0;
    int  spin = -1;
    BOOL changed = FALSE;

    spin = SpinAt(x, y, &spinDir);

    for (i = 0; i < CTW_COUNT && hit < 0; i++)
    {
        if (g_box[i].enabled && Hit(&g_box[i].rc, x, y))
            hit = i;
    }

    if (spin != g_spinHot || spinDir != g_spinHotDir)
    {
        g_spinHot    = spin;
        g_spinHotDir = spinDir;
        changed      = TRUE;
    }

    if (hit != g_hot)
    {
        g_hot   = hit;
        changed = TRUE;
    }

    for (i = 0; i < CTW_COUNT; i++)
    {
        BOOL h = (hit == i);

        if (g_box[i].hover != h)
        {
            g_box[i].hover = h;
            changed = TRUE;
        }
    }

    return changed;
}

BOOL CtUiOnMouseLeave(void)
{
    int  i;
    BOOL changed = FALSE;

    for (i = 0; i < CTW_COUNT; i++)
    {
        if (g_box[i].hover)   { g_box[i].hover = FALSE; changed = TRUE; }
        if (g_box[i].pressed) { g_box[i].pressed = FALSE; changed = TRUE; }
    }

    if (g_hot >= 0)      { g_hot = -1; changed = TRUE; }
    if (g_spinHot >= 0)  { g_spinHot = -1; g_spinHotDir = 0; changed = TRUE; }

    g_pressed = -1;
    return changed;
}

BOOL CtUiOnMouseDown(int x, int y)
{
    int id = -1;
    int i;
    int spinDir = 0;
    int spin;

    // A click anywhere outside the focused field commits it first, so Start
    // always acts on what the user just typed.
    if (CtUiIsEditing())
    {
        int  focus = g_focus;
        BOOL inside = Hit(&g_box[focus].rc, x, y) ? TRUE : FALSE;

        if (!inside)
        {
            CtUiCommitToSettings();
            g_focus = -1;
            Notify(-1);
        }
    }

    spin = SpinAt(x, y, &spinDir);
    if (spin >= 0)
    {
        StepField(spin, spinDir);
        return TRUE;
    }

    for (i = 0; i < CTW_COUNT; i++)
    {
        if (g_box[i].enabled && Hit(&g_box[i].rc, x, y))
        {
            id = i;
            break;
        }
    }

    if (id < 0)
        return FALSE;

    if (id >= CTW_HOURS && id <= CTW_SECS)
    {
        SetFocusField(id);
        return TRUE;
    }

    if (id >= CTW_PRESET_3 && id <= CTW_PRESET_CUSTOM)
    {
        SelectPreset(id - CTW_PRESET_3);
        return TRUE;
    }

    if (id == CTW_AUTORESTART || id == CTW_RINGFOREVER)
    {
        if (id == CTW_AUTORESTART)
            g_ui.autoRestart = !g_ui.autoRestart;
        else
            g_ui.ringForever = !g_ui.ringForever;

        Notify(id);
        return TRUE;
    }

    g_pressed = id;
    g_box[id].pressed = TRUE;
    return TRUE;
}

BOOL CtUiOnMouseUp(int x, int y)
{
    int pressed = g_pressed;

    if (pressed < 0)
        return FALSE;

    g_box[pressed].pressed = FALSE;
    g_pressed = -1;

    if (Hit(&g_box[pressed].rc, x, y))
        Notify(pressed);

    return TRUE;
}

BOOL CtUiOnCaptureLost(void)
{
    int i;

    for (i = 0; i < CTW_COUNT; i++)
        g_box[i].pressed = FALSE;

    g_pressed = -1;
    return TRUE;
}

BOOL CtUiOnMouseWheel(int x, int y, int delta)
{
    int id = -1;
    int i;

    if (delta == 0)
        return FALSE;

    for (i = 0; i < 3; i++)
    {
        if (g_box[CTW_HOURS + i].enabled && Hit(&g_box[CTW_HOURS + i].rc, x, y))
        {
            id = CTW_HOURS + i;
            break;
        }
    }

    if (id < 0)
        return FALSE;

    StepField(id, (delta > 0) ? 1 : -1);
    return TRUE;
}

BOOL CtUiOnKeyDown(int vk)
{
    if (CtUiIsEditing())
    {
        wchar_t *text = FieldText(g_focus);
        int      len  = (int)wcslen(text);

        switch (vk)
        {
        case VK_BACK:
            g_zeroSlot = FALSE;
            if (g_editPos > 0)
            {
                memmove(&text[g_editPos - 1], &text[g_editPos],
                        (size_t)(len - g_editPos + 1) * sizeof(wchar_t));
                g_editPos--;
                DraftChanged();
            }
            return TRUE;

        case VK_DELETE:
            g_zeroSlot = FALSE;
            if (g_editPos < len)
            {
                memmove(&text[g_editPos], &text[g_editPos + 1],
                        (size_t)(len - g_editPos) * sizeof(wchar_t));
                DraftChanged();
            }
            return TRUE;

        case VK_LEFT:
            g_zeroSlot = FALSE;
            if (g_editPos > 0) g_editPos--;
            return TRUE;

        case VK_RIGHT:
            g_zeroSlot = FALSE;
            if (g_editPos < len) g_editPos++;
            return TRUE;

        case VK_HOME:
            g_zeroSlot = FALSE;
            g_editPos = 0;
            return TRUE;

        case VK_END:
            g_zeroSlot = FALSE;
            g_editPos = len;
            return TRUE;

        case VK_UP:
            StepField(g_focus, 1);
            return TRUE;

        case VK_DOWN:
            StepField(g_focus, -1);
            return TRUE;

        case VK_RETURN:
            g_focus = -1;
            g_zeroSlot = FALSE;
            Notify(-1);
            return TRUE;

        case VK_TAB:
            MoveFocus((GetKeyState(VK_SHIFT) & 0x8000) ? -1 : 1);
            return TRUE;

        case VK_ESCAPE:
            g_focus = -1;
            g_zeroSlot = FALSE;
            CtUiLoadFromSettings();
            Notify(-1);
            return TRUE;

        default:
            break;
        }
    }

    return FALSE;
}

BOOL CtUiOnChar(wchar_t ch)
{
    wchar_t *text;
    int      len;

    if (!CtUiIsEditing())
        return FALSE;

    if (ch < 32)
        return FALSE;

    if (!(ch >= L'0' && ch <= L'9'))
        return FALSE;

    text = FieldText(g_focus);
    len  = (int)wcslen(text);

    if (len >= 2 && !g_zeroSlot)
        return FALSE;

    if (g_zeroSlot)
    {
        text[0] = L'\0';
        len = 0;
        g_editPos = 0;
        g_zeroSlot = FALSE;
    }

    memmove(&text[g_editPos + 1], &text[g_editPos],
            (size_t)(len - g_editPos + 1) * sizeof(wchar_t));
    text[g_editPos] = ch;
    g_editPos++;

    DraftChanged();

    g_caretTick = GetTickCount();
    g_caretOn   = TRUE;
    return TRUE;
}

void CtUiTick(void)
{
    if (CtUiIsEditing())
    {
        DWORD now = GetTickCount();

        if (now - g_caretTick >= CT_CARET_BLINK_MS)
        {
            g_caretTick = now;
            g_caretOn   = !g_caretOn;
        }
    }
    else
    {
        g_caretOn = FALSE;
    }
}
