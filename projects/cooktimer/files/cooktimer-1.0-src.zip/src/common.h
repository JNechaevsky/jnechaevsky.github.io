// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - common definitions shared by all modules.
//

#ifndef CT_COMMON_H
#define CT_COMMON_H

#include <windows.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// ---------------------------------------------------------------------------
// Application identity
// ---------------------------------------------------------------------------

#define CT_APP_NAME      L"Cook Timer"
#define CT_APP_VERSION   L"1.0"
#define CT_WINDOW_CLASS  L"CookTimerWindow"
#define CT_CONFIG_FILE   L"cooktimer.ini"

// ---------------------------------------------------------------------------
// Bounds and defaults
// ---------------------------------------------------------------------------

#define CT_FIELD_LEN      4
#define CT_MIN_TOTAL_SEC  1
#define CT_MAX_HOURS      99
#define CT_MAX_MINUTES    59
#define CT_MAX_SECONDS    59
#define CT_MAX_TOTAL_SEC  (CT_MAX_HOURS * 3600 + CT_MAX_MINUTES * 60 + CT_MAX_SECONDS)

// Idle time before an automatic restart begins, so "00:00:00" stays visible.
#define CT_RESTART_DELAY_MS  2500

// ---------------------------------------------------------------------------
// Window geometry, in 96 DPI logical units
// ---------------------------------------------------------------------------

#define CT_BASE_W        460
#define CT_BASE_H        242
#define CT_MIN_W         CT_BASE_W
#define CT_MIN_H         CT_BASE_H

// ---------------------------------------------------------------------------
// Presets
// ---------------------------------------------------------------------------

typedef enum
{
    CT_PRESET_3 = 0,
    CT_PRESET_5,
    CT_PRESET_10,
    CT_PRESET_CUSTOM,

    CT_PRESET_COUNT
} CtPreset;

// ---------------------------------------------------------------------------
// Settings (persisted between runs)
// ---------------------------------------------------------------------------

typedef struct
{
    CtPreset preset;
    int      hours;
    int      mins;
    int      secs;
    BOOL     autoRestart;
    BOOL     ringForever;
    BOOL     hasWindowPos;
    int      windowX;
    int      windowY;
} CtSettings;

// ---------------------------------------------------------------------------
// Visual theme (all colors in 0x00BBGGRR, i.e. RGB() macro order)
// ---------------------------------------------------------------------------

typedef struct
{
    COLORREF bg;           // window / panel background
    COLORREF panel;        // grouped section fill
    COLORREF border;       // section border
    COLORREF field;        // edit field background
    COLORREF fieldBorder;  // edit field border
    COLORREF button;       // button face
    COLORREF buttonHover;  // button hover face
    COLORREF buttonDown;   // button pressed face
    COLORREF text;         // primary text
    COLORREF textDim;      // secondary text
    COLORREF textDisabled; // disabled text
    COLORREF accent;       // accent color (radio dot, progress, focus)
    COLORREF accentSoft;   // accent on hover
    COLORREF accentText;   // text on accent background
    COLORREF track;        // progress track
    COLORREF selection;    // edit selection background
    COLORREF accentBorder; // accent-colored outline on hover
    COLORREF closeHover;   // window close button hover
    COLORREF warning;      // "time is up" color
} CtTheme;

extern CtSettings g_settings;
extern CtTheme    g_theme;

// ---------------------------------------------------------------------------
// Metrics, recomputed on every DPI change
// ---------------------------------------------------------------------------

typedef struct
{
    UINT  dpi;
    int   s;      // scale for coordinates (round(base * dpi / 96))
    int   fontS;  // scale for font sizes (floor(base * dpi / 96))
    HFONT font;
    HFONT fontBold;
    HFONT fontSmall;
    HFONT fontSmallBold;
    HFONT fontClock;
    int   lineH;
    int   smallLineH;
    int   clockLineH;
    int   pad;
    int   sectionTitleH;
    int   rowH;
    int   buttonH;
    int   editPadX;
    int   checkBox;
    int   radio;
    int   gutter;
} CtMetrics;

extern CtMetrics g_metrics;
extern HINSTANCE g_instance;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

int  CtScale(int base);
int  CtScaleFont(int base);
int  CtClampInt(int v, int lo, int hi);
void CtWideToAnsi(const wchar_t *src, char *dst, int dstSize);
BOOL CtIsHighContrast(void);
BOOL CtDarkModeEnabled(void);

#endif // CT_COMMON_H
