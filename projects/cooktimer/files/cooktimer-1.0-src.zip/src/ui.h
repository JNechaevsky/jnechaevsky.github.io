// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef CT_UI_H
#define CT_UI_H

#include "common.h"

typedef struct
{
    wchar_t  hours[CT_FIELD_LEN];
    wchar_t  mins[CT_FIELD_LEN];
    wchar_t  secs[CT_FIELD_LEN];
    CtPreset preset;
    BOOL     autoRestart;
    BOOL     ringForever;
} CtUiState;

extern CtUiState g_ui;

typedef void (*CtUiNotify)(int widget);

void CtUiSetNotify(CtUiNotify notify);

void CtUiLoadFromSettings(void);
void CtUiCommitToSettings(void);

void CtUiLayout(int clientW, int clientH);
void CtUiRelayout(void);   // re-runs layout with the last known client size
void CtUiPaint(HDC hdc);

BOOL CtUiOnMouseMove(int x, int y);
BOOL CtUiOnMouseDown(int x, int y);
BOOL CtUiOnMouseUp(int x, int y);
BOOL CtUiOnMouseLeave(void);
BOOL CtUiOnMouseWheel(int x, int y, int delta);
BOOL CtUiOnKeyDown(int vk);
BOOL CtUiOnChar(wchar_t ch);
BOOL CtUiOnCaptureLost(void);

void CtUiTick(void);

BOOL CtUiWantsTextInput(void);
BOOL CtUiIsEditing(void);
BOOL CtUiIsWidgetEnabled(int widget);

// Duration described by the three fields, in seconds.
int CtUiDurationSec(void);

#endif // CT_UI_H
