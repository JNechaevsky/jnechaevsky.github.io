// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - theme, DPI metrics and small shared helpers.
//

#include "common.h"
#include "theme.h"

CtSettings g_settings = {
    CT_PRESET_3, 0, 3, 0, FALSE, FALSE, FALSE, 0, 0
};

CtTheme   g_theme;
// DPI first: CtScale() must work before the window exists.
CtMetrics g_metrics = {
    96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

HINSTANCE g_instance = NULL;

// Dark palette - the same cool neutral greys and soft blue accent as the
// Auto Clicker, plus a warm warning color for the end of the countdown.
static const CtTheme kDarkTheme = {
    /* bg           */ RGB( 26,  27,  30),
    /* panel        */ RGB( 36,  37,  41),
    /* border       */ RGB( 58,  60,  66),
    /* field        */ RGB( 24,  25,  28),
    /* fieldBorder  */ RGB( 76,  78,  86),
    /* button       */ RGB( 46,  48,  53),
    /* buttonHover  */ RGB( 58,  60,  66),
    /* buttonDown   */ RGB( 36,  38,  43),
    /* text         */ RGB(232, 233, 236),
    /* textDim      */ RGB(166, 168, 175),
    /* textDisabled */ RGB(108, 110, 116),
    /* accent       */ RGB(112, 170, 255),
    /* accentSoft   */ RGB(142, 188, 255),
    /* accentText   */ RGB( 12,  14,  18),
    /* track        */ RGB( 56,  58,  64),
    /* selection    */ RGB( 38,  79, 120),
    /* accentBorder */ RGB(112, 170, 255),
    /* closeHover   */ RGB(196,  43,  28),
    /* warning      */ RGB(255, 146,  92)
};

// Fallback light palette, used under high contrast mode.
static const CtTheme kLightTheme = {
    RGB(240, 240, 240), RGB(250, 250, 250), RGB(214, 214, 214),
    RGB(255, 255, 255), RGB(190, 190, 190), RGB(253, 253, 253),
    RGB(240, 241, 245), RGB(232, 233, 238), RGB(  0,   0,   0),
    RGB( 90,  90,  90), RGB(150, 150, 150), RGB(  0, 103, 192),
    RGB( 30, 120, 214), RGB(255, 255, 255), RGB(224, 224, 224),
    RGB(180, 205, 235), RGB(  0, 103, 192), RGB(196,  43,  28),
    RGB(176,  70,  20)
};

// ---------------------------------------------------------------------------
// Scaling helpers
// ---------------------------------------------------------------------------

int CtScale(int base)
{
    return (int)((base * (int)g_metrics.dpi + 48) / 96);
}

int CtScaleFont(int base)
{
    return (int)((base * (int)g_metrics.dpi) / 96);
}

int CtClampInt(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

void CtWideToAnsi(const wchar_t *src, char *dst, int dstSize)
{
    if (dstSize <= 0) return;
    if (src == NULL) { dst[0] = '\0'; return; }
    WideCharToMultiByte(CP_ACP, 0, src, -1, dst, dstSize, NULL, NULL);
    dst[dstSize - 1] = '\0';
}

BOOL CtIsHighContrast(void)
{
    HIGHCONTRASTW hc;
    ZeroMemory(&hc, sizeof(hc));
    hc.cbSize = sizeof(hc);
    if (SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(hc), &hc, 0))
        return (hc.dwFlags & HCF_HIGHCONTRASTON) ? TRUE : FALSE;
    return FALSE;
}

BOOL CtDarkModeEnabled(void)
{
    DWORD value = 0;
    DWORD size  = sizeof(value);
    HKEY  key   = NULL;
    LONG  rc;

    if (CtIsHighContrast())
        return FALSE;

    rc = RegOpenKeyExW(HKEY_CURRENT_USER,
                       L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
                       0, KEY_QUERY_VALUE, &key);
    if (rc != ERROR_SUCCESS)
        return TRUE;

    rc = RegQueryValueExW(key, L"AppsUseLightTheme", NULL, NULL,
                          (LPBYTE)&value, &size);
    RegCloseKey(key);

    if (rc != ERROR_SUCCESS)
        return TRUE;

    return (value == 0) ? TRUE : FALSE;
}

// ---------------------------------------------------------------------------
// Palette
// ---------------------------------------------------------------------------

void CtThemeInit(void)
{
    g_theme = CtDarkModeEnabled() ? kDarkTheme : kLightTheme;
}

// ---------------------------------------------------------------------------
// Fonts and metrics
// ---------------------------------------------------------------------------

static HFONT CreateUiFont(const wchar_t *face, int pt, BOOL bold)
{
    LOGFONTW lf;
    ZeroMemory(&lf, sizeof(lf));
    lf.lfHeight = -MulDiv(pt, (int)g_metrics.dpi, 72);
    lf.lfWeight = bold ? FW_SEMIBOLD : FW_NORMAL;
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfQuality = CLEARTYPE_QUALITY;
    lf.lfPitchAndFamily = VARIABLE_PITCH | FF_SWISS;
    wcsncpy(lf.lfFaceName, face, LF_FACESIZE - 1);
    return CreateFontIndirectW(&lf);
}

void CtMetricsInit(UINT dpi)
{
    if (dpi == 0) dpi = 96;
    g_metrics.dpi = dpi;

    if (g_metrics.font)          DeleteObject(g_metrics.font);
    if (g_metrics.fontBold)      DeleteObject(g_metrics.fontBold);
    if (g_metrics.fontSmall)     DeleteObject(g_metrics.fontSmall);
    if (g_metrics.fontSmallBold) DeleteObject(g_metrics.fontSmallBold);
    if (g_metrics.fontClock)     DeleteObject(g_metrics.fontClock);

    g_metrics.font          = CreateUiFont(L"Segoe UI", 10, FALSE);
    g_metrics.fontBold      = CreateUiFont(L"Segoe UI", 10, TRUE);
    g_metrics.fontSmall     = CreateUiFont(L"Segoe UI", 9,  FALSE);
    g_metrics.fontSmallBold = CreateUiFont(L"Segoe UI", 9,  TRUE);

    // The big remaining-time display: proportional, but Segoe UI uses tabular
    // digits, so the readout never jitters while it counts down.
    g_metrics.fontClock     = CreateUiFont(L"Segoe UI", 32, TRUE);

    g_metrics.lineH         = CtScaleFont(16);
    g_metrics.smallLineH    = CtScaleFont(14);
    g_metrics.clockLineH    = CtScaleFont(48);
    g_metrics.pad           = CtScale(8);
    g_metrics.sectionTitleH = CtScaleFont(16);
    g_metrics.rowH          = CtScale(24);
    g_metrics.buttonH       = CtScale(30);
    g_metrics.editPadX      = CtScale(5);
    g_metrics.checkBox      = CtScale(14);
    g_metrics.radio         = CtScale(13);
    g_metrics.gutter        = CtScale(10);
}

void CtMetricsFree(void)
{
    if (g_metrics.font)          DeleteObject(g_metrics.font);
    if (g_metrics.fontBold)      DeleteObject(g_metrics.fontBold);
    if (g_metrics.fontSmall)     DeleteObject(g_metrics.fontSmall);
    if (g_metrics.fontSmallBold) DeleteObject(g_metrics.fontSmallBold);
    if (g_metrics.fontClock)     DeleteObject(g_metrics.fontClock);
    ZeroMemory(&g_metrics, sizeof(g_metrics));
}
