// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - settings persistence.
//
// The INI lives next to cooktimer.exe. That is the only location: the whole
// folder can be moved or copied without leaving anything behind in the system.
//

#include "common.h"
#include "config.h"
#include "theme.h"

static wchar_t g_dir[MAX_PATH];   // folder that holds cooktimer.exe
static wchar_t g_path[MAX_PATH];  // portable cooktimer.ini

static BOOL FileExists(const wchar_t *path)
{
    DWORD attr = GetFileAttributesW(path);
    return (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY)) ? TRUE : FALSE;
}

static void BuildPaths(void)
{
    wchar_t exe[MAX_PATH];
    DWORD   len;

    g_dir[0]  = L'\0';
    g_path[0] = L'\0';

    len = GetModuleFileNameW(NULL, exe, MAX_PATH);
    if (len == 0 || len >= MAX_PATH)
        return;

    {
        wchar_t *slash = wcsrchr(exe, L'\\');

        if (slash != NULL)
            *slash = L'\0';
    }

    wcsncpy(g_dir, exe, MAX_PATH - 1);
    g_dir[MAX_PATH - 1] = L'\0';

    _snwprintf(g_path, MAX_PATH, L"%s\\%s", g_dir, CT_CONFIG_FILE);
    g_path[MAX_PATH - 1] = L'\0';
}

void CtConfigGetPath(wchar_t *buf, int cch)
{
    if (cch <= 0) return;
    if (g_path[0] == L'\0')
        BuildPaths();
    wcsncpy(buf, g_path, (size_t)cch - 1);
    buf[cch - 1] = L'\0';
}

// Lightweight key=value reader. Tolerates CRLF, comments (';' and '#'),
// surrounding whitespace and is case-insensitive on keys.
static BOOL ReadKey(const wchar_t *path, const wchar_t *key, wchar_t *out, int cch)
{
    wchar_t line[512];
    FILE   *fp = NULL;
    BOOL    found = FALSE;

    out[0] = L'\0';
    if (_wfopen_s(&fp, path, L"rt") != 0 || fp == NULL)
        return FALSE;

    while (fgetws(line, 512, fp))
    {
        wchar_t *p = line;
        wchar_t *eq;

        if (*p == 0xFEFF) p++;                       // BOM
        while (*p == L' ' || *p == L'\t') p++;
        if (*p == L';' || *p == L'#' || *p == L'[' || *p == L'\r' || *p == L'\n' || *p == 0)
            continue;

        eq = wcschr(p, L'=');
        if (eq == NULL)
            continue;

        *eq = L'\0';

        // trim key
        {
            wchar_t *end = eq - 1;
            while (end >= p && (*end == L' ' || *end == L'\t')) *end-- = L'\0';
        }

        if (_wcsicmp(p, key) != 0)
            continue;

        p = eq + 1;
        while (*p == L' ' || *p == L'\t') p++;

        // trim trailing whitespace
        {
            size_t len = wcslen(p);
            while (len > 0 && (p[len - 1] == L'\r' || p[len - 1] == L'\n' ||
                               p[len - 1] == L' '  || p[len - 1] == L'\t'))
                p[--len] = L'\0';
        }

        wcsncpy(out, p, (size_t)cch - 1);
        out[cch - 1] = L'\0';
        found = TRUE;
        break;
    }

    fclose(fp);
    return found;
}

static int ReadInt(const wchar_t *path, const wchar_t *key, int fallback)
{
    wchar_t buf[64];
    if (!ReadKey(path, key, buf, 64) || buf[0] == L'\0')
        return fallback;
    return (int)wcstol(buf, NULL, 10);
}

static BOOL ReadBool(const wchar_t *path, const wchar_t *key, BOOL fallback)
{
    wchar_t buf[64];
    if (!ReadKey(path, key, buf, 64) || buf[0] == L'\0')
        return fallback;
    if (!_wcsicmp(buf, L"1") || !_wcsicmp(buf, L"true") || !_wcsicmp(buf, L"yes"))
        return TRUE;
    if (!_wcsicmp(buf, L"0") || !_wcsicmp(buf, L"false") || !_wcsicmp(buf, L"no"))
        return FALSE;
    return fallback;
}

static void SetDefaults(CtSettings *out)
{
    out->preset       = CT_PRESET_3;
    out->hours        = 0;
    out->mins         = 3;
    out->secs         = 0;
    out->autoRestart  = FALSE;
    out->ringForever  = FALSE;
    out->hasWindowPos = FALSE;
    out->windowX      = 0;
    out->windowY      = 0;
}

static int PresetSeconds(CtPreset preset)
{
    switch (preset)
    {
    case CT_PRESET_3:  return 3 * 60;
    case CT_PRESET_5:  return 5 * 60;
    case CT_PRESET_10: return 10 * 60;
    default:           return 0;
    }
}

static void ReadSettings(const wchar_t *path, CtSettings *out)
{
    int preset;

    preset = ReadInt(path, L"preset", (int)out->preset);
    if (preset < 0 || preset >= CT_PRESET_COUNT)
        preset = (int)CT_PRESET_3;
    out->preset = (CtPreset)preset;

    out->hours = CtClampInt(ReadInt(path, L"hours", out->hours), 0, CT_MAX_HOURS);
    out->mins  = CtClampInt(ReadInt(path, L"mins",  out->mins),  0, CT_MAX_MINUTES);
    out->secs  = CtClampInt(ReadInt(path, L"secs",  out->secs),  0, CT_MAX_SECONDS);

    out->autoRestart = ReadBool(path, L"auto_restart", out->autoRestart);
    out->ringForever = ReadBool(path, L"ring_forever", out->ringForever);

    out->hasWindowPos = ReadBool(path, L"window_placed", FALSE);
    out->windowX      = ReadInt(path, L"window_x", 0);
    out->windowY      = ReadInt(path, L"window_y", 0);

    // A preset defines the duration; whatever the fields held is irrelevant.
    if (out->preset != CT_PRESET_CUSTOM)
    {
        int total = PresetSeconds(out->preset);

        out->hours = total / 3600;
        out->mins  = (total / 60) % 60;
        out->secs  = total % 60;
    }
}

void CtConfigLoad(CtSettings *out)
{
    if (out == NULL) return;

    BuildPaths();
    SetDefaults(out);

    if (g_path[0] != L'\0' && FileExists(g_path))
        ReadSettings(g_path, out);
}

static BOOL WriteSettings(const wchar_t *path, const CtSettings *in)
{
    wchar_t tmp[MAX_PATH];
    FILE   *fp = NULL;

    if (in == NULL)
        return FALSE;

    if (path == NULL || path[0] == L'\0')
        return FALSE;

    _snwprintf(tmp, MAX_PATH, L"%s.tmp", path);
    tmp[MAX_PATH - 1] = L'\0';

    if (_wfopen_s(&fp, tmp, L"wt") != 0 || fp == NULL)
        return FALSE;

    fwprintf(fp, L"; Cook Timer %s - portable settings\n", CT_APP_VERSION);
    fwprintf(fp, L"; Safe to edit by hand, but the app rewrites it on exit.\n\n");

    fwprintf(fp, L"preset=%d\n", (int)in->preset);
    fwprintf(fp, L"hours=%d\n",  in->hours);
    fwprintf(fp, L"mins=%d\n",   in->mins);
    fwprintf(fp, L"secs=%d\n\n", in->secs);

    fwprintf(fp, L"auto_restart=%d\n", in->autoRestart ? 1 : 0);
    fwprintf(fp, L"ring_forever=%d\n\n", in->ringForever ? 1 : 0);

    fwprintf(fp, L"window_placed=%d\n", in->hasWindowPos ? 1 : 0);
    fwprintf(fp, L"window_x=%d\n", in->windowX);
    fwprintf(fp, L"window_y=%d\n", in->windowY);

    fclose(fp);

    if (!MoveFileExW(tmp, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
    {
        DeleteFileW(tmp);
        return FALSE;
    }

    return TRUE;
}

BOOL CtConfigSave(const CtSettings *in)
{
    if (in == NULL) return FALSE;

    BuildPaths();
    if (g_path[0] == L'\0')
        return FALSE;

    return WriteSettings(g_path, in);
}
