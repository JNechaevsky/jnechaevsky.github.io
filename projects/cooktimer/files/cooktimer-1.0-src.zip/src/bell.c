// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - the alarm.
//
// Beep() is the one sound source that needs no resources, no DirectSound and
// no system event scheme; on current Windows it is routed to the default audio
// device. It blocks for the length of a tone, so the bell lives on its own
// thread and the UI never waits for it.
//

#include "common.h"
#include "bell.h"

#define CT_BELL_STOP_WAIT_MS 2000

static HANDLE         g_thread = NULL;
static HANDLE         g_stop   = NULL;
static volatile LONG  g_active = 0;

static DWORD WINAPI BellThread(LPVOID param)
{
    BOOL forever = (BOOL)(INT_PTR)param;

    for (;;)
    {
        if (WaitForSingleObject(g_stop, 0) == WAIT_OBJECT_0)
            break;

        Beep(988, 150);

        if (WaitForSingleObject(g_stop, 0) == WAIT_OBJECT_0)
            break;

        Beep(1319, 150);

        if (WaitForSingleObject(g_stop, 0) == WAIT_OBJECT_0)
            break;

        Beep(1760, 260);

        if (!forever)
            break;

        if (WaitForSingleObject(g_stop, 900) == WAIT_OBJECT_0)
            break;
    }

    InterlockedExchange(&g_active, 0);
    return 0;
}

void CtBellStart(BOOL forever)
{
    DWORD threadId;

    if (InterlockedCompareExchange(&g_active, 1, 0) != 0)
        return;

    if (g_thread)
    {
        WaitForSingleObject(g_thread, CT_BELL_STOP_WAIT_MS);
        CloseHandle(g_thread);
        g_thread = NULL;
    }

    if (g_stop == NULL)
        g_stop = CreateEventW(NULL, TRUE, FALSE, NULL);

    if (g_stop == NULL)
    {
        InterlockedExchange(&g_active, 0);
        return;
    }

    ResetEvent(g_stop);

    g_thread = CreateThread(NULL, 0, BellThread, (LPVOID)(INT_PTR)(forever ? 1 : 0),
                            0, &threadId);
    if (g_thread == NULL)
    {
        InterlockedExchange(&g_active, 0);
        return;
    }

    SetThreadPriority(g_thread, THREAD_PRIORITY_ABOVE_NORMAL);
}

void CtBellStop(void)
{
    if (g_stop)
        SetEvent(g_stop);

    if (g_thread)
    {
        WaitForSingleObject(g_thread, CT_BELL_STOP_WAIT_MS);
        CloseHandle(g_thread);
        g_thread = NULL;
    }

    if (g_stop)
    {
        CloseHandle(g_stop);
        g_stop = NULL;
    }

    InterlockedExchange(&g_active, 0);
}

BOOL CtBellIsActive(void)
{
    return (g_active != 0) ? TRUE : FALSE;
}
