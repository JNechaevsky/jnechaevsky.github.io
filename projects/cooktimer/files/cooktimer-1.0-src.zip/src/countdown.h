// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef CT_COUNTDOWN_H
#define CT_COUNTDOWN_H

#include "common.h"

typedef enum
{
    CT_STATE_IDLE = 0,   // configured, not started
    CT_STATE_RUNNING,
    CT_STATE_PAUSED,
    CT_STATE_DONE        // reached zero, bell may still be sounding
} CtState;

// Sets the configured duration. Only meaningful while idle; the field editors
// are disabled during a run, so this keeps the engine consistent.
void CtSetDuration(int seconds);

void CtStart(void);
void CtPause(void);
void CtResume(void);
void CtReset(void);

// Called from the UI timer. Fires the bell at zero and performs auto restarts.
void CtTick(void);

// These are read at the moment they matter, not latched at start.
void CtSetAutoRestart(BOOL on);
void CtSetRingForever(BOOL on);

CtState CtGetState(void);
int     CtGetTotalSec(void);
int     CtGetRemainingSec(void);
int     CtGetDisplaySec(void);   // configured time while idle, remaining otherwise
int     CtGetRound(void);

// "HH:MM:SS", always eight characters.
void CtFormatClock(int seconds, wchar_t *buf, int cch);

#endif // CT_COUNTDOWN_H
