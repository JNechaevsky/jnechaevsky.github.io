// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - window, message loop and application logic.
//
// Written in C99 against the plain Win32 API. No frameworks, no runtime
// dependencies beyond what ships with Windows.
//

/*

    Compile under MS Build Tools (preferred):

        build.bat

    or by hand, from an "x64 Native Tools" prompt:

        rc /nologo /fo cooktimer.res cooktimer.rc
        cl /nologo /O2 /W4 /utf-8 src\*.c cooktimer.res /Fe:cooktimer.exe ^
           /link user32.lib gdi32.lib shell32.lib advapi32.lib winmm.lib ^
           comctl32.lib dwmapi.lib ole32.lib uuid.lib /SUBSYSTEM:WINDOWS ^
           /MANIFEST:EMBED /MANIFESTINPUT:cooktimer.manifest


    Compile under MSYS / GCC:

        build_msys.bat

    or by hand:

        windres cooktimer.rc -O coff -o cooktimer.res
        gcc -std=c99 -O2 -Wall -Wextra -mwindows -o cooktimer.exe all sources
            cooktimer.res -luser32 -lgdi32 -lshell32 -ladvapi32 -lwinmm \
            -lcomctl32 -ldwmapi -lole32 -luuid

*/

#include <windows.h>
#include <windowsx.h>
#include <dwmapi.h>

#include "common.h"
#include "theme.h"
#include "config.h"
#include "countdown.h"
#include "bell.h"
#include "taskbar.h"
#include "ui.h"
#include "ui_id.h"

#ifndef DWMWA_USE_IMMERSIVE_DARK_MODE
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#endif

#define TIMER_TICK 1
#define TICK_MS    100

static HWND      g_hwnd     = NULL;
static UINT      g_dpi      = 96;
static CtState   g_lastState = CT_STATE_IDLE;
static int       g_lastDisplay = -1;
static int       g_lastRound = -1;

// ---------------------------------------------------------------------------
// Dark window frame
// ---------------------------------------------------------------------------

static void ApplyDarkFrame(HWND hwnd)
{
    BOOL    dark = CtDarkModeEnabled();
    HMODULE dwm  = LoadLibraryW(L"dwmapi.dll");

    if (dwm)
    {
        typedef HRESULT (WINAPI *PFN_DwmSetWindowAttribute)(HWND, DWORD, LPCVOID, DWORD);
        PFN_DwmSetWindowAttribute fn =
            (PFN_DwmSetWindowAttribute)(void *)GetProcAddress(dwm, "DwmSetWindowAttribute");

        if (fn)
        {
            fn(hwnd, (DWORD)DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof(dark));
            fn(hwnd, 19u, &dark, sizeof(dark)); // pre-20H1 attribute id
        }
        FreeLibrary(dwm);
    }
}

// ---------------------------------------------------------------------------
// Window title mirrors the big clock
// ---------------------------------------------------------------------------

static void UpdateTitle(void)
{
    wchar_t clock[16];
    wchar_t title[64];
    int     seconds;

    // While idle, the fields are the source of truth: the title follows typing
    // even before the value has been committed to the engine.
    if (CtGetState() == CT_STATE_IDLE)
        seconds = CtUiDurationSec();
    else
        seconds = CtGetDisplaySec();

    CtFormatClock(seconds, clock, 16);
    _snwprintf(title, 64, L"%s - %s", clock, CT_APP_NAME);
    title[63] = L'\0';

    SetWindowTextW(g_hwnd, title);
}

// ---------------------------------------------------------------------------
// Taskbar button progress
// ---------------------------------------------------------------------------

static void UpdateTaskbar(void)
{
    CtState        state   = CtGetState();
    CtTaskbarState tbState;
    int            total   = CtGetTotalSec();
    int            left    = CtGetRemainingSec();
    int            percent = 0;

    switch (state)
    {
    case CT_STATE_RUNNING: tbState = CT_TASKBAR_NORMAL; break;
    case CT_STATE_PAUSED:  tbState = CT_TASKBAR_PAUSED; break;
    case CT_STATE_DONE:    tbState = CT_TASKBAR_ERROR;  break;
    default:               tbState = CT_TASKBAR_NO_PROGRESS; break;
    }

    // The taskbar fills up as time passes, so it shows how much is done.
    if (total > 0)
    {
        percent = (int)(((long long)(total - left) * 100) / total);
        if (percent < 0) percent = 0;
        if (percent > 100) percent = 100;
    }

    CtTaskbarSet(tbState, percent, 100);
}

// ---------------------------------------------------------------------------
// DPI plumbing
// ---------------------------------------------------------------------------

static UINT QueryDpi(HWND hwnd)
{
    typedef UINT (WINAPI *PFN_GetDpiForWindow)(HWND);
    static PFN_GetDpiForWindow fn = NULL;
    static BOOL tried = FALSE;

    if (!tried)
    {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32)
            fn = (PFN_GetDpiForWindow)(void *)GetProcAddress(user32, "GetDpiForWindow");
        tried = TRUE;
    }

    if (fn)
    {
        UINT dpi = fn(hwnd);
        if (dpi)
            return dpi;
    }
    return 96;
}

static void AdjustForDpi(RECT *rc, HWND hwnd, UINT dpi)
{
    typedef BOOL (WINAPI *PFN_AdjustWindowRectExForDpi)(RECT *, DWORD, BOOL, DWORD, UINT);
    static PFN_AdjustWindowRectExForDpi fn = NULL;
    static BOOL tried = FALSE;

    if (!tried)
    {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32)
            fn = (PFN_AdjustWindowRectExForDpi)(void *)GetProcAddress(user32, "AdjustWindowRectExForDpi");
        tried = TRUE;
    }

    if (fn)
        fn(rc, GetWindowLongW(hwnd, GWL_STYLE), FALSE, GetWindowLongW(hwnd, GWL_EXSTYLE), dpi);
    else
        AdjustWindowRectEx(rc, GetWindowLongW(hwnd, GWL_STYLE), FALSE, GetWindowLongW(hwnd, GWL_EXSTYLE));
}

static void ApplyMetrics(HWND hwnd, UINT dpi, BOOL resizeToFit)
{
    RECT rc;

    g_dpi = dpi;
    CtMetricsInit(dpi);

    if (resizeToFit)
    {
        RECT want = { 0, 0, CtScale(CT_BASE_W), CtScale(CT_BASE_H) };

        AdjustForDpi(&want, hwnd, dpi);

        SetWindowPos(hwnd, NULL, 0, 0,
                     want.right - want.left, want.bottom - want.top,
                     SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    }

    GetClientRect(hwnd, &rc);
    CtUiLayout(rc.right - rc.left, rc.bottom - rc.top);
    InvalidateRect(hwnd, NULL, FALSE);
}

// ---------------------------------------------------------------------------
// Window placement
// ---------------------------------------------------------------------------

static void CenterWindow(HWND hwnd)
{
    HMONITOR    mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi;
    RECT        wr;

    if (mon == NULL)
        return;

    mi.cbSize = sizeof(mi);
    if (!GetMonitorInfoW(mon, &mi))
        return;

    GetWindowRect(hwnd, &wr);

    SetWindowPos(hwnd, NULL,
                 mi.rcWork.left + ((mi.rcWork.right - mi.rcWork.left) - (wr.right - wr.left)) / 2,
                 mi.rcWork.top  + ((mi.rcWork.bottom - mi.rcWork.top) - (wr.bottom - wr.top)) / 2,
                 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

// A saved position is accepted only if enough of the window would land on a
// monitor that currently exists - otherwise a removed display would hide it.
static BOOL WindowPosUsable(int x, int y, int w, int h)
{
    RECT        rc = { x, y, x + w, y + h };
    RECT        inter;
    MONITORINFO mi;
    HMONITOR    mon = MonitorFromRect(&rc, MONITOR_DEFAULTTONULL);

    if (mon == NULL)
        return FALSE;

    mi.cbSize = sizeof(mi);
    if (!GetMonitorInfoW(mon, &mi))
        return FALSE;

    if (!IntersectRect(&inter, &rc, &mi.rcWork))
        return FALSE;

    return (inter.right - inter.left >= CtScale(120) &&
            inter.bottom - inter.top >= CtScale(40)) ? TRUE : FALSE;
}

static void RememberWindowPos(HWND hwnd)
{
    RECT wr;

    // When minimised, GetWindowRect() reports the off-screen icon position;
    // keep the last known normal rectangle in that case.
    if (IsIconic(hwnd))
        return;

    if (GetWindowRect(hwnd, &wr))
    {
        g_settings.hasWindowPos = TRUE;
        g_settings.windowX      = wr.left;
        g_settings.windowY      = wr.top;
    }
}

// ---------------------------------------------------------------------------
// UI notification
// ---------------------------------------------------------------------------

static void OnUiNotify(int widget)
{
    switch (widget)
    {
    case CTW_START:
        switch (CtGetState())
        {
        case CT_STATE_RUNNING: CtPause();  break;
        case CT_STATE_PAUSED:  CtResume(); break;
        case CT_STATE_DONE:    CtReset();  break;
        default:
            CtStart();
            break;
        }
        break;

    case CTW_RESET:
        CtReset();
        break;

    default:
        break;
    }

    CtConfigSave(&g_settings);

    CtUiRelayout();
    UpdateTitle();
    UpdateTaskbar();
    InvalidateRect(g_hwnd, NULL, FALSE);

    g_lastState   = CtGetState();
    g_lastDisplay = CtGetDisplaySec();
    g_lastRound   = CtGetRound();
}

// ---------------------------------------------------------------------------
// Window procedure
// ---------------------------------------------------------------------------

static void PaintWindow(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT        rc;
    HDC         dc;
    HDC         mem;
    HBITMAP     bmp;
    HGDIOBJ     old;

    dc = BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);

    if (rc.right <= 0 || rc.bottom <= 0)
    {
        EndPaint(hwnd, &ps);
        return;
    }

    mem = CreateCompatibleDC(dc);
    bmp = CreateCompatibleBitmap(dc, rc.right, rc.bottom);
    old = SelectObject(mem, bmp);

    CtUiPaint(mem);

    BitBlt(dc, 0, 0, rc.right, rc.bottom, mem, 0, 0, SRCCOPY);

    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);

    EndPaint(hwnd, &ps);
}

static LRESULT OnCreate(HWND hwnd)
{
    g_hwnd = hwnd;

    CtThemeInit();
    ApplyDarkFrame(hwnd);

    CtConfigLoad(&g_settings);
    CtUiLoadFromSettings();
    CtUiSetNotify(OnUiNotify);
    CtTaskbarInit(hwnd);

    // Metrics and the initial size are applied by wWinMain once the window is
    // associated with a monitor: GetDpiForWindow() is not reliable yet inside
    // WM_CREATE, and a wrong guess here would leave the UI at 96 DPI.
    SetTimer(hwnd, TIMER_TICK, TICK_MS, NULL);
    return 0;
}

static void OnDestroy(HWND hwnd)
{
    KillTimer(hwnd, TIMER_TICK);

    CtReset();
    CtUiCommitToSettings();
    RememberWindowPos(hwnd);
    CtConfigSave(&g_settings);
    CtTaskbarShutdown();
    CtMetricsFree();

    PostQuitMessage(0);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
        return OnCreate(hwnd);

    case WM_DESTROY:
        OnDestroy(hwnd);
        return 0;

    case WM_CLOSE:
        CtReset();
        DestroyWindow(hwnd);
        return 0;

    case WM_PAINT:
        PaintWindow(hwnd);
        return 0;

    case WM_ERASEBKGND:
        return 1;

    case WM_GETMINMAXINFO:
    {
        MINMAXINFO *mmi  = (MINMAXINFO *)lParam;
        RECT        want = { 0, 0, CtScale(CT_MIN_W), CtScale(CT_MIN_H) };

        // Never derive the frame size from the current window geometry: while
        // the window is minimised GetClientRect() is (0,0), which used to make
        // the minimum track size (and therefore the restored width) drift.
        AdjustForDpi(&want, hwnd, g_metrics.dpi);

        mmi->ptMinTrackSize.x = want.right - want.left;
        mmi->ptMinTrackSize.y = want.bottom - want.top;
        return 0;
    }

    case WM_SIZE:
        CtUiLayout(LOWORD(lParam), HIWORD(lParam));
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_DPICHANGED:
    {
        RECT *sug = (RECT *)lParam;
        RECT  want = { 0, 0, CtScale(CT_BASE_W), CtScale(CT_BASE_H) };
        RECT  rc;

        // The window is fixed-size, so the "suggested" rectangle is only used
        // for its position: the size always follows our design at the new DPI.
        g_dpi = HIWORD(wParam);
        CtMetricsInit(g_dpi);
        AdjustForDpi(&want, hwnd, g_dpi);

        SetWindowPos(hwnd, NULL, sug->left, sug->top,
                     want.right - want.left, want.bottom - want.top,
                     SWP_NOZORDER | SWP_NOACTIVATE);

        GetClientRect(hwnd, &rc);
        CtUiLayout(rc.right - rc.left, rc.bottom - rc.top);
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_TIMER:
        if (wParam != TIMER_TICK)
            return 0;

        CtTick();
        CtUiTick();
        UpdateTaskbar();

        {
            CtState state   = CtGetState();
            int     display = CtGetDisplaySec();
            int     round   = CtGetRound();
            BOOL    dirty   = FALSE;

            if (state != g_lastState)
            {
                if (state == CT_STATE_DONE)
                {
                    FLASHWINFO fw;

                    fw.cbSize    = sizeof(fw);
                    fw.hwnd      = hwnd;
                    fw.dwFlags   = FLASHW_TRAY | FLASHW_TIMERNOFG;
                    fw.uCount    = 0;
                    fw.dwTimeout = 0;
                    FlashWindowEx(&fw);
                }

                // Enable states of presets / fields / buttons follow the state,
                // so the rectangles must be rebuilt.
                CtUiRelayout();
                dirty = TRUE;
            }

            if (display != g_lastDisplay || round != g_lastRound)
                dirty = TRUE;

            if (dirty)
            {
                g_lastState   = state;
                g_lastDisplay = display;
                g_lastRound   = round;

                UpdateTitle();
                InvalidateRect(hwnd, NULL, FALSE);
            }
        }

        if (CtUiIsEditing())
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_MOUSEMOVE:
    {
        TRACKMOUSEEVENT tme;

        tme.cbSize      = sizeof(tme);
        tme.dwFlags     = TME_LEAVE;
        tme.hwndTrack   = hwnd;
        tme.dwHoverTime = 0;
        TrackMouseEvent(&tme);

        if (CtUiOnMouseMove(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_MOUSEWHEEL:
    {
        POINT pt;

        pt.x = GET_X_LPARAM(lParam);
        pt.y = GET_Y_LPARAM(lParam);
        ScreenToClient(hwnd, &pt);

        if (CtUiOnMouseWheel(pt.x, pt.y, GET_WHEEL_DELTA_WPARAM(wParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_MOUSELEAVE:
        if (CtUiOnMouseLeave())
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_LBUTTONDOWN:
        SetCapture(hwnd);
        SetFocus(hwnd);
        SetActiveWindow(hwnd);

        if (CtUiOnMouseDown(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_LBUTTONUP:
        if (CtUiOnMouseUp(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            InvalidateRect(hwnd, NULL, FALSE);

        if (GetCapture() == hwnd)
            ReleaseCapture();
        return 0;

    case WM_ACTIVATE:
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_CAPTURECHANGED:
        CtUiOnCaptureLost();
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_EXITSIZEMOVE:
        RememberWindowPos(hwnd);
        CtConfigSave(&g_settings);
        return 0;

    case WM_KEYDOWN:
        if (CtUiOnKeyDown((int)wParam))
        {
            CtUiRelayout();
            UpdateTitle();
            InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;

    case WM_CHAR:
        if (CtUiOnChar((wchar_t)wParam))
        {
            CtUiRelayout();
            UpdateTitle();
            InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;

    case WM_SETTINGCHANGE:
        if (wParam == SPI_SETHIGHCONTRAST)
        {
            CtThemeInit();
            CtUiRelayout();
            InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;

    default:
        break;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE prev, PWSTR cmdline, int show)
{
    WNDCLASSEXW wc;
    MSG         msg;
    HWND        hwnd;

    (void)prev; (void)cmdline;

    g_instance = inst;

    // DPI awareness is declared in the manifest (PerMonitorV2). The runtime
    // call is deliberately NOT repeated here: calling it after the first
    // window exists is rejected by Windows, and calling it before CreateWindow
    // while the manifest already set the mode is unnecessary.

    ZeroMemory(&wc, sizeof(wc));
    wc.cbSize        = sizeof(wc);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = inst;
    wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
    wc.hIcon         = LoadIconW(inst, MAKEINTRESOURCEW(1));
    wc.hIconSm       = wc.hIcon;
    wc.hbrBackground = NULL;
    wc.lpszClassName = CT_WINDOW_CLASS;

    if (!RegisterClassExW(&wc))
        return 0;

    hwnd = CreateWindowExW(0, CT_WINDOW_CLASS, CT_APP_NAME,
                           WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
                           CW_USEDEFAULT, CW_USEDEFAULT,
                           CtScale(CT_BASE_W), CtScale(CT_BASE_H),
                           NULL, NULL, inst, NULL);

    if (hwnd == NULL)
        return 0;

    ApplyMetrics(hwnd, QueryDpi(hwnd), TRUE);

    {
        RECT wr;

        GetWindowRect(hwnd, &wr);

        if (g_settings.hasWindowPos &&
            WindowPosUsable(g_settings.windowX, g_settings.windowY,
                            wr.right - wr.left, wr.bottom - wr.top))
        {
            SetWindowPos(hwnd, NULL, g_settings.windowX, g_settings.windowY, 0, 0,
                         SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
        else
        {
            CenterWindow(hwnd);
        }
    }

    // Keep the effective position in the settings even on the very first run,
    // so closing the app always persists where it actually was.
    RememberWindowPos(hwnd);
    UpdateTitle();

    g_lastState   = CtGetState();
    g_lastDisplay = CtGetDisplaySec();
    g_lastRound   = CtGetRound();

    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);

    while (GetMessageW(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return (int)msg.wParam;
}
