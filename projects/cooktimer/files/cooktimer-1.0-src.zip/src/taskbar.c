// MIT License
//
// Copyright (c) 2026 Polina "Aura" N.
// Copyright (c) 2026 Julia Nechaevskaya
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

//
// Cook Timer - taskbar button progress (ITaskbarList3).
//
// The same mechanism Explorer uses while copying or a player uses while
// playing: a green fill grows behind the taskbar button, turns yellow while
// paused and red when the countdown has finished. Everything degrades to a
// no-op on systems or shells that do not expose ITaskbarList3.
//

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif

#include "common.h"
#include "taskbar.h"

#include <objbase.h>
#include <shobjidl.h>

static ITaskbarList3 *g_taskbar     = NULL;
static HWND           g_hwnd        = NULL;
static BOOL           g_comInit     = FALSE;
static int            g_lastState   = -1;
static int            g_lastPercent = -1;

void CtTaskbarInit(HWND hwnd)
{
    HRESULT hr;

    g_hwnd = hwnd;

    hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (FAILED(hr) && hr != RPC_E_CHANGED_MODE)
        return;

    g_comInit = SUCCEEDED(hr) ? TRUE : FALSE;

    if (FAILED(CoCreateInstance(&CLSID_TaskbarList, NULL, CLSCTX_INPROC_SERVER,
                                &IID_ITaskbarList3, (void **)&g_taskbar)))
    {
        g_taskbar = NULL;
        return;
    }

    if (FAILED(g_taskbar->lpVtbl->HrInit(g_taskbar)))
    {
        g_taskbar->lpVtbl->Release(g_taskbar);
        g_taskbar = NULL;
    }
}

void CtTaskbarShutdown(void)
{
    if (g_taskbar != NULL)
    {
        if (g_hwnd != NULL)
            g_taskbar->lpVtbl->SetProgressState(g_taskbar, g_hwnd, TBPF_NOPROGRESS);

        g_taskbar->lpVtbl->Release(g_taskbar);
        g_taskbar = NULL;
    }

    if (g_comInit)
    {
        CoUninitialize();
        g_comInit = FALSE;
    }

    g_hwnd        = NULL;
    g_lastState   = -1;
    g_lastPercent = -1;
}

void CtTaskbarSet(CtTaskbarState state, int completed, int total)
{
    TBPFLAG flag;
    int     percent;

    if (g_taskbar == NULL || g_hwnd == NULL)
        return;

    if (total <= 0)
        total = 100;

    if (completed < 0)
        completed = 0;
    if (completed > total)
        completed = total;

    percent = (int)(((long long)completed * 100) / total);

    if ((int)state != g_lastState)
    {
        switch (state)
        {
        case CT_TASKBAR_NORMAL: flag = TBPF_NORMAL; break;
        case CT_TASKBAR_PAUSED: flag = TBPF_PAUSED; break;
        case CT_TASKBAR_ERROR:  flag = TBPF_ERROR;  break;
        default:                flag = TBPF_NOPROGRESS; break;
        }

        g_taskbar->lpVtbl->SetProgressState(g_taskbar, g_hwnd, flag);
        g_lastState = (int)state;

        if (state == CT_TASKBAR_NO_PROGRESS)
            g_lastPercent = -1;
    }

    if (state != CT_TASKBAR_NO_PROGRESS && percent != g_lastPercent)
    {
        g_taskbar->lpVtbl->SetProgressValue(g_taskbar, g_hwnd,
                                            (ULONGLONG)percent, 100ULL);
        g_lastPercent = percent;
    }
}
